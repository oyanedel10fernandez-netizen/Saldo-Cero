# SALDO CERO V49

V49 es una corrección del pipeline de evidencia de V48.

- Mantiene Gradle 8.9 y los jobs Backend/Android independientes.
- Busca APK y AAB de forma recursiva dentro de `app/build/outputs`.
- Copia ambos archivos a `android/artifacts/` antes de subirlos.
- Publica un único artefacto Android simple de localizar: `saldo-cero-v49-android`.
- `if-no-files-found: error` evita falsos verdes si falta el AAB.
- Genera `release-evidence.txt` con nombres y SHA-256.
- Backend también publica evidencia con fallo explícito si falta el archivo.
- No contiene credenciales ni conexiones reales de producción.

Estado: preparado para ejecutar en GitHub Actions.
