# CHANGELOG V49

- Pipeline Android reforzado para entregar APK/AAB como artefacto único.
- Detección recursiva de salidas Gradle.
- Evidencia SHA-256 consolidada.
- `if-no-files-found: error` para evitar ejecuciones verdes sin artefactos.
- Verificación estática V49.
