import fs from "node:fs";
import path from "node:path";
const root = path.resolve(new URL("../..", import.meta.url).pathname);
const required = [
  "backend/package.json",
  "backend/src/server.ts",
  "android/app/build.gradle.kts",
  ".github/workflows/verify-build-v49.yml",
  "V49_STATUS.md",
];
for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) throw new Error(`Missing ${rel}`);
}
const pkg = JSON.parse(fs.readFileSync(path.join(root,"backend/package.json"),"utf8"));
if (!pkg.scripts?.build || !pkg.scripts?.["verify:v49"]) throw new Error("Backend scripts missing");
const gradle = fs.readFileSync(path.join(root,"android/app/build.gradle.kts"),"utf8");
if (!gradle.includes("versionCode = 49") || !gradle.includes("versionName = \"49.0.0\"")) throw new Error("Android version is not V49");
console.log("V49 static verification: PASS");
