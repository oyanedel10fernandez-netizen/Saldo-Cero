# V49 BUILD EVIDENCE

Objetivo: obtener evidencia inequívoca del build Android y del backend.

## Android
1. `clean assembleDebug`
2. `bundleRelease`
3. búsqueda recursiva de `.apk` y `.aab`
4. copia a `android/artifacts/`
5. SHA-256
6. upload-artifact con `if-no-files-found: error`

## Backend
1. npm install
2. npm run build
3. npm run verify:v49
4. comprobación de `dist/server.js`

V49 no afirma que exista una infraestructura productiva conectada.
