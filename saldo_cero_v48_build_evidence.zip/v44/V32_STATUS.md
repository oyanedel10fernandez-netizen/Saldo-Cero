# SALDO CERO V35

## Añadido
- harness de checks de staging
- fixtures de billing para casos activos/expirados/revocados/pending
- redacción de secretos para pruebas/logs
- contrato de smoke tests de API
- plan de pruebas de integración
- production readiness gate
- corrección del contexto Docker del workflow CI/CD cuando aplica

## Estado
El paquete sigue sin credenciales reales, proyecto Cloud, Cloud SQL, Pub/Sub o Google Play conectados. Debe probarse en staging antes de producción.
