# V27

- Google Play service-account OAuth2 boundary made concrete with `google-auth-library`.
- Google Play Subscriptions V2 HTTP client.
- Fastify RTDN webhook endpoint with Pub/Sub payload decoding and event idempotency.
- Production PostgreSQL migration for billing events/jobs.
- Production environment template for Cloud SQL, Google Play and Pub/Sub.
- Android version 27.0.0.
