package cl.saldocero.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class AppState(
    val loggedIn:Boolean=false,
    val loading:Boolean=false,
    val error:String?=null,
    val debts:List<DebtDto> = emptyList(),
    val strategy:String="AVALANCHE",
    val plan:PlanResponse?=null,
    val assistantReply:String?=null
)

class MainViewModel(app:Application):AndroidViewModel(app) {
    private val repo=SaldoCeroRepository(app)
    private val _state=MutableStateFlow(AppState(loggedIn=SaldoCeroRepository(app).hasSession()))
    val state:StateFlow<AppState> = _state

    fun login(email:String,password:String)=auth{repo.login(email,password)}
    fun register(email:String,password:String)=auth{repo.register(email,password)}

    private fun auth(call:suspend()->AuthResponse)=viewModelScope.launch {
        _state.value=_state.value.copy(loading=true,error=null)
        try { call(); loadDebts() } catch(e:Exception) {
            _state.value=_state.value.copy(loading=false,error=e.message?:"Error de conexión")
        }
    }

    fun loadDebts()=viewModelScope.launch {
        _state.value=_state.value.copy(loading=true,error=null)
        try {
            val d=repo.loadDebts()
            _state.value=_state.value.copy(loading=false,loggedIn=true,debts=d)
        } catch(e:Exception) {
            _state.value=_state.value.copy(loading=false,error=e.message?:"No se pudieron cargar las deudas")
        }
    }

    fun addDebt(name:String,balanceCents:Long,paymentCents:Long,rateBps:Int)=viewModelScope.launch {
        _state.value=_state.value.copy(loading=true,error=null)
        try { repo.addDebt(DebtDto(name=name,balance_cents=balanceCents,payment_cents=paymentCents,annual_rate_bps=rateBps)); loadDebts() }
        catch(e:Exception){_state.value=_state.value.copy(loading=false,error=e.message?:"No se pudo guardar")}
    }

    fun deleteDebt(id:String)=viewModelScope.launch {
        try { repo.removeDebt(id); loadDebts() }
        catch(e:Exception){_state.value=_state.value.copy(error=e.message?:"No se pudo eliminar")}
    }

    fun calculate(strategy:String)=viewModelScope.launch {
        try { val p=repo.plan(strategy); _state.value=_state.value.copy(strategy=strategy,plan=p) }
        catch(e:Exception){_state.value=_state.value.copy(error=e.message?:"No se pudo calcular")}
    }

    fun askAssistant(text:String)=viewModelScope.launch {
        try { val r=repo.assistant(text); _state.value=_state.value.copy(assistantReply=r.message) }
        catch(e:Exception){_state.value=_state.value.copy(error=e.message?:"No se pudo contactar al asistente")}
    }

    fun logout(){repo.logout();_state.value=AppState()}
}
