package cl.saldocero.app

import android.content.Context

class SessionStore(context:Context) {
    private val prefs=context.getSharedPreferences("saldo_cero_session",Context.MODE_PRIVATE)
    fun saveToken(token:String){prefs.edit().putString("access_token",token).apply()}
    fun token():String?=prefs.getString("access_token",null)
    fun clear(){prefs.edit().clear().apply()}
}
