package cl.saldocero.app

enum class EntitlementFreshness {
    UNKNOWN,
    CHECKING,
    VERIFIED,
    EXPIRED,
    ERROR
}

data class EntitlementPresentation(
    val plan: String = "FREE",
    val active: Boolean = false,
    val freshness: EntitlementFreshness = EntitlementFreshness.UNKNOWN,
    val expiresAt: String? = null
)
