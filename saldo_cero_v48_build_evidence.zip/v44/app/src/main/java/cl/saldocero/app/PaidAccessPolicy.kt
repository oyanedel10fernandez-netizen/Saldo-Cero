package cl.saldocero.app

object PaidAccessPolicy {
    fun isPaid(plan:String, active:Boolean):Boolean {
        return active && (plan.equals("PRO",true) || plan.equals("PREMIUM",true))
    }
}
