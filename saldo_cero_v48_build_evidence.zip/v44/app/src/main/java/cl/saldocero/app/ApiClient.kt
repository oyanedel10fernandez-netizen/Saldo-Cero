package cl.saldocero.app

/**
 * Transport contract for the v9 API.
 * Replace the implementation with OkHttp/Retrofit in the Android build.
 */
data class ApiConfig(val baseUrl: String)

data class LoginResult(val accessToken: String, val userId: String, val email: String)

interface SaldoCeroApi {
    suspend fun register(email: String, password: String): LoginResult
    suspend fun login(email: String, password: String): LoginResult
    suspend fun me(token: String): String
    suspend fun debts(token: String): List<DebtDto>
    suspend fun createDebt(token: String, debt: DebtDto): DebtDto
    suspend fun deleteDebt(token: String, id: String)
    suspend fun calculatePlan(token: String, strategy: String): PlanDto
}

data class DebtDto(
    val id: String? = null,
    val name: String,
    val balanceCents: Long,
    val paymentCents: Long,
    val annualRateBps: Int,
    val dueDay: Int? = null
)

data class PlanDto(
    val strategy: String,
    val extraPaymentCents: Long,
    val priority: List<DebtDto>
)
