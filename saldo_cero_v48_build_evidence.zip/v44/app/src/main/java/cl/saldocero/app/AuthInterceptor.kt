package cl.saldocero.app

import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val session: SecureSessionStore): Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token=session.token()
        val request=chain.request().newBuilder()
        if(token!=null) request.header("Authorization","Bearer $token")
        return chain.proceed(request.build())
    }
}
