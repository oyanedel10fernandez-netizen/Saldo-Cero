package cl.saldocero.app

import kotlinx.serialization.Serializable

@Serializable data class RefreshRequest(val refresh_token:String)
@Serializable data class RefreshResponse(val access_token:String,val refresh_token:String)
@Serializable data class ForgotPasswordRequest(val email:String)
@Serializable data class ResetPasswordRequest(val token:String,val new_password:String)
