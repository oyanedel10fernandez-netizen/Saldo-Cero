package cl.saldocero.app

data class CommercialPlan(val name:String,val priceClp:Int,val features:List<String>,val highlighted:Boolean=false)

val SALDO_CERO_PLANS=listOf(
    CommercialPlan("Gratis",0,listOf("Diagnóstico básico","Hasta 3 deudas","Plan inicial")),
    CommercialPlan("Pro",9990,listOf("Deudas ilimitadas","Avalancha y bola de nieve","Simulaciones","Asistente IA"),true),
    CommercialPlan("Premium",14990,listOf("Todo Pro","Seguimiento avanzado","Contenido educativo premium"))
)
