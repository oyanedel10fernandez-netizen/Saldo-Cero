package cl.saldocero.app

data class CommercialState(
    val profile:ProfileDto?=null,
    val subscription:SubscriptionDto?=null,
    val saving:Boolean=false,
    val message:String?=null
)
