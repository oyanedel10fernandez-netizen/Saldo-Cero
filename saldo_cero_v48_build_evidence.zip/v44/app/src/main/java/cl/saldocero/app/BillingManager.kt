package cl.saldocero.app

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

class BillingManager(
    context: Context,
    private val onProducts: (List<ProductDetails>) -> Unit,
    private val onPurchaseToken: (productId:String, token:String) -> Unit,
    private val onError: (String) -> Unit
) : PurchasesUpdatedListener {

    companion object {
        const val PRO_ID = "saldo_cero_pro_monthly"
        const val PREMIUM_ID = "saldo_cero_premium_monthly"
    }

    private val billingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases()
        .build()

    fun connect() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() {}
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) queryProducts()
                else onError("Google Play Billing: ${result.debugMessage}")
            }
        })
    }

    private fun queryProducts() {
        val params=QueryProductDetailsParams.newBuilder()
            .setProductList(listOf(PRO_ID,PREMIUM_ID).map{
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(it)
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build()
            }).build()
        billingClient.queryProductDetailsAsync(params){result,details->
            if(result.responseCode==BillingClient.BillingResponseCode.OK) onProducts(details)
            else onError(result.debugMessage)
        }
    }

    fun buy(activity: Activity, product: ProductDetails) {
        val offer=product.subscriptionOfferDetails?.firstOrNull()
            ?: return onError("No hay oferta disponible para ${product.productId}")
        val productParams=BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(product)
            .setOfferToken(offer.offerToken)
            .build()
        val params=BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams)).build()
        billingClient.launchBillingFlow(activity,params)
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if(result.responseCode==BillingClient.BillingResponseCode.OK && purchases!=null){
            purchases.forEach{ purchase ->
                purchase.products.forEach{ productId ->
                    if(purchase.purchaseState==Purchase.PurchaseState.PURCHASED) {
                        if(!purchase.isAcknowledged) {
                            billingClient.acknowledgePurchase(
                                AcknowledgePurchaseParams.newBuilder()
                                    .setPurchaseToken(purchase.purchaseToken).build()
                            ) { }
                        }
                        onPurchaseToken(productId,purchase.purchaseToken)
                    }
                }
            }
        } else if(result.responseCode!=BillingClient.BillingResponseCode.USER_CANCELED) {
            onError(result.debugMessage)
        }
    }

    fun restore() {
        billingClient.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        ){result,purchases->
            if(result.responseCode==BillingClient.BillingResponseCode.OK)
                purchases.forEach{p->p.products.forEach{onPurchaseToken(it,p.purchaseToken)}}
        }
    }
}
