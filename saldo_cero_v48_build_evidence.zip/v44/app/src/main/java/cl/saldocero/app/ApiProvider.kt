package cl.saldocero.app

import android.content.Context
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType

object ApiProvider {
    // Local emulator. Production must be HTTPS.
    const val BASE_URL = BuildConfig.API_BASE_URL
    fun create(context: Context): SaldoCeroApi {
        val session=SecureSessionStore(context)
        val client=OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(session))
            .build()
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(kotlinx.serialization.json.Json{ignoreUnknownKeys=true}
                .asConverterFactory("application/json".toMediaType()))
            .build()
            .create(SaldoCeroApi::class.java)
    }
}
