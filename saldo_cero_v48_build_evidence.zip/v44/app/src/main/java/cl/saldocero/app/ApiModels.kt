package cl.saldocero.app

import kotlinx.serialization.Serializable

@Serializable
data class AuthRequest(val email:String,val password:String)

@Serializable
data class UserDto(val id:String,val email:String)

@Serializable
data class AuthResponse(val access_token:String,val user:UserDto)

@Serializable
data class DebtDto(
    val id:String?=null,
    val name:String,
    val balance_cents:Long,
    val payment_cents:Long,
    val annual_rate_bps:Int,
    val due_day:Int?=null
)

@Serializable
data class DebtResponse(val debt:DebtDto)

@Serializable
data class DebtsResponse(val debts:List<DebtDto>)

@Serializable
data class PlanRequest(val strategy:String,val extra_payment_cents:Long=0)

@Serializable
data class PlanResponse(val strategy:String,val extra_payment_cents:Long,val priority:List<DebtDto>)

@Serializable
data class AssistantRequest(val message:String)

@Serializable
data class AssistantResponse(val mode:String,val message:String,val echo:String?=null)
