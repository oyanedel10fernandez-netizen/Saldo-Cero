package cl.saldocero.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class EntitlementViewModel(app:Application):AndroidViewModel(app){
    private val repo=SaldoCeroRepository(app)
    private val _state=MutableStateFlow(EntitlementDto())
    val state:StateFlow<EntitlementDto> = _state

    fun refresh(){
        viewModelScope.launch {
            try { _state.value=repo.entitlement() } catch(_:Exception) { }
        }
    }
}


    fun paidLabel(): String {
        val p = entitlement.value.plan.uppercase()
        return when {
            entitlement.value.active && p == "PREMIUM" -> "Premium activo"
            entitlement.value.active && p == "PRO" -> "Pro activo"
            else -> "Plan Gratis"
        }
    }
