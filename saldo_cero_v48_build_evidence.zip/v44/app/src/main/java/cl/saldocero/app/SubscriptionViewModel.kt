package cl.saldocero.app

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

data class SubscriptionUiState(
    val currentPlan:String="FREE",
    val products:List<String> = emptyList(),
    val message:String?=null,
    val loading:Boolean=false
)

class SubscriptionViewModel(app:Application):AndroidViewModel(app){
    private val repo=SaldoCeroRepository(app)
    private val _state=kotlinx.coroutines.flow.MutableStateFlow(SubscriptionUiState())
    val state=kotlinx.coroutines.flow.StateFlow(_state)

    fun load(){
        viewModelScope.launch {
            _state.value=_state.value.copy(loading=true)
            try{
                val sub=repo.subscription()
                _state.value=_state.value.copy(loading=false,currentPlan=sub.plan)
            }catch(e:Exception){
                _state.value=_state.value.copy(loading=false,message=e.message)
            }
        }
    }

    fun verify(productId:String,token:String){
        viewModelScope.launch {
            _state.value=_state.value.copy(loading=true)
            try{
                val sub=repo.verifyPurchase(productId,token)
                _state.value=_state.value.copy(loading=false,currentPlan=sub.plan,message="Compra enviada para verificación")
            }catch(e:Exception){
                _state.value=_state.value.copy(loading=false,message=e.message)
            }
        }
    }
}
