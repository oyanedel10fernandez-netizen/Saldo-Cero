package cl.saldocero.app

object Validation {
    fun email(v:String)=v.trim().matches(Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))
    fun password(v:String)=v.length>=8
    fun debtName(v:String)=v.trim().length in 2..80
    fun money(v:String)=v.toLongOrNull()?.let{it>=0}==true
    fun rate(v:String)=v.toDoubleOrNull()?.let{it in 0.0..200.0}==true
}
