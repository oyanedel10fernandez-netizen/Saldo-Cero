package cl.saldocero.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun V11ConnectedApp(vm:MainViewModel=viewModel()){
    val s by vm.state.collectAsState()
    if(!s.loggedIn) LoginView(s.loading,s.error,vm::login,vm::register)
    else DashboardConnected(s,vm)
}

@Composable private fun LoginView(
    loading:Boolean,error:String?,login:(String,String)->Unit,register:(String,String)->Unit
){
    var email by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){
        Text("SALDO CERO",style=MaterialTheme.typography.headlineLarge)
        Text("Tu camino para ordenar tus deudas.")
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(email,{email=it},label={Text("Correo")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(pass,{pass=it},label={Text("Contraseña")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button(enabled=!loading,onClick={login(email,pass)}){Text("Ingresar")}
            OutlinedButton(enabled=!loading,onClick={register(email,pass)}){Text("Crear cuenta")}
        }
        if(error!=null) Text(error,color=MaterialTheme.colorScheme.error)
    }
}

@Composable private fun DashboardConnected(s:AppState,vm:MainViewModel){
    var name by remember{mutableStateOf("")}; var balance by remember{mutableStateOf("")}
    var payment by remember{mutableStateOf("")}; var rate by remember{mutableStateOf("")}
    var question by remember{mutableStateOf("")}
    LazyColumn(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{
            Text("SALDO CERO",style=MaterialTheme.typography.headlineMedium)
            Text("Deudas conectadas a tu cuenta")
            Text("Total: $${s.debts.sumOf{it.balance_cents}/100}")
        }
        item{
            OutlinedTextField(name,{name=it},label={Text("Nombre de deuda")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(balance,{balance=it},label={Text("Saldo (CLP)")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(payment,{payment=it},label={Text("Cuota mensual (CLP)")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(rate,{rate=it},label={Text("Tasa anual (%)")},modifier=Modifier.fillMaxWidth())
            Button(onClick={
                vm.addDebt(name,balance.toLongOrNull()?.times(100)?:0,payment.toLongOrNull()?.times(100)?:0,
                    ((rate.toDoubleOrNull()?:0.0)*100).toInt())
            }){Text("Guardar deuda")}
        }
        item{
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Button(onClick={vm.calculate("AVALANCHE")}){Text("Avalancha")}
                OutlinedButton(onClick={vm.calculate("SNOWBALL")}){Text("Bola de nieve")}
            }
        }
        item{s.plan?.let{Text("Prioridad: "+it.priority.joinToString(" → "){d->d.name})}}
        items(s.debts){d->
            Card(Modifier.fillMaxWidth()){
                Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Column{Text(d.name);Text("$${d.balance_cents/100}")}
                    if(d.id!=null) TextButton(onClick={vm.deleteDebt(d.id)}){Text("Eliminar")}
                }
            }
        }
        item{
            OutlinedTextField(question,{question=it},label={Text("Pregunta al asistente")},modifier=Modifier.fillMaxWidth())
            Button(onClick={vm.askAssistant(question)}){Text("Preguntar")}
            s.assistantReply?.let{Text(it)}
        }
        item{TextButton(onClick=vm::logout){Text("Cerrar sesión")}}
        s.error?.let{item{Text(it,color=MaterialTheme.colorScheme.error)}}
    }
}
