package cl.saldocero.app

import kotlinx.serialization.Serializable

@Serializable
data class ProfileDto(
    val id:String,
    val email:String,
    val display_name:String?=null,
    val currency:String="CLP"
)

@Serializable data class UpdateProfileRequest(val display_name:String?)
@Serializable data class SubscriptionDto(
    val plan:String="FREE",
    val status:String="ACTIVE",
    val renews_at:String?=null
)
@Serializable data class VerifyPurchaseRequest(
    val product_id:String,
    val purchase_token:String
)
