package cl.saldocero.app

object EntitlementRefreshPolicy {
    const val ON_APP_START = "ON_APP_START"
    const val AFTER_PURCHASE = "AFTER_PURCHASE"
    const val AFTER_RESTORE = "AFTER_RESTORE"
    const val MANUAL_REFRESH = "MANUAL_REFRESH"
}
