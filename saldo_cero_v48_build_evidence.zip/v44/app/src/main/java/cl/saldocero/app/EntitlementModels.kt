package cl.saldocero.app

import kotlinx.serialization.Serializable

@Serializable
data class EntitlementDto(
    val plan:String="FREE",
    val active:Boolean=false,
    val expires_at:String?=null,
    val product_id:String?=null
)
