package cl.saldocero.app

data class BillingLifecycleUi(
    val plan: String = "FREE",
    val active: Boolean = false,
    val state: String = "UNKNOWN",
    val expiresAt: String? = null
)
