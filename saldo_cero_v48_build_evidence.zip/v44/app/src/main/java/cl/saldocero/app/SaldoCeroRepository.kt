package cl.saldocero.app

import android.content.Context

class SaldoCeroRepository(context: Context) {
    private val session=SecureSessionStore(context)
    private val api=ApiProvider.create(context)

    suspend fun register(email:String,password:String):AuthResponse {
        val r=api.register(AuthRequest(email,password)); session.saveToken(r.access_token); return r
    }
    suspend fun login(email:String,password:String):AuthResponse {
        val r=api.login(AuthRequest(email,password)); session.saveToken(r.access_token); return r
    }
    suspend fun loadDebts():List<DebtDto> = api.debts().debts
    suspend fun profile():ProfileDto=api.getProfile()
    suspend fun updateProfile(name:String?):ProfileDto=api.updateProfile(UpdateProfileRequest(name))
    suspend fun subscription():SubscriptionDto=api.subscription()
    suspend fun entitlement():EntitlementDto=api.entitlement()
    suspend fun verifyPurchase(productId:String,purchaseToken:String):SubscriptionDto=
        api.verifyPurchase(VerifyPurchaseRequest(productId,purchaseToken))
    suspend fun addDebt(debt:DebtDto):DebtDto = api.createDebt(debt).debt
    suspend fun updateDebt(id:String,debt:DebtDto):DebtDto = api.updateDebt(id,debt).debt
    suspend fun removeDebt(id:String){ api.deleteDebt(id) }
    suspend fun plan(strategy:String,extraPaymentCents:Long=0)=api.calculatePlan(PlanRequest(strategy,extraPaymentCents))
    suspend fun assistant(message:String)=api.assistant(AssistantRequest(message))
    suspend fun refresh():Boolean {
        val old=session.refreshToken() ?: return false
        return try {
            val r=api.refresh(RefreshRequest(old))
            session.saveToken(r.access_token); session.saveRefreshToken(r.refresh_token); true
        } catch(_:Exception){false}
    }
    suspend fun forgotPassword(email:String)=api.forgotPassword(ForgotPasswordRequest(email))
    suspend fun resetPassword(token:String,password:String)=api.resetPassword(ResetPasswordRequest(token,password))
    fun logout(){session.clear()}
    fun hasSession()=session.token()!=null
}
