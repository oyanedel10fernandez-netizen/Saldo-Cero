package cl.saldocero.app

import retrofit2.http.*

interface SaldoCeroApi {
    @POST("v1/auth/register") suspend fun register(@Body body:AuthRequest):AuthResponse
    @POST("v1/auth/login") suspend fun login(@Body body:AuthRequest):AuthResponse
    @POST("v1/auth/refresh") suspend fun refresh(@Body body:RefreshRequest):RefreshResponse
    @POST("v1/auth/forgot-password") suspend fun forgotPassword(@Body body:ForgotPasswordRequest):Map<String,String>
    @POST("v1/auth/reset-password") suspend fun resetPassword(@Body body:ResetPasswordRequest):Map<String,String>
    @GET("v1/me") suspend fun me():Map<String,Any>
    @GET("v1/profile") suspend fun getProfile():ProfileDto
    @PATCH("v1/profile") suspend fun updateProfile(@Body body:UpdateProfileRequest):ProfileDto
    @GET("v1/subscription") suspend fun subscription():SubscriptionDto
    @GET("v1/entitlement") suspend fun entitlement():EntitlementDto
    @POST("v1/subscription/verify") suspend fun verifyPurchase(@Body body:VerifyPurchaseRequest):SubscriptionDto
    @GET("v1/debts") suspend fun debts():DebtsResponse
    @POST("v1/debts") suspend fun createDebt(@Body debt:DebtDto):DebtResponse
    @PATCH("v1/debts/{id}") suspend fun updateDebt(@Path("id") id:String,@Body debt:DebtDto):DebtResponse
    @DELETE("v1/debts/{id}") suspend fun deleteDebt(@Path("id") id:String)
    @POST("v1/plans/calculate") suspend fun calculatePlan(@Body body:PlanRequest):PlanResponse
    @POST("v1/assistant/message") suspend fun assistant(@Body body:AssistantRequest):AssistantResponse
}
