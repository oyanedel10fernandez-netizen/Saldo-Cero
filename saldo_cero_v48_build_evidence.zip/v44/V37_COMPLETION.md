# V37 completion package

This release completes the production wiring layer without embedding real credentials.

Functional paths implemented:
1. API -> PostgreSQL/Cloud SQL via `DATABASE_URL`.
2. Sensitive endpoint rate limiting -> Redis/Memorystore via `REDIS_URL`.
3. Google Play verification -> OAuth service account supplied at runtime.
4. Pub/Sub RTDN -> OIDC verification -> durable DB event -> billing job.
5. Billing worker -> Google Play verification -> transactional entitlement persistence.
6. Secret Manager adapter available for runtime secret retrieval.
7. Request limits/security headers.
8. Production configuration gate.
9. Idempotency for billing events/purchases.

Security rule:
- No real secret, private key, token or production connection is present in this archive.
- `.env.example` contains placeholders only.

Operational requirement:
The code becomes connected only after an operator supplies the actual infrastructure and secret references in the deployment environment. This artifact itself makes no claim of production connectivity.
