# SALDO CERO V48

V48 corrige los dos bloqueos reales observados en V47:

1. **Gradle**: V47 usaba Gradle 8.7 mientras Android Gradle Plugin 8.7.3 exige como mínimo Gradle 8.9.
2. **Backend verifier**: `verify-v47.mjs` buscaba `android/app/build.gradle.kts` desde `backend/`, generando `ENOENT`. V48 resuelve la ruta de forma absoluta a partir de `import.meta.url`.

Cambios:
- Gradle CI fijado en 8.9.
- Verificador backend V48 independiente del directorio de ejecución.
- Verificación de versión 48.
- Jobs Backend y Android independientes.
- Android genera APK Debug y AAB Release.
- Se conserva Java/Kotlin JVM target 21.
- No contiene credenciales ni conexiones reales de producción.

Estado: listo para ejecutar en GitHub Actions.
