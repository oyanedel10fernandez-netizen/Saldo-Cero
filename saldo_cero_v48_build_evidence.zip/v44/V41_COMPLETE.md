# SALDO CERO v42 — COMPLETA

v42 consolida el salto desde el pipeline V40 hacia una infraestructura de producción reproducible.

## Incluye
- Redis/Memorystore para rate limiting compartido.
- VPC Access Connector para Cloud Run.
- Service Accounts para runtime y Pub/Sub.
- IAM base para Secret Manager y Pub/Sub OIDC.
- Secret Manager referenciado desde Cloud Run sin valores en Git.
- Cloud SQL PostgreSQL con backup/PITR.
- Pub/Sub RTDN con OIDC y reintentos.
- Resolución de eventos RTDN por hash de purchase token.
- Gate de configuración de producción.
- Readiness con dependencias.
- Secret scan.
- Terraform outputs.
- CI/CD base de V40 conservado.

## Importante
“Completa” significa completa a nivel de código/configuración preparada. NO significa que exista un proyecto GCP real, credenciales reales, dominio, datos de producción o una cuenta de Google Play conectada.

Antes del lanzamiento real deben ejecutarse Terraform, cargar secretos, configurar Google Play RTDN, crear/verificar el endpoint, ejecutar migraciones, probar staging y firmar el AAB.
