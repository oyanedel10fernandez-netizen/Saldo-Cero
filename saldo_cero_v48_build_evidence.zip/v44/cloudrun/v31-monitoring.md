# V35 Cloud Monitoring
Dashboard: Cloud Run (4xx/5xx/latencia), Pub/Sub (backlog/oldest age), Cloud SQL (CPU/storage/connections), billing queue y RTDN rate.
Umbrales iniciales: 5xx >2%/5m; p95 >1500ms/10m; billing failures >0/5m; oldest billing job >900s; storage Cloud SQL >80%. Ajustar con tráfico real.
