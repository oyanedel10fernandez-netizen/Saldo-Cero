# V35 Rollback

- Keep the previous Cloud Run revision available.
- Do not delete the previous container image until smoke tests pass.
- If billing processing fails, pause/redirect the Pub/Sub subscription before destructive DB changes.
- Roll back the Cloud Run revision first, then investigate queue/database state.
- Billing events are append/audit-oriented and should not be deleted during rollback.
