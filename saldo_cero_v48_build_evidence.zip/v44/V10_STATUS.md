# SALDO CERO v10

V10 is the integration release.

## Added
- Android Retrofit API layer.
- Android session token store.
- Configurable API base URL.
- Backend PostgreSQL persistence.
- Auth register/login.
- Persistent debt CRUD endpoints.
- Server-side plan ordering.
- AI gateway endpoint.
- Production-oriented environment variables.

## What is still required before public launch
- Wire every Compose screen to Retrofit/repository instead of demo data.
- Encrypted token storage (e.g. Android Keystore-backed solution).
- Refresh-token rotation and password recovery/email verification.
- Database migration runner and managed PostgreSQL.
- Real AI provider with safety/privacy controls.
- Google Play Billing verification.
- Observability, rate limiting, automated tests and security audit.
- Chile-specific privacy/legal review.

The included project is source code, not a compiled APK.
