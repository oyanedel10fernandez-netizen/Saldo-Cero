variable "project_id" { type = string }
variable "region" { type = string default = "southamerica-west1" }
variable "cloud_sql_tier" { type = string default = "db-custom-1-3840" }
variable "rtdn_push_endpoint" { type = string default = "https://api.example.com/v1/webhooks/google-play/rtdn" }
