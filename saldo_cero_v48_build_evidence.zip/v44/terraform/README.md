# Terraform V35

This is a deployment template, not an executed deployment.

Before apply:
- authenticate locally with Google Cloud
- choose the production project ID
- review region/costs
- configure Pub/Sub OIDC authentication for the Cloud Run webhook
- create Secret Manager secrets and grant the runtime service account least-privilege access
- configure Google Play RTDN in Play Console to publish to the topic

Do not commit service-account JSON or passwords.
