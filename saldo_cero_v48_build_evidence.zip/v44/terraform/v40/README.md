# Terraform V40

V40 define infraestructura reproducible sin credenciales embebidas.

Antes de `terraform apply`:
- configurar backend remoto de estado con control de acceso;
- proporcionar `project_id`, cuentas de servicio y endpoints mediante variables/CI;
- revisar IAM y costos;
- resolver `rtdn_endpoint` y `rtdn_audience` reales.

Los secretos se crean como recursos de Secret Manager, pero sus valores NO están en Terraform.
