provider "google" {
  project = var.project_id
  region  = var.region
}

locals {
  apis = [
    "run.googleapis.com",
    "sqladmin.googleapis.com",
    "secretmanager.googleapis.com",
    "pubsub.googleapis.com",
    "artifactregistry.googleapis.com",
    "iam.googleapis.com"
  ]
  secrets = [
    "google-play-package-name",
    "google-play-service-account-json",
    "saldo-cero-database-url",
    "saldo-cero-redis-url",
    "saldo-cero-jwt-secret",
    "saldo-cero-pubsub-audience",
    "saldo-cero-pubsub-service-account"
  ]
}

resource "google_project_service" "apis" {
  for_each = toset(local.apis)
  service  = each.value
  disable_on_destroy = false
}

resource "google_artifact_registry_repository" "api" {
  location = var.region
  repository_id = "saldo-cero"
  format = "DOCKER"
}

resource "google_sql_database_instance" "postgres" {
  name = "saldo-cero-postgres"
  database_version = "POSTGRES_16"
  region = var.region
  settings {
    tier = "db-custom-1-3840"
    availability_type = "REGIONAL"
    disk_type = "PD_SSD"
    disk_size = 20
    disk_autoresize = true
    backup_configuration {
      enabled = true
      point_in_time_recovery_enabled = true
    }
  }
  deletion_protection = true
}

resource "google_sql_database" "app" {
  name = "saldo_cero"
  instance = google_sql_database_instance.postgres.name
}

resource "google_secret_manager_secret" "secrets" {
  for_each = toset(local.secrets)
  secret_id = each.value
  replication { auto {} }
}

resource "google_pubsub_topic" "rtdn" {
  name = "saldo-cero-google-play-rtdn"
}

resource "google_pubsub_subscription" "rtdn" {
  name = "saldo-cero-google-play-rtdn-push"
  topic = google_pubsub_topic.rtdn.name
  ack_deadline_seconds = 30
  push_config {
    push_endpoint = var.rtdn_endpoint
    oidc_token {
      service_account_email = var.pubsub_push_service_account
      audience = var.rtdn_audience
    }
  }
  retry_policy {
    minimum_backoff = "10s"
    maximum_backoff = "600s"
  }
}

resource "google_cloud_run_v2_service" "api" {
  name = var.service_name
  location = var.region
  ingress = "INGRESS_TRAFFIC_ALL"
  template {
    service_account = var.runtime_service_account
    containers {
      image = var.container_image
      ports { container_port = 8080 }
      env {
        name = "NODE_ENV"
        value = "production"
      }
    }
  }
  deletion_protection = true
}
