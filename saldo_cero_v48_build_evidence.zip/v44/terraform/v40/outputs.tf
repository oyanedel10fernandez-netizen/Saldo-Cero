output "cloud_run_uri" {
  value = google_cloud_run_v2_service.api.uri
}
output "cloud_sql_connection_name" {
  value = google_sql_database_instance.postgres.connection_name
}
output "artifact_registry_repository" {
  value = google_artifact_registry_repository.api.name
}
