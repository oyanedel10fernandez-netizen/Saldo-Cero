variable "project_id" { type = string }
variable "region" { type = string default = "southamerica-west1" }
variable "service_name" { type = string default = "saldo-cero-api" }
variable "container_image" { type = string }
variable "runtime_service_account" { type = string }
variable "pubsub_push_service_account" { type = string }
variable "rtdn_endpoint" { type = string }
variable "rtdn_audience" { type = string }
