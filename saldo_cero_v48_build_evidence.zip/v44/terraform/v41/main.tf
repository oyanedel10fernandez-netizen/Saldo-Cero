provider "google" {
  project = var.project_id
  region  = var.region
}

locals {
  runtime_sa = coalesce(var.runtime_service_account, "saldo-cero-runtime@${var.project_id}.iam.gserviceaccount.com")
  pubsub_sa = coalesce(var.pubsub_push_service_account, "saldo-cero-pubsub@${var.project_id}.iam.gserviceaccount.com")
}

resource "google_project_service" "required" {
  for_each = toset([
    "run.googleapis.com","sqladmin.googleapis.com","secretmanager.googleapis.com",
    "pubsub.googleapis.com","artifactregistry.googleapis.com","iam.googleapis.com",
    "vpcaccess.googleapis.com","redis.googleapis.com"
  ])
  service = each.value
  disable_on_destroy = false
}

resource "google_service_account" "runtime" {
  account_id   = "saldo-cero-runtime"
  display_name = "SALDO CERO Cloud Run runtime"
}

resource "google_service_account" "pubsub" {
  account_id   = "saldo-cero-pubsub"
  display_name = "SALDO CERO Google Play RTDN Pub/Sub"
}

resource "google_project_iam_member" "runtime_secret" {
  project = var.project_id
  role = "roles/secretmanager.secretAccessor"
  member = "serviceAccount:${local.runtime_sa}"
}

resource "google_project_iam_member" "pubsub_token_creator" {
  project = var.project_id
  role = "roles/iam.serviceAccountTokenCreator"
  member = "serviceAccount:service-${data.google_project.current.number}@gcp-sa-pubsub.iam.gserviceaccount.com"
}

data "google_project" "current" {}

resource "google_artifact_registry_repository" "api" {
  location = var.region
  repository_id = "saldo-cero"
  format = "DOCKER"
}

resource "google_sql_database_instance" "postgres" {
  name = "saldo-cero-postgres"
  database_version = "POSTGRES_16"
  region = var.region
  settings {
    tier = "db-custom-1-3840"
    availability_type = "REGIONAL"
    disk_type = "PD_SSD"
    disk_size = 20
    disk_autoresize = true
    backup_configuration {
      enabled = true
      point_in_time_recovery_enabled = true
    }
  }
  deletion_protection = true
}

resource "google_sql_database" "app" {
  name = "saldo_cero"
  instance = google_sql_database_instance.postgres.name
}

resource "google_redis_instance" "cache" {
  name = "saldo-cero-redis"
  tier = "BASIC"
  memory_size_gb = 1
  region = var.region
  redis_version = "REDIS_7_2"
}

resource "google_vpc_access_connector" "connector" {
  name = "saldo-cero-vpc"
  region = var.region
  network = "default"
  ip_cidr_range = "10.8.0.0/28"
}

resource "google_secret_manager_secret" "secrets" {
  for_each = toset([
    "google-play-package-name","google-play-service-account-json",
    "saldo-cero-database-url","saldo-cero-redis-url","saldo-cero-jwt-secret",
    "saldo-cero-pubsub-audience"
  ])
  secret_id = each.value
  replication { auto {} }
}

resource "google_pubsub_topic" "rtdn" {
  name = "saldo-cero-google-play-rtdn"
}

resource "google_pubsub_subscription" "rtdn" {
  name = "saldo-cero-google-play-rtdn-push"
  topic = google_pubsub_topic.rtdn.name
  ack_deadline_seconds = 30
  push_config {
    push_endpoint = var.rtdn_endpoint
    oidc_token {
      service_account_email = local.pubsub_sa
      audience = var.rtdn_audience
    }
  }
  retry_policy {
    minimum_backoff = "10s"
    maximum_backoff = "600s"
  }
}

resource "google_cloud_run_v2_service" "api" {
  name = var.service_name
  location = var.region
  ingress = "INGRESS_TRAFFIC_ALL"
  template {
    service_account = local.runtime_sa
    vpc_access {
      connector = google_vpc_access_connector.connector.id
      egress = "PRIVATE_RANGES_ONLY"
    }
    containers {
      image = var.container_image
      ports { container_port = 8080 }
      env { name = "NODE_ENV" value = "production" }
      env { name = "GOOGLE_PLAY_PACKAGE_NAME" value_source { secret_key_ref { secret = "google-play-package-name" version = "latest" } } }
      env { name = "GOOGLE_PLAY_SERVICE_ACCOUNT_JSON" value_source { secret_key_ref { secret = "google-play-service-account-json" version = "latest" } } }
      env { name = "DATABASE_URL" value_source { secret_key_ref { secret = "saldo-cero-database-url" version = "latest" } } }
      env { name = "REDIS_URL" value_source { secret_key_ref { secret = "saldo-cero-redis-url" version = "latest" } } }
      env { name = "JWT_SECRET" value_source { secret_key_ref { secret = "saldo-cero-jwt-secret" version = "latest" } } }
      env { name = "PUBSUB_OIDC_AUDIENCE" value_source { secret_key_ref { secret = "saldo-cero-pubsub-audience" version = "latest" } } }
    }
  }
  deletion_protection = true
}
