terraform {
  required_version = ">= 1.6.0"
  required_providers { google = { source = "hashicorp/google", version = "~> 6.0" } }
}
provider "google" { project = var.project_id; region = var.region }

resource "google_project_service" "services" {
  for_each = toset(["run.googleapis.com","sqladmin.googleapis.com","artifactregistry.googleapis.com","secretmanager.googleapis.com","pubsub.googleapis.com","redis.googleapis.com","vpcaccess.googleapis.com","iamcredentials.googleapis.com","androidpublisher.googleapis.com"])
  service = each.value
  disable_on_destroy = false
}

resource "google_service_account" "runtime" {
  account_id   = "saldo-cero-api"
  display_name = "SALDO CERO API runtime"
  depends_on   = [google_project_service.services]
}
resource "google_service_account" "pubsub_push" {
  account_id   = "saldo-cero-pubsub"
  display_name = "SALDO CERO Pub/Sub push"
  depends_on   = [google_project_service.services]
}

resource "google_sql_database_instance" "postgres" {
  name = "saldo-cero-postgres"
  database_version = "POSTGRES_16"
  region = var.region
  settings { tier = var.cloud_sql_tier; availability_type = "ZONAL"; backup_configuration { enabled = true; point_in_time_recovery_enabled = true } }
  deletion_protection = true
  depends_on = [google_project_service.services]
}
resource "google_sql_database" "app" { name = "saldo_cero" instance = google_sql_database_instance.postgres.name }
resource "google_artifact_registry_repository" "api" { location = var.region; repository_id = "saldo-cero"; format = "DOCKER" }

resource "google_compute_network" "app" { name = "saldo-cero-vpc"; auto_create_subnetworks = false }
resource "google_compute_subnetwork" "app" { name = "saldo-cero-subnet"; ip_cidr_range = "10.42.0.0/24"; region = var.region; network = google_compute_network.app.id }
resource "google_vpc_access_connector" "run" {
  name = "saldo-cero-run"
  region = var.region
  network = google_compute_network.app.name
  ip_cidr_range = "10.8.0.0/28"
  depends_on = [google_project_service.services]
}
resource "google_redis_instance" "cache" {
  name = "saldo-cero-redis"
  tier = "BASIC"
  memory_size_gb = 1
  region = var.region
  redis_version = "REDIS_7_2"
  authorized_network = google_compute_network.app.id
  depends_on = [google_project_service.services]
}

resource "google_pubsub_topic" "rtdn" { name = "saldo-cero-google-play-rtdn" }
resource "google_pubsub_subscription" "rtdn_push" {
  name = "saldo-cero-google-play-rtdn-push"; topic = google_pubsub_topic.rtdn.id; ack_deadline_seconds = 30
  push_config {
    push_endpoint = var.rtdn_push_endpoint
    oidc_token { service_account_email = google_service_account.pubsub_push.email; audience = var.rtdn_push_endpoint }
  }
}
resource "google_cloud_run_v2_service_iam_member" "pubsub_invoker" {
  name = "saldo-cero-api"; location = var.region; role = "roles/run.invoker"; member = "serviceAccount:${google_service_account.pubsub_push.email}"
}

# Secret containers only: no secret values are created by Terraform.
resource "google_secret_manager_secret" "database_url" { secret_id = "saldo-cero-database-url"; replication { auto {} } }
resource "google_secret_manager_secret" "jwt_secret" { secret_id = "saldo-cero-jwt-secret"; replication { auto {} } }
resource "google_secret_manager_secret" "google_play_sa" { secret_id = "saldo-cero-google-play-sa"; replication { auto {} } }

resource "google_secret_manager_secret_iam_member" "runtime_database" { secret_id = google_secret_manager_secret.database_url.id; role = "roles/secretmanager.secretAccessor"; member = "serviceAccount:${google_service_account.runtime.email}" }
resource "google_secret_manager_secret_iam_member" "runtime_jwt" { secret_id = google_secret_manager_secret.jwt_secret.id; role = "roles/secretmanager.secretAccessor"; member = "serviceAccount:${google_service_account.runtime.email}" }
resource "google_secret_manager_secret_iam_member" "runtime_play" { secret_id = google_secret_manager_secret.google_play_sa.id; role = "roles/secretmanager.secretAccessor"; member = "serviceAccount:${google_service_account.runtime.email}" }

output "cloud_sql_connection_name" { value = google_sql_database_instance.postgres.connection_name }
output "redis_host" { value = google_redis_instance.cache.host }
output "pubsub_topic" { value = google_pubsub_topic.rtdn.name }
output "runtime_service_account" { value = google_service_account.runtime.email }
output "pubsub_push_service_account" { value = google_service_account.pubsub_push.email }
