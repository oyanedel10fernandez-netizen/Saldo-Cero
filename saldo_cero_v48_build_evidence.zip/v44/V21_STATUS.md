# SALDO CERO v21 — Billing worker, RTDN endpoint & production orchestration

## Added
- VersionCode 21 / versionName 21.0.0.
- Google Play transport abstraction for Subscriptions V2.
- Strict server product allow-list.
- RTDN Pub/Sub decoding + expected-package validation boundary.
- Billing worker orchestration with retry/idempotency rules.
- Unique RTDN event-id index.
- Android entitlement refresh policy for app start, purchase, restore and manual refresh.

## Production architecture
Google Play
-> RTDN / Pub/Sub
-> authenticated RTDN endpoint
-> idempotent billing worker
-> Google Play Subscriptions V2 verification
-> atomic PostgreSQL transaction
-> server-owned entitlement
-> Android GET /v1/entitlement

A scheduled reconciliation job remains the backstop for missed notifications.

## Security
- Service-account secrets remain runtime-only.
- Raw purchase tokens must never be logged.
- Pub/Sub push authentication must be verified before processing.
- The expected Android package name must be enforced.
- RTDN is a trigger to reconcile; Google Play V2 verification is the source of truth.
- A Pub/Sub message is acknowledged only after durable DB commit.

## Environment limitation
V21 is source code and production architecture. This workspace does not contain
the user's Google Cloud/Play credentials or a deployed Pub/Sub endpoint, so no
live Google Play transaction is claimed or simulated as real.

## Remaining
- Concrete authenticated Google OAuth2 transport implementation/configuration.
- Deployed RTDN endpoint + Pub/Sub.
- Real DB transaction repository.
- Scheduled worker runtime.
- Complete account security flows.
- Real AI provider and usage controls.
- Automated integration/security/load tests.
- Signed AAB and Play Console release.
- Chile privacy/legal review.
