# SALDO CERO V40 — Pipeline de producción

V40 convierte el diseño de V39 en una canalización más reproducible.

## Flujo
Terraform -> APIs/IAM/resources -> secrets references -> build -> registry -> Cloud Run -> migration gate -> readiness gate -> traffic.

## Seguridad
- WIF, no claves JSON de GitHub.
- Secret values fuera del repositorio.
- Cloud Run con service account dedicada.
- Pub/Sub push OIDC.
- Cloud SQL con backups/PITR.
- Docker image etiquetada por commit.
- Migraciones transaccionales.
- No se promociona tráfico si fallan gates.

## No conectado
Este paquete no ejecuta Terraform contra un proyecto real ni crea credenciales reales. Requiere configuración del propietario.
