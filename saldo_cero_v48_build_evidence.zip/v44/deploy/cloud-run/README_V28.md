# SALDO CERO V35 — Cloud Run

1. Crear un proyecto Google Cloud de producción.
2. Habilitar Cloud Run, Artifact Registry, Cloud SQL Admin, Secret Manager, Pub/Sub y Android Publisher API.
3. Crear una instancia Cloud SQL PostgreSQL y ejecutar `backend/MIGRATION_V35.sql`.
4. Crear secretos: `saldo-cero-database-url`, `saldo-cero-jwt-secret`, `saldo-cero-google-play-sa`.
5. Crear la cuenta de servicio `saldo-cero-api` y otorgarle acceso mínimo a Secret Manager y Cloud SQL.
6. Construir/publicar la imagen y desplegar `service.yaml.example` sustituyendo PROJECT_ID/REGION.
7. Configurar HTTPS y el dominio `api.saldocero.cl`.
8. Crear un tópico Pub/Sub para RTDN y una suscripción push hacia `/v1/webhooks/google-play/rtdn` con OIDC.
9. Configurar el mismo audience en `PUBSUB_AUDIENCE`.
10. Probar `/health`, `/ready`, login, compra sandbox y RTDN antes de producción.

## Seguridad obligatoria antes de publicar
- No subir `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` a Git.
- Preferir Secret Manager y rotación de secretos.
- Restringir Pub/Sub push con OIDC/audience y validar el JWT antes de procesar RTDN.
- Mantener Cloud SQL sin IP pública cuando sea posible y usar la conexión de Cloud Run/Cloud SQL.
- Configurar backups y point-in-time recovery.
