# SALDO CERO V38 — despliegue

V38 separa código y secretos. El repositorio contiene únicamente nombres de variables y referencias a secretos.

Orden recomendado:
1. Crear proyecto GCP y habilitar APIs.
2. Crear la cuenta de servicio de runtime con mínimo privilegio.
3. Crear Cloud SQL PostgreSQL.
4. Crear Redis/Memorystore y conectividad VPC.
5. Crear secretos en Secret Manager.
6. Configurar Pub/Sub RTDN con push OIDC hacia el endpoint.
7. Configurar Google Play Console + Google Play Developer API.
8. Ejecutar migraciones.
9. Construir y publicar la imagen.
10. Desplegar Cloud Run.
11. Ejecutar smoke tests y pruebas E2E de facturación.

No se incluye ninguna credencial real en V38.
