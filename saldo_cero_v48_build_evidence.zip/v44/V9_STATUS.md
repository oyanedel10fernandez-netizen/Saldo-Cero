# SALDO CERO v9 — Integration release

This release adds the Android account flow UI and API client contracts, plus the persistent PostgreSQL backend implementation from v8.

## User journey represented
1. Create account / sign in
2. Enter the app
3. View debts
4. Add debt
5. Select payment strategy
6. Use the AI gateway
7. View PRO subscription

## Current limitation
The Android UI's login/debt screens are still demo-connected; the interface and API contracts are ready, but the HTTP implementation and secure token storage are intentionally not bundled as production code. The backend is a runnable PostgreSQL-backed foundation when configured.

Before public launch:
- implement Retrofit/OkHttp repository and secure token storage
- refresh-token rotation
- email verification and password reset
- connect every Android screen to API
- run database migrations
- real AI provider
- verified Google Play billing
- security/penetration tests
- Chile privacy/legal review
