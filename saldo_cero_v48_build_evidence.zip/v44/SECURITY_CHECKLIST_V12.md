# V12 security checklist

[ ] Set a long random JWT_SECRET in production.
[ ] Use HTTPS only.
[ ] Disable Android cleartext traffic in release builds.
[ ] Put API keys only on the server.
[ ] Never log passwords or access tokens.
[ ] Add refresh tokens with rotation/revocation.
[ ] Add password recovery and email verification.
[ ] Add rate limiting to auth and assistant endpoints.
[ ] Add strict request validation and maximum payload sizes.
[ ] Run dependency and static security scans.
[ ] Configure PostgreSQL backups and least-privilege DB user.
[ ] Perform privacy/legal review for Chile before commercial launch.
