# V7 status
This is the first full-stack foundation: Android + a runnable Fastify API skeleton + PostgreSQL schema + Docker configuration.

The API currently has real HTTP routes and JWT auth, but its register/debt data store is intentionally in-memory in this package. PostgreSQL wiring is included for the next production integration; migrations and provider integrations still need implementation/testing.

Not production-ready until security review, persistent database implementation, refresh-token/session management, rate limits, privacy/legal review, payment verification and real AI gateway are completed.
