# Changelog V47

- Alineado Java source/target a JVM 21.
- Alineado Kotlin jvmTarget a 21.
- VersionCode/versionName: 47 / 47.0.0.
- Añadida verificación estática V47.
- Workflow CI renombrado a verify-build-v47.yml.
