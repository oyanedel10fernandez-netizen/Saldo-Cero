# SALDO CERO V35

V35 es la versión de preparación para despliegue real en Google Cloud.

Incluye verificación server-side de Google Play Subscriptions V2, OAuth2 Service Account, persistencia transaccional, Cloud Run, Cloud SQL, Secret Manager, Pub/Sub RTDN y plantillas Terraform.

**Estado:** código y configuración preparados; infraestructura real NO conectada desde este entorno.
