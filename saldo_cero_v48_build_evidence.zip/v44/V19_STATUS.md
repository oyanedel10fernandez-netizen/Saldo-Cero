# SALDO CERO v19 — Real Google Play verification integration boundary

## Added
- VersionCode 19 / versionName 19.0.0.
- Google Play Subscriptions V2 response normalization.
- Product allow-list for SALDO CERO Pro/Premium.
- Explicit lifecycle mapping: ACTIVE, CANCELED, EXPIRED, ON_HOLD,
  GRACE_PERIOD, REVOKED.
- Reconciliation transaction contract with idempotent billing events.
- RTDN event normalization boundary.
- Additive PostgreSQL lifecycle/audit fields and index.
- Android paid-access policy helper.

## Security rules
- Never grant Pro/Premium solely from BillingClient.
- Never log raw purchase tokens.
- Never store Google service-account private keys in the repository.
- Verify product IDs server-side.
- Update purchase + subscription + entitlement atomically.
- Treat RTDN as a trigger to reconcile, not as proof by itself.

## Important limitation
This source contains the real verification *business boundary and state mapping*,
but it does not contain live Google credentials or perform a production Google
API request in this environment. The deployment must connect the
GooglePlayHttpClient to an authenticated Google Play Developer API client.

## Remaining before production
- Authenticated Google Play Developer API client.
- RTDN Pub/Sub endpoint with push authentication validation.
- Scheduled reconciliation worker.
- Full DB transaction implementation.
- Refresh-token rotation/password recovery/email verification.
- Real AI provider + usage limits.
- Automated integration/security tests.
- Signed AAB + Play Console release.
- Chile privacy/legal review.
