# V35 — Database Migration Policy

Production migrations must be:
- versioned
- backward compatible where possible
- reviewed before deployment
- executed with a dedicated migration identity
- logged and auditable

Recommended order:
1. deploy additive schema
2. deploy application compatible with old/new schema
3. backfill if required
4. switch reads/writes
5. remove obsolete columns only in a later release

Never put database passwords in GitHub secrets when Secret Manager can be used by the runtime.
