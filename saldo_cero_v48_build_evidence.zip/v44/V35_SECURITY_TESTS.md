# V35 Security Tests
Rate limit multi-instancia; login/recovery throttling; OIDC válido y rechazos por issuer/firma/audience/service account/expiry; webhook no persiste eventos sin OIDC válido; secretos ausentes provocan readiness failure; request limits; auditoría; cero tokens/secretos en logs.
