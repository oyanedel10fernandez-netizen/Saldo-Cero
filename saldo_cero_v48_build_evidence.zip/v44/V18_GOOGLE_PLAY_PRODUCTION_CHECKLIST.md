# Google Play production checklist — V18

- [ ] Google Play app package registered.
- [ ] Products/subscriptions created and activated.
- [ ] Google Cloud project linked.
- [ ] Google Play Developer API enabled.
- [ ] Service account created with least privilege.
- [ ] Service account granted access in Play Console.
- [ ] Secret stored outside source control.
- [ ] Subscriptions V2 verification implemented.
- [ ] RTDN Pub/Sub topic + subscription configured.
- [ ] Push authentication validated.
- [ ] Idempotent event processing implemented.
- [ ] Scheduled reconciliation enabled.
- [ ] Entitlement downgrade rules tested.
- [ ] License testers configured.
- [ ] Internal/closed test track validated.
- [ ] Signed AAB built and uploaded.
