# SALDO CERO v12 — Security foundation

## Added
- Android Keystore-backed AES/GCM token encryption.
- Automatic Authorization header via OkHttp interceptor.
- Repository no longer passes JWT strings through every API method.
- Backend JWT secret is mandatory (fails closed if absent).
- Per-user password salt is stored in PostgreSQL.
- Version 12.0.0 / versionCode 12.
- Security-focused launch checklist.

## Still required before public release
- HTTPS production endpoint and disable cleartext traffic.
- Refresh-token rotation with revocation.
- Email verification and password reset.
- Argon2id (or another reviewed password hashing configuration) and migration from any development accounts.
- Database migration tooling.
- Rate limiting, request validation, audit logging and automated tests.
- Real AI provider with privacy/safety controls.
- Verified Google Play Billing.
- Chile-specific privacy/legal review.
- External security audit.

This package is source code, not a compiled APK.
