# SALDO CERO v15 — Google Play Billing foundation

## Added
- Google Play Billing Client dependency.
- BillingManager for subscription discovery, purchase flow and restore.
- Product IDs:
  - saldo_cero_pro_monthly
  - saldo_cero_premium_monthly
- Server verification boundary for purchase tokens.
- PostgreSQL billing purchase audit table.
- Subscription ViewModel foundation.
- V15 versionCode 15 / versionName 15.0.0.

## Critical security rule
A PURCHASED result from Android is not sufficient to grant paid access. The backend must verify the purchase token against Google Play before changing entitlement.

## Remaining for production
- Configure Play Console products and test track.
- Implement Google Play Developer API server verification.
- Handle subscription lifecycle/renewal/cancellation/expiration.
- Persist entitlements and idempotently process purchase tokens.
- Complete refresh tokens, password recovery/email verification.
- Real AI provider.
- Automated tests, monitoring and security audit.
- Chile privacy/legal review.
- Signed AAB build in a real Android environment.

Source code only; no compiled APK/AAB.
