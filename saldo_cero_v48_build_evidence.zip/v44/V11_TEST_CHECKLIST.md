# V11 smoke test

1. Start PostgreSQL with the V10 Docker setup.
2. Set DATABASE_URL and JWT_SECRET.
3. Start backend on port 8080.
4. In Android emulator, build/install the app.
5. Create a new account.
6. Close/reopen the app and confirm session persists.
7. Add a debt and confirm it appears after reload.
8. Delete the debt and confirm it disappears.
9. Run Avalancha and Bola de nieve and confirm priority changes.
10. Ask the assistant and confirm the gateway response.
11. Verify the debt exists in PostgreSQL.
