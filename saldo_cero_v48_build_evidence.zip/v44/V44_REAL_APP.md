# SALDO CERO V44 — APP REAL / INTEGRACIÓN

V44 corrige bloqueos de V43 y conecta la aplicación Android con el backend para autenticación, deudas, cálculo de plan y asistente. También incluye BillingClient y almacenamiento seguro de tokens.

## Corregido
- Import faltante `createHash` en backend.
- Refresh token y reset de contraseña permanecen server-side.
- Recuperación de contraseña preparada para proveedor de email mediante variables de entorno; nunca se guardan claves en la APK.
- Android ya no usa deudas demo: carga datos de `/v1/debts`.
- Login/registro reales contra API.
- Alta de deuda real y recarga de datos.
- Plan real contra `/v1/plans/calculate`.
- Asistente real contra `/v1/assistant/message`.
- Tokens access/refresh protegidos con Android Keystore.
- BillingClient 7.1.1 y compra/restauración preparados; la concesión sigue dependiendo de verificación server-side.

## Aún requiere infraestructura externa
- Ejecutar `npm ci` y `npm run build` en un entorno con acceso a npm.
- Android SDK/Gradle para generar y verificar AAB.
- PostgreSQL/Redis reales y migraciones.
- Google Cloud/Cloud Run/Secret Manager/PubSub.
- Credenciales Google Play en Secret Manager.
- Proveedor de email y AI.
- Pruebas reales de Google Play Billing y RTDN.

No se incluyen credenciales reales y no se afirma conexión con producción.
