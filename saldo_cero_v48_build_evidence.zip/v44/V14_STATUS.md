# SALDO CERO v14 — Commercial product foundation

## Added
- Profile API and profile model (name + currency).
- Subscription status API and purchase-verification contract.
- Release build API URL configuration.
- Release manifest disables cleartext HTTP.
- Commercial state model.
- V14 versionCode 14 / versionName 14.0.0.
- Database support for profile fields.
- Purchase verification intentionally fails closed until Google Play server verification is implemented.

## Product flow
Account -> Profile -> Debts -> Plan -> Assistant -> Subscription.

## Before public launch
- Implement Google Play Billing client + server-side purchase verification.
- Implement refresh-token rotation and password recovery.
- Production HTTPS, domain, certificates and secrets.
- Real AI provider with privacy/safety controls.
- Automated tests and crash/observability stack.
- Chile-specific privacy/legal review.

Source code only; no compiled APK.
