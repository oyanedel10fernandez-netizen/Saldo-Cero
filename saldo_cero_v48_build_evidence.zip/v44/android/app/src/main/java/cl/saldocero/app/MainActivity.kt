package cl.saldocero.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun money(cents:Long) = "$" + String.format("%,d", cents/100).replace(",", ".")

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}
}

@Composable fun App(){
 val ctx=androidx.compose.ui.platform.LocalContext.current
 val scope=rememberCoroutineScope(); val nav=rememberNavController()
 var access by remember{mutableStateOf(SecureSession.access(ctx))}; var error by remember{mutableStateOf("")}
 if(access==null){AuthScreen({e,p->scope.launch{runCatching{withContext(Dispatchers.IO){ApiClient.login(e,p)}}.onSuccess{SecureSession.save(ctx,it.access,it.refresh);access=it.access}.onFailure{error=it.message?"Error de conexión":it.message!!}}},{e,p->scope.launch{runCatching{withContext(Dispatchers.IO){ApiClient.register(e,p)}}.onSuccess{SecureSession.save(ctx,it.access,it.refresh);access=it.access}.onFailure{error=it.message?"No se pudo crear la cuenta":it.message!!}}},error)}
 else Scaffold(bottomBar={NavigationBar{listOf("Inicio" to "home","Deudas" to "debts","Plan" to "plan","IA" to "ai","Perfil" to "profile").forEach{(t,r)->NavigationBarItem(nav.currentDestination?.route==r,{nav.navigate(r)},icon={Text(t.take(1))},label={Text(t)})}}}){p->NavHost(nav,"home",Modifier.padding(p)){composable("home"){Home(access!!)};composable("debts"){Debts(access!!)};composable("plan"){Plan(access!!)};composable("ai"){AI(access!!)};composable("profile"){Profile{SecureSession.clear(ctx);access=null}}}}
}

@Composable fun AuthScreen(login:(String,String)->Unit,register:(String,String)->Unit,error:String){var e by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var create by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){Text("SALDO CERO",style=MaterialTheme.typography.headlineLarge);Text(if(create)"Crear cuenta" else "Iniciar sesión");Spacer(Modifier.height(16.dp));OutlinedTextField(e,{e=it},Modifier.fillMaxWidth(),label={Text("Correo")});OutlinedTextField(p,{p=it},Modifier.fillMaxWidth(),label={Text("Contraseña")});Spacer(Modifier.height(12.dp));Button({if(create)register(e,p)else login(e,p)},Modifier.fillMaxWidth()){Text(if(create)"Crear cuenta" else "Entrar")};TextButton({create=!create}){Text(if(create)"Ya tengo cuenta" else "Crear cuenta")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}}

@Composable fun Home(token:String){var debts by remember{mutableStateOf<List<DebtDto>>(emptyList())};var msg by remember{mutableStateOf("Cargando…")};LaunchedEffect(token){runCatching{withContext(Dispatchers.IO){ApiClient.debts(token)}}.onSuccess{debts=it;msg=""}.onFailure{msg="No se pudieron cargar tus datos: ${it.message}"}};Column(Modifier.padding(20.dp)){Text("SALDO CERO",style=MaterialTheme.typography.headlineLarge);Spacer(Modifier.height(16.dp));Card{Column(Modifier.padding(20.dp)){Text("Deuda total");Text(money(debts.sumOf{it.balanceCents}),style=MaterialTheme.typography.headlineMedium);Text("${debts.size} deudas")}};if(msg.isNotBlank())Text(msg)}}

@Composable fun Debts(token:String){val scope=rememberCoroutineScope();var debts by remember{mutableStateOf<List<DebtDto>>(emptyList())};var name by remember{mutableStateOf("")};var balance by remember{mutableStateOf("")};var payment by remember{mutableStateOf("")};var rate by remember{mutableStateOf("")};LaunchedEffect(Unit){runCatching{withContext(Dispatchers.IO){ApiClient.debts(token)}}.onSuccess{debts=it}};Column(Modifier.padding(16.dp)){Text("Mis deudas",style=MaterialTheme.typography.headlineMedium);OutlinedTextField(name,{name=it},label={Text("Nombre")},modifier=Modifier.fillMaxWidth());OutlinedTextField(balance,{balance=it},label={Text("Saldo $")},modifier=Modifier.fillMaxWidth());OutlinedTextField(payment,{payment=it},label={Text("Cuota $")},modifier=Modifier.fillMaxWidth());OutlinedTextField(rate,{rate=it},label={Text("Tasa anual %")},modifier=Modifier.fillMaxWidth());Button({val b=(balance.toDoubleOrNull()?:0.0)*100;val pay=(payment.toDoubleOrNull()?:0.0)*100;val r=(rate.toDoubleOrNull()?:0.0)*100;scope.launch{runCatching{withContext(Dispatchers.IO){ApiClient.addDebt(token,name,b.toLong(),pay.toLong(),r.toInt());ApiClient.debts(token)}}.onSuccess{debts=it;name="";balance="";payment="";rate=""}}}){Text("Agregar deuda")};LazyColumn{items(debts,key={it.id}){d->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(16.dp)){Text(d.name,style=MaterialTheme.typography.titleLarge);Text("Saldo ${money(d.balanceCents)}");Text("Cuota ${money(d.paymentCents)}");Text("Tasa ${d.annualRateBps/100.0}%")}}}}}}

@Composable fun Plan(token:String){var avalanche by remember{mutableStateOf(true)};var result by remember{mutableStateOf("Selecciona una estrategia")};val scope=rememberCoroutineScope();Column(Modifier.padding(16.dp)){Text("Plan de pago",style=MaterialTheme.typography.headlineMedium);Row{FilterChip(avalanche,{avalanche=true},label={Text("Avalancha")});Spacer(Modifier.width(8.dp));FilterChip(!avalanche,{avalanche=false},label={Text("Bola de nieve")})};Button({scope.launch{runCatching{withContext(Dispatchers.IO){ApiClient.plan(token,if(avalanche)"AVALANCHE"else"SNOWBALL",0)}}.onSuccess{result=it.toString()}.onFailure{result="Error: ${it.message}"}}}){Text("Calcular plan")};Text(result)}}

@Composable fun AI(token:String){var q by remember{mutableStateOf("")};var answer by remember{mutableStateOf("")};val scope=rememberCoroutineScope();Column(Modifier.padding(16.dp)){Text("Asistente IA",style=MaterialTheme.typography.headlineMedium);OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Pregunta")});Spacer(Modifier.height(8.dp));Button({scope.launch{runCatching{withContext(Dispatchers.IO){ApiClient.assistant(token,q)}}.onSuccess{answer=it.optString("message")}.onFailure{answer="Error: ${it.message}"}}}){Text("Enviar")};Spacer(Modifier.height(12.dp));Text(answer)}}

@Composable fun Profile(logout:()->Unit){
 val activity=androidx.compose.ui.platform.LocalContext.current as? android.app.Activity
 var billing by remember{mutableStateOf<BillingManager?>(null)}
 var status by remember{mutableStateOf("Conectando con Google Play…")}
 LaunchedEffect(activity){if(activity!=null){billing=BillingManager(activity){product,token->status="Compra recibida: $product. Verificación en servidor pendiente."};billing?.connect{status="Google Play disponible"};billing?.restore()}}
 Column(Modifier.padding(16.dp)){Text("Cuenta",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));Text("SALDO CERO PRO / PREMIUM");Text(status);Spacer(Modifier.height(8.dp));Button({billing?.buy("saldo_cero_pro_monthly")}){Text("Pro $9.990/mes")};Button({billing?.buy("saldo_cero_premium_monthly")}){Text("Premium $14.990/mes")};Spacer(Modifier.height(16.dp));Button(logout){Text("Cerrar sesión")};Text("La app nunca concede acceso pagado solo por la compra local: el servidor valida el token con Google Play.")}
}
