package cl.saldocero.app

import android.app.Activity
import com.android.billingclient.api.*

class BillingManager(private val activity:Activity, private val onPurchaseToken:(String,String)->Unit): PurchasesUpdatedListener {
 private val client=BillingClient.newBuilder(activity).setListener(this).enablePendingPurchases().build()
 fun connect(onReady:()->Unit={}){client.startConnection(object:BillingClientStateListener{override fun onBillingSetupFinished(r:BillingResult){if(r.responseCode==BillingClient.BillingResponseCode.OK)onReady()};override fun onBillingServiceDisconnected(){}})}
 fun buy(productId:String){client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(BillingClient.ProductType.SUBS).build())).build(), object: ProductDetailsResponseListener {
  override fun onProductDetailsResponse(r:BillingResult,result:QueryProductDetailsResult){if(r.responseCode==BillingClient.BillingResponseCode.OK){val d=result.productDetailsList.firstOrNull();if(d!=null){val offer=d.subscriptionOfferDetails?.firstOrNull()?.offerToken?:return;client.launchBillingFlow(activity,BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).setOfferToken(offer).build())).build())}}}
 })}
 override fun onPurchasesUpdated(r:BillingResult,purchases:MutableList<Purchase>?){if(r.responseCode==BillingClient.BillingResponseCode.OK)purchases.orEmpty().forEach{if(it.purchaseState==Purchase.PurchaseState.PURCHASED){if(!it.isAcknowledged)client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(it.purchaseToken).build(),null);onPurchaseToken(it.products.firstOrNull()?:return@forEach,it.purchaseToken)}}}
 fun restore(){client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()){r,p->if(r.responseCode==BillingClient.BillingResponseCode.OK)p.forEach{if(it.purchaseState==Purchase.PurchaseState.PURCHASED)onPurchaseToken(it.products.firstOrNull()?:return@forEach,it.purchaseToken)}}}
}
