package cl.saldocero.app
import android.content.Context
import android.util.Base64
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

object SecureSession {
 private const val PREF="saldo_cero_secure"; private const val ALIAS="saldo_cero_session"
 private fun prefs(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
 private fun key():SecretKey{
  val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
  (ks.getKey(ALIAS,null) as? SecretKey)?.let{return it}
  val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
  kg.init(KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
  return kg.generateKey()
 }
 private fun enc(v:String):String{val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());return Base64.encodeToString(c.iv+c.doFinal(v.toByteArray()),Base64.NO_WRAP)}
 private fun dec(v:String)=runCatching{val x=Base64.decode(v,Base64.NO_WRAP);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,x.copyOfRange(0,12)));String(c.doFinal(x.copyOfRange(12,x.size)),StandardCharsets.UTF_8)}.getOrNull()
 fun save(c:Context,a:String,r:String)=prefs(c).edit().putString("access",enc(a)).putString("refresh",enc(r)).apply()
 fun access(c:Context)=prefs(c).getString("access",null)?.let(::dec)
 fun refresh(c:Context)=prefs(c).getString("refresh",null)?.let(::dec)
 fun clear(c:Context)=prefs(c).edit().clear().apply()
}
