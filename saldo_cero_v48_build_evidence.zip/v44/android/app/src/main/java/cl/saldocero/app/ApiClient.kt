package cl.saldocero.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ApiSession(val access: String, val refresh: String)

data class DebtDto(val id:String,val name:String,val balanceCents:Long,val paymentCents:Long,val annualRateBps:Int)

object ApiClient {
    private fun call(path:String, method:String, body:String?=null, token:String?=null):JSONObject {
        val c=URL(BuildConfig.API_BASE_URL.trimEnd('/')+path).openConnection() as HttpURLConnection
        c.requestMethod=method; c.connectTimeout=10000; c.readTimeout=15000
        c.setRequestProperty("Accept","application/json")
        if(token!=null)c.setRequestProperty("Authorization","Bearer $token")
        if(body!=null){c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(body.toByteArray())}}
        val code=c.responseCode; val stream=if(code in 200..299)c.inputStream else c.errorStream
        val text=stream?.bufferedReader()?.use{it.readText()} ?: "{}"
        if(code !in 200..299) throw IllegalStateException("HTTP $code: ${JSONObject(text).optString("error",text)}")
        return JSONObject(text)
    }
    fun login(e:String,p:String)=session(call("/v1/auth/login","POST",JSONObject(mapOf("email" to e,"password" to p)).toString()))
    fun register(e:String,p:String)=session(call("/v1/auth/register","POST",JSONObject(mapOf("email" to e,"password" to p)).toString()))
    private fun session(o:JSONObject)=ApiSession(o.getString("access_token"),o.getString("refresh_token"))
    fun refresh(r:String)=session(call("/v1/auth/refresh","POST",JSONObject(mapOf("refresh_token" to r)).toString()))
    fun debts(t:String):List<DebtDto>{
        val a=call("/v1/debts","GET",token=t).optJSONArray("debts")?:JSONArray();
        return (0 until a.length()).map{val x=a.getJSONObject(it);DebtDto(x.getString("id"),x.getString("name"),x.getLong("balance_cents"),x.getLong("payment_cents"),x.getInt("annual_rate_bps"))}
    }
    fun addDebt(t:String,name:String,balanceCents:Long,paymentCents:Long,annualRateBps:Int)=call("/v1/debts","POST",JSONObject(mapOf("name" to name,"balance_cents" to balanceCents,"payment_cents" to paymentCents,"annual_rate_bps" to annualRateBps)).toString(),t)
    fun deleteDebt(t:String,id:String)=call("/v1/debts/$id","DELETE",token=t)
    fun plan(t:String,strategy:String,extraCents:Long)=call("/v1/plans/calculate","POST",JSONObject(mapOf("strategy" to strategy,"extra_payment_cents" to extraCents)).toString(),t)
    fun assistant(t:String,q:String)=call("/v1/assistant/message","POST",JSONObject(mapOf("message" to q)).toString(),t)
    fun entitlement(t:String)=call("/v1/entitlement","GET",token=t)
}
