# SALDO CERO v6 — Backend + Android commercial foundation

V44 moves the project from a UI prototype toward a real product architecture.

Included:
- Android native client source
- Backend API contract
- PostgreSQL schema
- authentication flow specification
- debt/plan API
- AI gateway contract
- subscription contract
- security checklist
- deployment checklist

Important: external infrastructure is not provisioned by this ZIP. The code contains no production credentials and does not claim that cloud services, payments or AI are live.
