# Android V44

La aplicación ya consume la API para autenticación, deudas, plan y asistente. Los tokens se almacenan mediante Android Keystore. Google Play Billing está integrado y la concesión de acceso pagado sigue dependiendo de la verificación server-side.

API debug: `http://10.0.2.2:8080`
API release: `https://api.saldocero.cl`
