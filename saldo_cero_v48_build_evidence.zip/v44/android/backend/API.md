# V6 API contract

POST /v1/auth/register
POST /v1/auth/login
POST /v1/auth/refresh
DELETE /v1/account

GET /v1/me

GET /v1/debts
POST /v1/debts
PATCH /v1/debts/{id}
DELETE /v1/debts/{id}

POST /v1/plans/calculate
POST /v1/simulator

POST /v1/assistant/message

GET /v1/subscription
POST /v1/subscription/verify

All production requests use HTTPS and authenticated access where applicable.
