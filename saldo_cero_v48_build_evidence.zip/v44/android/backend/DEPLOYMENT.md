# Suggested production topology

Android -> HTTPS API -> application server -> PostgreSQL
                         |
                         +-> AI provider
                         +-> subscription provider

Recommended first deployment:
- managed PostgreSQL
- managed container/server
- HTTPS domain
- secret manager
- monitoring/error reporting

The exact providers can be selected later based on cost and Chile availability.
