CREATE TABLE users (
 id UUID PRIMARY KEY,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE debts (
 id UUID PRIMARY KEY,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 balance_cents BIGINT NOT NULL CHECK(balance_cents >= 0),
 payment_cents BIGINT NOT NULL CHECK(payment_cents >= 0),
 annual_rate_bps INTEGER NOT NULL CHECK(annual_rate_bps >= 0),
 due_day INTEGER,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE plans (
 id UUID PRIMARY KEY,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 strategy TEXT NOT NULL CHECK(strategy IN ('AVALANCHE','SNOWBALL')),
 extra_payment_cents BIGINT NOT NULL DEFAULT 0,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE subscriptions (
 id UUID PRIMARY KEY,
 user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 provider TEXT NOT NULL,
 external_id TEXT,
 status TEXT NOT NULL,
 renews_at TIMESTAMPTZ
);


CREATE TABLE IF NOT EXISTS billing_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_token_hash TEXT NOT NULL,
  event_type TEXT NOT NULL,
  event_id TEXT,
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(purchase_token_hash, event_type, event_id)
);

CREATE INDEX IF NOT EXISTS idx_billing_events_token
  ON billing_events(purchase_token_hash);


-- V19 lifecycle/audit fields (safe additive migration)
ALTER TABLE billing_purchases ADD COLUMN IF NOT EXISTS last_verified_at TIMESTAMPTZ;
ALTER TABLE billing_purchases ADD COLUMN IF NOT EXISTS lifecycle_state TEXT;
ALTER TABLE billing_purchases ADD COLUMN IF NOT EXISTS last_event_id TEXT;

CREATE INDEX IF NOT EXISTS idx_billing_purchases_lifecycle
  ON billing_purchases(lifecycle_state);



-- V21: event idempotency key for RTDN/worker processing
CREATE UNIQUE INDEX IF NOT EXISTS idx_billing_events_unique_event
  ON billing_events(event_id)
  WHERE event_id IS NOT NULL;


-- V24: worker claim/lease support and operational replay
ALTER TABLE billing_jobs ADD COLUMN IF NOT EXISTS user_id UUID;
ALTER TABLE billing_jobs ADD COLUMN IF NOT EXISTS product_id TEXT;
ALTER TABLE billing_jobs ADD COLUMN IF NOT EXISTS purchase_token_encrypted TEXT;
CREATE INDEX IF NOT EXISTS idx_billing_jobs_lock
  ON billing_jobs(status,locked_at,next_attempt_at);

-- V25 billing worker lease / operational hardening
-- V25 billing worker lease
ALTER TABLE billing_jobs ADD COLUMN IF NOT EXISTS lease_expires_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_billing_jobs_lease
  ON billing_jobs(status,lease_expires_at);

-- Recover jobs whose worker/container died without completing them.
UPDATE billing_jobs
SET status='RETRY', locked_at=NULL, lease_expires_at=NULL,
    next_attempt_at=NOW(), updated_at=NOW()
WHERE status='PROCESSING'
  AND lease_expires_at IS NOT NULL
  AND lease_expires_at < NOW();
