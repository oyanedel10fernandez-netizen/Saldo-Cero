# Production security requirements

- HTTPS only
- Argon2id/bcrypt password hashing
- short-lived access tokens and rotated refresh tokens
- server-side validation
- rate limiting
- secrets in a secret manager
- no AI/payment secrets in Android
- encrypted database backups
- audit logging without sensitive payloads
- account deletion and data export
- dependency and penetration testing before launch
