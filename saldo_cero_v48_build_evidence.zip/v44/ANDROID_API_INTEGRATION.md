# Android ↔ API v8

Base URL should be configurable (debug/local vs production), never hard-coded to a secret.

Flow:
1. POST /v1/auth/register or /v1/auth/login
2. Store short-lived access token securely.
3. GET /v1/me
4. GET/POST/PATCH/DELETE /v1/debts
5. POST /v1/plans/calculate
6. POST /v1/assistant/message

For production Android:
- add an HTTP client such as OkHttp/Retrofit
- use HTTPS
- handle 401 and token refresh
- never log Authorization headers
- validate server responses
- add offline/error states
