# SALDO CERO V35 — Production Deployment Hardening

V35 is based on V28 and focuses on making the deployment path reproducible and safer.

## Added
- Cloud Run deployment manifest with environment/secret references.
- Cloud SQL migration/deployment guidance.
- Pub/Sub push authentication and service-account guidance.
- Secret Manager inventory.
- Production smoke-test and rollback checklist.
- Staging/production separation guidance.
- No real credentials, project IDs, database URLs, or secrets are embedded.

## Status
Architecture/configuration prepared. No external Google Cloud or production database is actually connected from this artifact.
