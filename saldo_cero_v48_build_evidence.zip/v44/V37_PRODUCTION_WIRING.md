# SALDO CERO V37 — production wiring

V37 is implementation-ready but contains NO real credentials.

## Services wired in code
- PostgreSQL / Cloud SQL: `DATABASE_URL`
- Redis / Memorystore: `REDIS_URL`
- Google Play Subscriptions V2: service-account JSON supplied through environment/secret injection
- Pub/Sub RTDN: OIDC bearer verification using `google-auth-library`
- Secret Manager: `GoogleSecretManagerProvider`
- Cloud Run: existing Docker/CI scaffolding can inject configuration at deploy time

## Required production configuration
`JWT_SECRET`, `DATABASE_URL`, `REDIS_URL`, `GOOGLE_PLAY_PACKAGE_NAME`, `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`, `PUBSUB_OIDC_AUDIENCE`, `PUBSUB_SERVICE_ACCOUNT`, `GCP_PROJECT_ID`.

Never commit values. Use a secret store and workload identity in the deployment environment.

## Database
Run `MIGRATION_V37.sql` once against the target database before starting the API.

## RTDN
Configure a Pub/Sub push subscription with OIDC authentication whose audience exactly equals `PUBSUB_OIDC_AUDIENCE` and whose service account exactly equals `PUBSUB_SERVICE_ACCOUNT`.

## Google Play
Create a service account with the minimum required Play Console/API permissions and inject its JSON at runtime. The app never decides entitlement; the backend verifies the purchase with Google Play.

## Local development
Copy `.env.example` to `.env`, use local PostgreSQL/Redis, and use test/staging Google credentials only when testing Google Play integration. Do not place production secrets in the repository.

## Production status
No service is claimed to be connected. The project is considered ready only after the deployment operator supplies real infrastructure and runs the release gates.
