# V16 billing architecture

Google Play
   |
   | purchase / renewal events
   v
Android BillingClient
   |
   | purchaseToken
   v
SALDO CERO API
   |
   | Google Play Developer API
   v
Google verification
   |
   v
PostgreSQL subscriptions + billing_purchases
   |
   v
GET /v1/entitlement
   |
   v
Android Pro/Premium access

Rules:
- Entitlements are server-owned.
- Purchase tokens are never logged.
- Store only a cryptographic fingerprint for audit/idempotency.
- Every purchase verification must be idempotent.
- Expired/revoked subscriptions must downgrade access.
