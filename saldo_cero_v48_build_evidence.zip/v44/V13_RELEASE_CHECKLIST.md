# V13 release checklist

AUTH
[ ] Login/register validation
[ ] Refresh rotation
[ ] Logout/revocation
[ ] Email verification
[ ] Password reset email

SECURITY
[ ] HTTPS only
[ ] No cleartext in release
[ ] Keystore-backed tokens
[ ] JWT secret from secret manager
[ ] Rate limiting
[ ] Audit/security tests

COMMERCIAL
[ ] Google Play product IDs
[ ] Billing verification server-side
[ ] Restore purchases
[ ] Subscription entitlement checks
[ ] Terms/privacy/consumer disclosures

PRODUCT
[ ] Empty states
[ ] Loading/error states
[ ] Offline behavior
[ ] Analytics with privacy controls
[ ] Accessibility
