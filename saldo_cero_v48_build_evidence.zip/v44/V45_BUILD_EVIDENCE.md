# SALDO CERO V45 — Build reproducible

## Objetivo
Obtener evidencia objetiva de que backend y Android compilan en un runner limpio.

## Backend
El workflow instala dependencias con `npm install`, ejecuta `npm run build` y `npm run verify:v44`. La evidencia se guarda como artifact `backend-pass-evidence`.

## Android / AAB
El workflow usa Java 21 y Gradle 8.7, ejecuta `clean assembleDebug` y `bundleRelease`. El AAB y su SHA-256 se guardan como artifact `saldo-cero-v45-aab`.

## Firma
La firma de release no incluye claves privadas en el repositorio. Para Google Play se debe usar un secreto/keystore protegido en CI o firmar el bundle fuera del repositorio.

## Criterio PASS
No se considera PASS por inspección estática. El PASS requiere que GitHub Actions termine el job correspondiente en verde y produzca el artifact.
