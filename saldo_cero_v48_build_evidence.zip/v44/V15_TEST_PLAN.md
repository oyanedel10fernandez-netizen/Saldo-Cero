# V15 test plan

1. Add Pro and Premium subscriptions in a Play Console test track.
2. Add license tester accounts.
3. Install the debug/internal-test build.
4. Confirm products load from Google Play.
5. Start a test purchase.
6. Confirm Android receives the purchase token.
7. Confirm the token is sent to the backend.
8. Confirm backend refuses to grant entitlement while verification is unconfigured.
9. After Google verification is implemented, verify entitlement is granted once.
10. Test restore purchases.
11. Test renewal, cancellation, expiration and duplicate purchase tokens.
