# SALDO CERO V46 — Build Fixes

V46 corrige los fallos reales detectados por GitHub Actions en V45.

## Backend
- Añade `@types/pg` para el tipado de PostgreSQL.
- Añade `zod`, requerido por `env-v38.ts`.
- Corrige imports ESM para NodeNext agregando `.js`.
- Corrige la ruta del `billing-store-v37` desde `billing/worker-v37.ts`.
- Evita el conflicto de tipos de Redis usando un límite de tipo runtime en el adaptador.

## Android
- Alinea Kotlin 1.9.25 con Compose Compiler 1.5.15.
- Añade `kotlinx-coroutines-android`.
- Incrementa versionCode/versionName a 46/46.0.0.

## Objetivo CI
1. Backend `npm install` + `npm run build` debe pasar.
2. Verificación estática debe pasar.
3. Android debe compilar debug.
4. Android debe generar el AAB release.

No se afirma PASS hasta ejecutar el workflow real en GitHub Actions.
