# V35 Release Checklist

- [ ] Google Cloud project selected
- [ ] Artifact Registry repository created
- [ ] Cloud Run runtime service account created
- [ ] GitHub OIDC/WIF configured
- [ ] Deployer IAM is least privilege
- [ ] Secret Manager secrets created
- [ ] Cloud SQL production database available
- [ ] Pub/Sub RTDN configured
- [ ] Database migrations reviewed/applied
- [ ] /health passes
- [ ] /ready passes with production dependencies
- [ ] Google Play server verification passes in controlled test
- [ ] RTDN -> queue -> worker -> entitlement tested
- [ ] Duplicate event tested
- [ ] Renewal/cancel/expiry/revoke tested
- [ ] Monitoring and alerts verified
- [ ] Rollback revision confirmed
- [ ] Android release build signed and tested separately

V35 does not contain or invent real credentials and does not claim a live deployment.
