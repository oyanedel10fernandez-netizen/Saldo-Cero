# V35 Production Security Gate
1. Rate limiter compartido desplegado.
2. OIDC Pub/Sub real y verificado.
3. Cloud Run Invoker restringido al service account de Pub/Sub.
4. Secret Manager activo.
5. Request limits activos.
6. Tests V33/V34/V35 pasan.
7. Alertas V31 activas.
8. IAM mínimo privilegio revisado.
9. Rollback ensayado.
