# V47 — Corrección JVM Android

V46 falló porque Java compilaba con JVM 1.8 mientras Kotlin compilaba con JVM 21.

V47 alinea ambos targets en Java/Kotlin 21 dentro de `android/app/build.gradle.kts`.

Objetivo del CI:
- Backend V47
- Android debug APK
- Android release AAB
- Verificación estática de Java/Kotlin JVM 21

No se incluyen credenciales ni conexiones reales de producción.
