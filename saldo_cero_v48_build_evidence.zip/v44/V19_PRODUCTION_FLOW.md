# V19 production flow

Google Play purchase
  -> Android BillingClient
  -> POST /v1/subscription/verify
  -> pending record (never grants entitlement)
  -> Google Play Subscriptions V2 server verification
  -> atomic DB transaction
  -> subscriptions + billing_purchases + entitlement
  -> Android GET /v1/entitlement

Renewal/cancel/hold/grace/expiry/revoke
  -> Google Play RTDN
  -> authenticated Pub/Sub handler
  -> reconcile by purchase token
  -> same atomic transaction
  -> updated entitlement

Scheduled reconciliation is the backstop for missed notifications.
