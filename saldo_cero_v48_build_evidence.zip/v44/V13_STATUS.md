# SALDO CERO v13 — Commercial & account foundation

## Added
- Stronger client-side validation for auth and debt forms.
- Secure session abstraction extended for refresh-token storage.
- API contracts for refresh, forgot-password and reset-password.
- PostgreSQL schema for refresh tokens and password-reset tokens.
- Commercial plan model: Gratis / Pro / Premium.
- Neutral forgot-password response to reduce account enumeration.
- V13 security and release checklist.

## Important
Refresh and password reset endpoints are intentionally returned as not enabled until the complete rotation/email-delivery flow is implemented. This avoids pretending these are production-ready.

## Before public release
- Implement refresh-token rotation + revocation.
- Implement email delivery and one-time password reset tokens.
- HTTPS only and release build configuration.
- Complete Google Play Billing verification.
- Real AI provider, privacy controls and moderation.
- Automated Android/API tests.
- Rate limiting, monitoring and security audit.
- Chile privacy/legal review.

Source code only; no compiled APK.
