# V14 launch plan

1. Configure `https://api.saldocero.cl/`.
2. Deploy PostgreSQL and API with managed secrets.
3. Run DB migrations.
4. Configure Google Play products for Pro and Premium.
5. Implement server-side purchase token verification.
6. Add restore purchases and entitlement checks.
7. Implement refresh-token rotation.
8. Implement email verification and password recovery.
9. Add automated Android/API tests.
10. Prepare privacy policy, terms and financial-education disclaimer.
11. Generate signed release bundle (AAB) in a real Android build environment.
12. Internal/closed testing on Google Play before production.
