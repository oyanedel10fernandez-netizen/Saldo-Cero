# SALDO CERO V37

Production-wiring release. The archive contains implementation and infrastructure templates, but no real credentials and no claim that any external production service is connected.

## Main commands
- `cd backend && npm ci`
- `npm run build`
- `npm run smoke:v37`
- `npm start`
- `npm run worker`

## Required deployment sequence
1. Create/select Google Cloud project.
2. Apply Terraform with real `project_id` and domain endpoint.
3. Add secret versions manually through Secret Manager.
4. Apply `MIGRATION_V37.sql` to the target PostgreSQL/Cloud SQL database.
5. Configure the Google Play service account and required Play Console/API access.
6. Configure Pub/Sub RTDN push and OIDC audience.
7. Deploy API and worker.
8. Run staging E2E/security tests.
9. Build/sign the Android AAB and verify Play billing against a test track.

Nothing in this archive performs those external actions automatically.
