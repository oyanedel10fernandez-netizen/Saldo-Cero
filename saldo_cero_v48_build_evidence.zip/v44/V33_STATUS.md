# SALDO CERO V35

## Añadido
- escenarios E2E críticos
- máquina de estados determinista para entitlement
- fixtures aisladas de producción
- auditoría de claves sensibles en objetos de prueba
- release gate para staging -> producción
- cobertura explícita de compras, RTDN, expiración, revocación, retries e idempotencia

## Estado
Suite preparada para ejecutarse en staging. La ejecución contra Google Play/Cloud reales requiere infraestructura y credenciales reales, que no están incluidas.
