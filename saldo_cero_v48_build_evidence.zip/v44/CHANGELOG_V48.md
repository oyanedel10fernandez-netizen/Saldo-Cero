# CHANGELOG V48

- Fixed GitHub Android build minimum Gradle version: 8.9.
- Fixed backend verifier path resolution.
- Bumped Android versionCode/versionName to 48 / 48.0.0.
- Added independent Backend and Android CI jobs.
- Android CI produces Debug APK and Release AAB artifacts.
