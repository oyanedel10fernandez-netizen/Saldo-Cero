# Changelog V46

- Fixed PostgreSQL TypeScript declarations.
- Added zod dependency.
- Fixed NodeNext `.js` imports.
- Fixed billing worker relative import.
- Stabilized Redis adapter typing.
- Aligned Kotlin with Compose Compiler 1.5.15.
- Added explicit Android coroutines dependency.
- Added V46 static verification and independent backend/Android CI jobs.
