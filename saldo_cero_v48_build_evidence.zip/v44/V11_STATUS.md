# SALDO CERO v11 — End-to-end integration

V11 connects the Android UI to the V10 backend contracts.

## Working source flow
Android login/register -> JWT session -> API -> PostgreSQL
Android load debts -> GET /v1/debts
Android add debt -> POST /v1/debts
Android delete debt -> DELETE /v1/debts/:id
Android plan -> POST /v1/plans/calculate
Android assistant -> POST /v1/assistant/message

## Local development
Android emulator should use `http://10.0.2.2:8080/`.
For a real device, replace `ApiProvider.BASE_URL` with the computer's LAN IP and keep the API reachable on the same network.

## Important production work remaining
- HTTPS only; remove cleartext traffic.
- Replace SharedPreferences token storage with Android Keystore-backed encrypted storage.
- Refresh-token rotation, email verification and password recovery.
- Replace demo scrypt salt with a per-user secure password-hashing scheme such as Argon2id.
- Replace development JWT fallback with a required secret.
- Add DB migrations, tests, rate limiting, observability.
- Real AI provider and safety/privacy layer.
- Google Play Billing verification.
- Chile privacy/legal review.

This package is source code. It is not a compiled APK.
