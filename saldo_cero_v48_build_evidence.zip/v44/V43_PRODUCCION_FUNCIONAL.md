# V43 — SALDO CERO PRODUCCIÓN FUNCIONAL
Base: V42 HUB resiliente.

Implementado:
- API Android conectable por HTTP(S) con URL debug/release.
- Registro/login real contra backend.
- Sesión cifrada con Android Keystore.
- Billing Client 7.1.1 incluido para compras.
- Backend refresh token con rotación/revocación.
- Reset de contraseña por token de un solo uso.
- Gateway IA server-side configurable; la clave no va en APK.
- Migración 040 de autenticación.
- Runner de migraciones ordenadas con schema_migrations.
- HUB V42 conservado para diagnóstico por etapas.

Requiere fuera del ZIP:
Google Cloud/Cloud Run/Cloud SQL/Redis/Pub/Sub, Google Play Console y service account, secretos, dominio HTTPS, proveedor de correo y proveedor IA. No se incluyen credenciales reales.
