# V21 Google Cloud setup

- Enable Google Play Developer API in the Google Cloud project.
- Create a service account.
- Grant only the permissions needed to read subscription state.
- Store the JSON credential in a secret manager.
- Create a Pub/Sub topic and subscription for RTDN.
- Configure Play Console real-time developer notifications.
- Protect the Pub/Sub push endpoint with authenticated push/JWT validation.
- Configure retry/dead-letter behavior.
- Monitor verification failures, RTDN lag, reconciliation backlog and entitlement mismatches.
