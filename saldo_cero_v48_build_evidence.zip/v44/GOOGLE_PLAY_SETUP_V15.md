# Google Play setup — V15

Create two subscription products in Play Console:
- saldo_cero_pro_monthly
- saldo_cero_premium_monthly

The Android app now queries and launches Google Play Billing for subscriptions.
Purchase entitlement must NOT be trusted from the client alone. The purchase token must be sent to the backend and verified with Google Play Developer API before granting Pro/Premium.

Use a Play Console test track and license testers before production.
