# V35 Alert & Incident Runbook
## Billing
Revisar logs estructurados -> correlación/event ID -> Google Play API -> Cloud SQL -> cola. Reprocesar solo trabajos idempotentes.
## RTDN
Revisar backlog Pub/Sub -> OIDC -> permisos -> 4xx/5xx -> replay seguro.
## DB
Revisar conexiones/queries; ajustar concurrencia. No borrar auditoría de billing.
## Rollback
Volver a la revisión anterior de Cloud Run y luego reconciliar la cola.
