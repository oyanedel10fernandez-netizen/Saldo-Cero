# SALDO CERO v24 — Production billing worker

## New in V24
- Worker orchestration that claims durable jobs, verifies Google Play purchases,
  atomically applies verified entitlements and completes/retries/dead-letters jobs.
- Queue/provider interfaces keep the worker deployable with PostgreSQL + a
  managed queue or an in-process scheduler.
- Operational billing health and dead-job replay contracts.
- Queue lease/index support in PostgreSQL.
- Android versionCode 24 / versionName 24.0.0.

## Safety
- Entitlements are granted only from server-side verification.
- Job processing is designed to be idempotent through event IDs.
- Raw purchase tokens must not appear in logs.
- Admin operations require authenticated/authorized backend routes.

## Still required before production
1. Implement the actual PostgreSQL repository/pool methods.
2. Connect the Google Play Developer API transport with a service account stored
   in secret management.
3. Deploy RTDN through Google Cloud Pub/Sub.
4. Run this worker as a managed process/container.
5. Add admin authentication/RBAC and replay UI/API.
6. Execute integration tests against staging Google Play + PostgreSQL.
7. Finish password reset/email verification, real AI, billing analytics,
   security audit, privacy/terms review and signed Play release.

V24 is production-shaped source architecture, not a claim of live deployment.
