CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE users ADD COLUMN IF NOT EXISTS password_salt TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS display_name TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS currency TEXT NOT NULL DEFAULT 'CLP';

CREATE TABLE IF NOT EXISTS billing_purchases (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 product_id TEXT NOT NULL, purchase_token_hash TEXT UNIQUE NOT NULL, purchase_state TEXT NOT NULL,
 verified_at TIMESTAMPTZ, expires_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS billing_jobs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), event_id TEXT UNIQUE, user_id UUID REFERENCES users(id) ON DELETE SET NULL,
 product_id TEXT, purchase_token TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING', attempts INTEGER NOT NULL DEFAULT 0,
 locked_at TIMESTAMPTZ, lease_expires_at TIMESTAMPTZ, next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT now(), last_error TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS product_id TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS ux_subscriptions_user_provider_external ON subscriptions(user_id,provider,external_id);
CREATE TABLE IF NOT EXISTS billing_events (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), purchase_token_hash TEXT NOT NULL, event_type TEXT NOT NULL,
 event_id TEXT UNIQUE, event_time_millis TEXT, notification_type INTEGER, notification_name TEXT, package_name TEXT,
 processed_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_billing_jobs_claim ON billing_jobs(status,next_attempt_at,created_at);
CREATE INDEX IF NOT EXISTS idx_billing_jobs_lease ON billing_jobs(status,lease_expires_at);
CREATE INDEX IF NOT EXISTS idx_billing_events_token ON billing_events(purchase_token_hash);

-- Repair legacy rows before enforcing the salt requirement.
UPDATE users SET password_salt=encode(gen_random_bytes(16),'hex') WHERE password_salt IS NULL;
ALTER TABLE users ALTER COLUMN password_salt SET NOT NULL;
