# V35 — checklist de despliegue

[ ] Google Cloud project creado
[ ] Billing habilitado
[ ] APIs habilitadas
[ ] Cloud SQL PostgreSQL creado
[ ] MIGRATION_V35.sql ejecutada
[ ] Artifact Registry creado
[ ] Imagen API publicada
[ ] Secret Manager configurado
[ ] Service Account Google Play creado con permisos mínimos
[ ] Google Play Developer API habilitada
[ ] RTDN topic + subscription creados
[ ] Pub/Sub push OIDC configurado
[ ] Cloud Run desplegado
[ ] api.saldocero.cl con HTTPS
[ ] /health y /ready OK
[ ] compra sandbox verificada server-side
[ ] RTDN de renovación/cancelación/expiración probado
[ ] backups/PITR revisados
[ ] logs/alertas revisados
