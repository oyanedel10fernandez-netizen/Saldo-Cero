# SALDO CERO V42 — HUB RESILIENTE

## Objetivo
Regenerar el proceso de preparación para producción evitando el problema anterior en el que el proceso terminaba a los pocos segundos ante un fallo inicial.

## Cambio principal
Se incorpora un HUB de orquestación que:
- ejecuta etapas independientes;
- captura errores por etapa;
- continúa con las verificaciones que todavía pueden ejecutarse;
- registra duración, estado, resumen y detalle;
- produce un resultado final `READY`, `PARTIAL` o `BLOCKED`;
- no convierte un fallo parcial en una falsa afirmación de que producción está lista.

## Etapas
Integridad → dependencias → TypeScript → Android → SQL → Cloud SQL → Redis → Google Play → RTDN → Cloud Run → seguridad → E2E → observabilidad → release gate.

## Importante
El HUB es infraestructura de proceso. No crea credenciales reales ni conecta automáticamente Google Cloud, Google Play, Pub/Sub, Redis o Cloud SQL. Las comprobaciones reales deben ejecutarse con el entorno de staging/producción autorizado.

## Regla de salida
`READY` solo puede declararse cuando no existan fallos críticos. Si una etapa falla, el resultado conserva el fallo y continúa con las etapas independientes.
