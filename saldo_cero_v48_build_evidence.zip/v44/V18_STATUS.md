# SALDO CERO v18 — Billing lifecycle, RTDN & reconciliation foundation

## Included
- VersionCode 18 / versionName 18.0.0.
- Google Play Subscriptions V2 integration boundary.
- Configuration checks for package/service-account credentials.
- Protected reconciliation worker contract.
- RTDN / Pub/Sub event contract.
- Billing event audit/idempotency table.
- Android billing lifecycle UI model.
- Entitlement remains server-owned.

## Production configuration still required
The source intentionally does NOT contain Google credentials and does NOT pretend
to call Google Play from this build. Before production:
1. Create/configure a Google Cloud service account with least-privilege Play
   Developer API access.
2. Store credentials in a secret manager.
3. Implement the authenticated Subscriptions V2 HTTP call.
4. Configure Google Play RTDN through Cloud Pub/Sub.
5. Validate Pub/Sub push authentication.
6. Atomically reconcile purchase + subscription + entitlement.
7. Run scheduled reconciliation as a backstop.
8. Test renewal, grace, hold, cancel, expiry, revoke and duplicate events.

## Security
- Never log raw purchase tokens.
- Persist only cryptographic token fingerprints where possible.
- Do not grant paid entitlement based solely on Android BillingClient state.
- Keep service-account credentials out of the repository.
