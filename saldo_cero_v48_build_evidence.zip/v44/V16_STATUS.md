# SALDO CERO v16 — Entitlements & billing backend foundation

## Added
- Google Play purchase acknowledgement in Android.
- Server-owned entitlement endpoint.
- Purchase-token SHA-256 fingerprint storage for idempotency/audit.
- PRO/PREMIUM product mapping boundary.
- PostgreSQL subscription product_id support.
- Dedicated Google Play verifier service contract.
- Entitlement ViewModel.
- V16 versionCode 16 / versionName 16.0.0.

## Security model
Android reports the purchase token -> backend records it -> backend verifies with Google Play Developer API -> backend updates subscription -> Android reads entitlement.

V16 intentionally does NOT grant paid access from the client-side purchase result.

## Still required
- Configure Google Play Developer API/service account.
- Implement the verifier using Google Play Developer API.
- Process renewals, grace period, account hold, cancellation and revocation.
- Scheduled reconciliation/webhook-like RTDN processing.
- Complete refresh-token/password-recovery flows.
- Real AI provider.
- Automated tests, monitoring, security audit.
- Signed AAB in an Android build environment.
- Chile privacy/legal review.

Source code only; no compiled APK/AAB.
