# V35 Production Readiness Gate

Antes de activar producción real deben existir:
1. Proyecto Google Cloud dedicado.
2. Cloud SQL de producción con migraciones aplicadas y backup/PITR.
3. Pub/Sub + DLQ + OIDC push configurados.
4. Cuenta de servicio con mínimo privilegio.
5. Google Play service account con permisos mínimos.
6. Secrets en Secret Manager, no en GitHub ni en código.
7. Cloud Run con service account dedicada.
8. Alertas de V31 activas.
9. Staging probado con sandbox/test purchases.
10. Rollback probado.

**Regla:** una build puede estar "production-shaped" sin estar "production-connected". V35 no afirma conexiones reales.
