# SALDO CERO V35 — Observabilidad
- Logs JSON compatibles con Cloud Logging.
- Correlation/request IDs.
- Métricas para HTTP, billing, RTDN y entitlements.
- Salud de la cola de billing.
- Guía de Cloud Monitoring y alertas.

Nunca registrar contraseñas, JWT/access/refresh tokens, claves privadas, headers Authorization ni tokens de compra de Google Play.
Alertas iniciales: HTTP 5xx, p95, trabajos billing fallidos, antigüedad de cola >15 min, backlog Pub/Sub y presión de Cloud SQL.
