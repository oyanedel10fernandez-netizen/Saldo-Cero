# V21 billing test matrix

1. PURCHASED -> server verifies -> ACTIVE entitlement.
2. Duplicate purchase verification -> one purchase record.
3. RTDN RENEWED -> reconcile -> expiry updated.
4. RTDN CANCELED -> reconcile -> policy state updated.
5. RTDN GRACE -> reconcile -> grace state.
6. RTDN ON_HOLD -> reconcile -> hold state.
7. RTDN EXPIRED -> entitlement removed.
8. RTDN REVOKED -> entitlement removed.
9. Invalid package -> reject.
10. Invalid product -> reject.
11. Invalid Pub/Sub payload -> reject/retry.
12. Duplicate eventId -> no duplicate billing event.
13. Google API temporary failure -> retry, do not acknowledge early.
14. DB transaction failure -> retry, no partial entitlement.
15. Android purchase -> refresh server entitlement.
16. Restore purchase -> refresh server entitlement.
