# SALDO CERO v27 — Producción Google Play / Cloud / PostgreSQL

## Qué incorpora
- OAuth2 real con service account para Google Play Developer API (Subscriptions V2).
- Cliente server-side para consultar una suscripción por purchase token.
- Endpoint Fastify para RTDN vía Google Cloud Pub/Sub.
- Validación de packageName y deduplicación por eventId.
- Auditoría RTDN en PostgreSQL y cola durable de billing.
- Variables de entorno de producción separadas; secretos fuera del repositorio.
- Migración V27 para `billing_events` y `billing_jobs`.
- Base preparada para Cloud SQL PostgreSQL con `sslmode=require`.
- Versionado Android 27.0.0.

## Lo que sigue SIN estar conectado
No contiene credenciales reales, proyecto Google Cloud real, tópico/subscripción Pub/Sub real, Cloud SQL real ni dominio desplegado. Por seguridad, el ZIP no incluye secretos.

## Activación real pendiente
1. Crear proyecto Google Cloud y habilitar Android Publisher API + Pub/Sub.
2. Crear service account con permisos mínimos para Google Play Developer API.
3. Configurar `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` como secreto del runtime.
4. Crear tópico y push subscription hacia `/v1/webhooks/google-play/rtdn`, con OIDC.
5. Crear Cloud SQL PostgreSQL, aplicar `schema.sql` + `MIGRATION_V27.sql` y configurar `DATABASE_URL`.
6. Desplegar API HTTPS y configurar `PUBSUB_AUDIENCE`.
7. Probar compra, renovación, cancelación, gracia, suspensión y expiración en Play Console.
