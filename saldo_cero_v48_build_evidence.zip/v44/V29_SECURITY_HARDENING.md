# V35 Security Hardening

- Secrets are externalized; do not place credentials in source control.
- Production database should not be publicly reachable.
- Cloud Run ingress should be restricted to intended traffic paths.
- RTDN push requests should require authenticated OIDC tokens and validate issuer/audience/service account.
- Billing events must be idempotent.
- Purchase tokens must not be trusted as proof of entitlement until server verification succeeds.
- Logs must not contain raw purchase tokens, authorization headers, passwords or private keys.
- Use separate staging and production Google Play/Cloud resources where possible.
- Rotate credentials and service-account keys according to operational policy.
