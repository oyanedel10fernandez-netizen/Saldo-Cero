# SALDO CERO V35 — Security Hardening

## Added
- rate-limit contract for auth/public endpoints
- security response headers
- Pub/Sub OIDC webhook verification boundary
- audit-event contract
- explicit least-privilege/security gate

## Production requirements
Rate limiting must use a shared store in Cloud Run; in-memory limits are not sufficient.
Pub/Sub push must validate the Google-signed OIDC JWT: signature, issuer, audience and authorized service account.
Secrets belong in Secret Manager.
Never trust Android purchase state for entitlement.
