# SALDO CERO V35 — Staging e Integración

## Objetivo
Validar el flujo completo antes de conectar tráfico de producción real.

### Smoke
- `/health` responde OK.
- `/ready` confirma DB + configuración Google Play.
- registro/login funcionan.
- CRUD de deudas funciona por usuario.
- cálculo de plan funciona.
- entitlement se obtiene con sesión válida.

### Billing
- compra PRO/PREMIUM de prueba llega al backend.
- token no se confía directamente desde Android.
- Google Play V2 se consulta desde servidor.
- compra verificada se persiste de forma idempotente.
- expiración/revocación elimina acceso pagado.
- repetición del mismo evento no duplica entitlement.

### RTDN
- payload válido se acepta.
- paquete incorrecto se rechaza.
- evento duplicado no genera doble procesamiento.
- Pub/Sub retry termina en DLQ/dead-job según política.

### Seguridad
- secretos no aparecen en logs.
- endpoints privados requieren JWT.
- webhook requiere autenticación OIDC de Pub/Sub antes de producción.
- no hay credenciales reales dentro del repositorio.

## Criterio de salida
No desplegar a producción si falla cualquier prueba crítica o si `/ready` no valida las dependencias requeridas.
