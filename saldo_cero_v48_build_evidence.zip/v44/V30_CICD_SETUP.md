# V35 — CI/CD

V35 introduces a production deployment pipeline using GitHub Actions + Google Cloud Workload Identity Federation.

## Required GitHub variables
- GCP_PROJECT_ID
- GCP_REGION
- GCP_WIF_PROVIDER
- GCP_DEPLOYER_SERVICE_ACCOUNT

No long-lived Google service-account JSON key is required by the workflow.

## Pipeline
1. Checkout
2. npm install/test
3. Authenticate through OIDC/WIF
4. Build Docker image
5. Push to Artifact Registry
6. Deploy Cloud Run
7. Run /health smoke test

Configure database migrations as a separate controlled job before promotion; do not run destructive migrations automatically on every push.
