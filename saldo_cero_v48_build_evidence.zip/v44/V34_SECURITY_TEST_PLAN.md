# V35 Security Test Plan

### Authentication
- brute-force/login rate limit
- malformed JWT
- expired JWT
- cross-user resource access denied
- password reset abuse protection

### Webhook
- missing Authorization rejected
- invalid signature rejected
- wrong audience rejected
- wrong service account rejected
- valid Pub/Sub OIDC accepted
- duplicate event remains idempotent

### API
- security headers present
- payload size limits
- invalid input rejected
- sensitive values absent from logs
- rate-limit behavior deterministic

### Billing
- Android cannot grant entitlement directly
- Google Play verification remains server-side
- audit event generated for verification outcome
