# SALDO CERO V47

V47 corrige el bloqueo de compilación detectado en V46:
`compileDebugJavaWithJavac (1.8)` vs `compileDebugKotlin (21)`.

Estado:
- Corrección JVM 21 aplicada: sí
- Backend CI separado: sí
- Android APK CI: preparado
- Android AAB CI: preparado
- Credenciales/infraestructura real: no incluidas
- Ejecución CI real: pendiente de GitHub
