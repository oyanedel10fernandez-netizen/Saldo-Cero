# V48 FIXES

- Corregido el mínimo de Gradle del pipeline: 8.7 -> 8.9.
- Corregido `verify-v48.mjs` para localizar `android/app/build.gradle.kts` mediante una ruta absoluta derivada de `import.meta.url`.
- La verificación ya no depende de que Node se ejecute desde `backend/`.
- Android continúa con Java/Kotlin JVM target 21.
- La CI de Android mantiene APK Debug + AAB Release.
