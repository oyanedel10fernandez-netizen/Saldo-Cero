# SALDO CERO v8
The backend now has persistent PostgreSQL-backed user/debt routes when DATABASE_URL is configured, plus SQL schema and Docker setup.

The Android client remains a native foundation and includes the screens from v7; the next integration task is adding an HTTP client, secure token storage, and replacing local/demo data with API calls.

Not production-ready: refresh-token rotation, email verification/password recovery, migrations tooling, rate limiting, payment verification, real AI provider, observability, security testing and Chile-specific legal/privacy review still need implementation.
