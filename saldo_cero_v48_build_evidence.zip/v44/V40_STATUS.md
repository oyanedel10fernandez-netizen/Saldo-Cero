# V40 STATUS

- [x] Terraform V40 reproducible
- [x] Pub/Sub OIDC parametrizado
- [x] Secret Manager sin valores
- [x] Cloud SQL con backup/PITR
- [x] Artifact Registry
- [x] Cloud Run
- [x] GitHub Actions + WIF
- [x] Migración automatizada como gate
- [x] Readiness gate
- [x] Sin credenciales reales

Pendiente de ejecución real: proyecto GCP, IAM, secretos, Redis/Memorystore, Google Play, dominio, Terraform apply, migraciones y pruebas de staging.
