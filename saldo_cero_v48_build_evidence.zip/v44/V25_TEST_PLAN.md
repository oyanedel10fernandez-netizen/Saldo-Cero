# V25 test plan

1. Two workers claim the same queue: only one receives the row.
2. Worker crash: expired lease returns PROCESSING job to RETRY.
3. Duplicate RTDN event: no duplicate entitlement.
4. Verified ACTIVE purchase: PRO/PREMIUM entitlement is granted.
5. Expired/revoked purchase: entitlement becomes FREE.
6. Google verification timeout: job enters RETRY.
7. Repeated verification failure: job becomes DEAD.
8. Admin without billing_admin role: replay returns FORBIDDEN.
9. Authorized replay: job returns to queue exactly once.
10. Logs contain no purchase tokens, passwords or access tokens.
11. Transaction failure: purchase/subscription/event writes all roll back.
