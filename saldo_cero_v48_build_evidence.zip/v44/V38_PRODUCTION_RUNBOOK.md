# SALDO CERO V38 — Runbook de activación real

## Gate 1 — secretos
Crear en Secret Manager, fuera del repositorio:
- google-play-package-name
- google-play-service-account-json
- saldo-cero-database-url
- saldo-cero-redis-url
- saldo-cero-jwt-secret
- saldo-cero-pubsub-audience
- saldo-cero-pubsub-service-account

## Gate 2 — identidad
Usar cuentas de servicio separadas para:
- Cloud Run runtime
- Pub/Sub push
- Google Play verification
- CI/CD

Aplicar mínimo privilegio.

## Gate 3 — datos
Aplicar MIGRATION_V37.sql/MIGRATION_V38.sql y verificar índices, constraints e idempotencia.

## Gate 4 — billing
Probar:
purchase -> Google Play V2 verification -> DB transaction -> entitlement
RTDN -> authenticated webhook -> durable event -> worker -> entitlement
duplicate event -> no duplicate entitlement
expiry/revocation -> paid access removed

## Gate 5 — seguridad
Verificar:
- no secrets in Git
- no secrets in Docker image
- OIDC signature/issuer/audience/service-account checks
- rate limit backed by shared Redis
- HTTPS only
- request size limits
- security headers
- structured logs with redaction

V38 no afirma que ninguno de estos servicios esté conectado hasta ejecutar estos gates en un entorno real.
