# V44 — ESTADO REAL

## Verde / resuelto en código
- Backend: `createHash` import corregido.
- Login y registro Android consumen API real.
- Access/refresh tokens protegidos con Android Keystore.
- Android deudas conectadas a `/v1/debts` (sin datos demo).
- Alta y eliminación/lectura preparada contra API.
- Plan conectado a `/v1/plans/calculate`.
- Asistente conectado a `/v1/assistant/message`.
- BillingClient 7.1.1 integrado para compra/restauración.
- Backend mantiene verificación server-side de compras.
- Recuperación de contraseña preparada con proveedor de email por variables de entorno.
- Verificación estática V44: PASS.

## No se puede marcar verde sin ejecutar en infraestructura real
- `npm install` no terminó dentro del entorno de construcción actual (timeout), por lo que TypeScript no se declara compilado.
- Android AAB no se declara compilado porque el proyecto no trae Gradle Wrapper/SDK ejecutable en este entorno.
- PostgreSQL/Redis reales no están conectados.
- Google Play Developer API no está conectado con credenciales reales.
- Pub/Sub RTDN/OIDC no está conectado.
- Cloud Run/Secret Manager/dominio no está desplegado.
- Proveedor de email e IA requieren credenciales externas.

No contiene secretos reales.
