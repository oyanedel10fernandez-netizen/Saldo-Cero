# SALDO CERO v25 — PostgreSQL billing + executable worker

## New
- Concrete PostgreSQL queue repository using `FOR UPDATE SKIP LOCKED`.
- Atomic verified-purchase transaction boundary.
- Executable-shaped worker loop with graceful shutdown.
- Billing-admin RBAC boundary and replay contract.
- Worker lease expiry/recovery migration.
- Android entitlement freshness state.
- Android versionCode 25 / versionName 25.0.0.

## Production flow
RTDN/Purchase
-> durable billing_jobs
-> PostgreSQL claim
-> Google Play V2 verification
-> atomic PostgreSQL transaction
-> entitlement/subscription update
-> DONE

Failures:
-> RETRY + exponential backoff
-> DEAD after maximum attempts
-> authorized billing_admin replay

## Important limitation
The repository and worker are now substantially closer to executable production
code, but this workspace does not have the user's live PostgreSQL database,
Google Play service-account credentials, Pub/Sub deployment, secrets or
production infrastructure. Therefore V25 does not claim live billing.

## Remaining production work
- Wire the concrete repository into the backend's actual DB pool.
- Encrypt/decrypt purchase tokens with a server-side secret/KMS strategy.
- Implement live Google Play Subscriptions V2 transport.
- Deploy RTDN/Pub/Sub.
- Add full integration tests against staging.
- Add rate limiting, alerting, dashboards and audit review.
- Complete account recovery/email verification and real AI gateway.
- Security/privacy/legal review and signed AAB/Play Console rollout.
