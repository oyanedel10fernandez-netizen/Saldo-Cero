# V35 Deployment Checklist

1. Create/select a dedicated Google Cloud project.
2. Enable Cloud Run, Cloud SQL Admin, Pub/Sub, Secret Manager, Artifact Registry and required IAM APIs.
3. Create a dedicated runtime service account with least-privilege roles.
4. Create the production Cloud SQL PostgreSQL instance and private connectivity.
5. Store DATABASE_URL, JWT secret and Google Play service-account material in Secret Manager.
6. Create Pub/Sub topic/subscription for Real-time Developer Notifications.
7. Configure authenticated push to the production RTDN endpoint.
8. Grant only required Pub/Sub publisher/invoker permissions.
9. Deploy the container to Cloud Run.
10. Run /health and /ready checks.
11. Apply database migrations.
12. Verify Google Play Subscriptions V2 in a controlled test environment.
13. Publish a sandbox/test subscription and verify RTDN -> queue -> worker -> entitlement.
14. Test renewal, cancellation, expiration, revoke/refund and duplicate-event handling.
15. Confirm logs/metrics/alerts and rollback procedure.
16. Only then promote the Android release.

Never commit service-account JSON, private keys, JWT secrets, database passwords or purchase tokens.
