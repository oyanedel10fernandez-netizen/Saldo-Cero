# V35 Release Gate

No promover a producción hasta que:
- smoke tests pasan
- E2E crítico pasa
- billing idempotency pasa
- RTDN duplicate/retry pasa
- expiry/revocation pasa
- `/ready` pasa
- observabilidad V31 está activa
- rollback fue ensayado
- migraciones están aplicadas
- secretos están en Secret Manager
- webhook Pub/Sub usa OIDC y mínimo privilegio

V35 no contiene ni afirma credenciales reales.
