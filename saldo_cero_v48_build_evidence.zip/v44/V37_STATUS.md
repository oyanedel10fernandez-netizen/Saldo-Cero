# V37 status

Version: 37.0.0

Implemented:
- V35 security foundation retained.
- Redis shared rate-limit adapter wired into sensitive routes when configured.
- Google OIDC verification uses google-auth-library and validates issuer, audience, service account and expiry.
- Secret Manager adapter implemented.
- RTDN endpoint authenticates OIDC, validates package, persists idempotent event and enqueues durable billing job.
- Google Play server-side verification path wired.
- Transactional billing persistence with idempotent purchase/event handling.
- Durable billing worker implementation included.
- Request/body limits and security headers registered.
- Production readiness gate rejects missing required environment configuration.
- No real credentials, keys, tokens or production connections included.

Not claimed:
- No Google Cloud project is connected by this artifact.
- No Secret Manager, Pub/Sub/OIDC, Redis/Memorystore, Cloud SQL or Google Play production connection is claimed.

Before launch:
- configure infrastructure and secrets outside source control
- apply MIGRATION_V37.sql
- configure Pub/Sub OIDC push
- configure Play Console/API permissions
- run staging E2E/security tests
- build/sign Android AAB and perform Play Console review
