# CHANGELOG V35
- Google Play server verification activa a nivel de código.
- OAuth2 Service Account con google-auth-library.
- Persistencia transaccional de entitlements en PostgreSQL.
- Health/readiness para despliegue.
- Docker/Cloud Run preparado.
- Secret Manager y configuración de producción documentados.
- Pub/Sub RTDN preparado para conexión OIDC.
- Migración V35 y checklist de despliegue.
