ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS plan TEXT NOT NULL DEFAULT 'FREE';
ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS product_id TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_user_provider_external_idx ON subscriptions(user_id,provider,external_id) WHERE external_id IS NOT NULL;
ALTER TABLE billing_purchases ADD COLUMN IF NOT EXISTS provider TEXT NOT NULL DEFAULT 'GOOGLE_PLAY';
ALTER TABLE billing_purchases ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();
CREATE TABLE IF NOT EXISTS billing_events (
 event_id TEXT PRIMARY KEY, event_time_millis BIGINT, notification_type TEXT, notification_name TEXT,
 package_name TEXT, purchase_token_hash TEXT, processed_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS billing_events_token_idx ON billing_events(purchase_token_hash);
