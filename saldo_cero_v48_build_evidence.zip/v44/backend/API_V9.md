# V9 endpoints
POST /v1/auth/register
POST /v1/auth/login
GET /v1/me
GET /v1/debts
POST /v1/debts
PATCH /v1/debts/{id}
DELETE /v1/debts/{id}
POST /v1/plans/calculate
POST /v1/assistant/message
GET /v1/subscription
POST /v1/subscription/verify
