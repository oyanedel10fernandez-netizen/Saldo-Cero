CREATE TABLE IF NOT EXISTS deployment_audit (
  id BIGSERIAL PRIMARY KEY,
  release_version TEXT NOT NULL,
  deployed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  environment TEXT NOT NULL,
  status TEXT NOT NULL
);
