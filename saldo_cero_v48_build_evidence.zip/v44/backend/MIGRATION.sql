-- Run after creating the database.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
\i schema.sql
