#!/usr/bin/env node
import fs from 'node:fs';

const app = fs.readFileSync('android/app/build.gradle.kts', 'utf8');
const checks = [
  ['Java sourceCompatibility 21', /sourceCompatibility\s*=\s*JavaVersion\.VERSION_21/],
  ['Java targetCompatibility 21', /targetCompatibility\s*=\s*JavaVersion\.VERSION_21/],
  ['Kotlin jvmTarget 21', /jvmTarget\s*=\s*"21"/],
  ['versionCode 47', /versionCode\s*=\s*47/],
  ['versionName 47.0.0', /versionName\s*=\s*"47\.0\.0"/],
];
for (const [name, re] of checks) {
  if (!re.test(app)) throw new Error(`FAIL: ${name}`);
}
console.log('V47 static verification: PASS');
