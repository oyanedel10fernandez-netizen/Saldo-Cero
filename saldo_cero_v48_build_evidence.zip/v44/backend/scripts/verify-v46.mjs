import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const required = [
  "src/server.ts",
  "src/billing-store-v37.ts",
  "src/billing/worker-v37.ts",
  "src/config/env-v38.ts",
  "src/security/production-bootstrap-v38.ts",
  "package.json"
];
for (const file of required) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
}
const pkg = JSON.parse(fs.readFileSync(path.join(root,"package.json"),"utf8"));
for (const dep of ["pg","redis","zod"]) if (!pkg.dependencies?.[dep] && !pkg.devDependencies?.[dep]) throw new Error(`Missing dependency ${dep}`);
for (const dep of ["@types/pg"]) if (!pkg.devDependencies?.[dep]) throw new Error(`Missing devDependency ${dep}`);
const worker = fs.readFileSync(path.join(root,"src/billing/worker-v37.ts"),"utf8");
if (!worker.includes("../billing-store-v37.js")) throw new Error("billing worker import not corrected");
console.log("V46 static verification: PASS");
