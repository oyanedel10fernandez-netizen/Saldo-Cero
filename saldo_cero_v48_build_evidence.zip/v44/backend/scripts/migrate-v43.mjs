import fs from "node:fs";import path from "node:path";import pg from "pg";
if(!process.env.DATABASE_URL)throw new Error("DATABASE_URL is required");
const dir=path.resolve(process.cwd(),"migrations"),pool=new pg.Pool({connectionString:process.env.DATABASE_URL});
await pool.query("CREATE TABLE IF NOT EXISTS schema_migrations(version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())");
for(const file of fs.readdirSync(dir).filter(x=>/^\\d+_.+\\.sql$/.test(x)).sort()){if((await pool.query("SELECT 1 FROM schema_migrations WHERE version=$1",[file])).rowCount)continue;const c=await pool.connect();try{await c.query("BEGIN");await c.query(fs.readFileSync(path.join(dir,file),"utf8"));await c.query("INSERT INTO schema_migrations(version) VALUES($1)",[file]);await c.query("COMMIT");console.log("APPLIED",file)}catch(e){await c.query("ROLLBACK");throw e}finally{c.release()}}await pool.end();
