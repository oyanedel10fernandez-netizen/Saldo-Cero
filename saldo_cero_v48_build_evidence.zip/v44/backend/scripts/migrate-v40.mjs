import fs from "node:fs";
import path from "node:path";
import pg from "pg";

const { Client } = pg;
const url = process.env.DATABASE_URL;
if (!url) throw new Error("DATABASE_URL is required for migrations");

const client = new Client({ connectionString: url, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: true } : undefined });
await client.connect();
try {
  const dir = path.resolve("migrations");
  const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => /^\\d+.*\\.sql$/.test(f)).sort() : [];
  await client.query("BEGIN");
  await client.query("CREATE TABLE IF NOT EXISTS schema_migrations(version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())");
  for (const file of files) {
    const version = file.split("_")[0];
    const exists = await client.query("SELECT 1 FROM schema_migrations WHERE version=$1", [version]);
    if (!exists.rowCount) {
      await client.query(fs.readFileSync(path.join(dir,file),"utf8"));
      await client.query("INSERT INTO schema_migrations(version) VALUES($1)", [version]);
    }
  }
  await client.query("COMMIT");
} catch (e) {
  await client.query("ROLLBACK"); throw e;
} finally { await client.end(); }
