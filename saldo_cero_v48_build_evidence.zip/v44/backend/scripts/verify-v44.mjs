import fs from 'node:fs'; import path from 'node:path';
const required=['src/server.ts','src/email-provider.ts','migrations/040_v43_auth_lifecycle.sql'];
for(const f of required){if(!fs.existsSync(path.join(process.cwd(),f))) throw new Error(`missing ${f}`)}
const server=fs.readFileSync('src/server.ts','utf8');
for(const x of ['createHash','/v1/auth/refresh','/v1/auth/reset-password','/v1/assistant/message']) if(!server.includes(x)) throw new Error(`missing ${x}`);
console.log('V44 static verification: PASS');
