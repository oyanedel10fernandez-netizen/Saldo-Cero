#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(scriptDir, '..', '..');
const appGradle = path.join(projectRoot, 'android', 'app', 'build.gradle.kts');

if (!fs.existsSync(appGradle)) {
  throw new Error(`FAIL: Android build file not found at ${appGradle}`);
}

const app = fs.readFileSync(appGradle, 'utf8');
const checks = [
  ['Java sourceCompatibility 21', /sourceCompatibility\s*=\s*JavaVersion\.VERSION_21/],
  ['Java targetCompatibility 21', /targetCompatibility\s*=\s*JavaVersion\.VERSION_21/],
  ['Kotlin jvmTarget 21', /jvmTarget\s*=\s*"21"/],
  ['versionCode 48', /versionCode\s*=\s*48/],
  ['versionName 48.0.0', /versionName\s*=\s*"48\.0\.0"/],
];

for (const [name, re] of checks) {
  if (!re.test(app)) throw new Error(`FAIL: ${name}`);
}

console.log('V48 static verification: PASS');
