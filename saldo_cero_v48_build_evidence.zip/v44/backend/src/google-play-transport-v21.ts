/**
 * SALDO CERO v21 — Google Play transport abstraction.
 *
 * The production adapter must obtain an OAuth2 access token from a service
 * account and call Google Play Developer API Subscriptions V2. Secrets are
 * injected at runtime; nothing sensitive belongs in source control.
 */

export interface GooglePlayTransportV21 {
  getSubscriptionV2(packageName:string, purchaseToken:string):
    Promise<GoogleSubscriptionV21>;
}

export type GoogleSubscriptionV21 = {
  subscriptionState:string;
  lineItems:Array<{
    productId:string;
    expiryTime?:string;
    autoRenewingPlan?:unknown;
  }>;
};

export function assertAllowedProduct(productId:string):void {
  if(productId!=="saldo_cero_pro_monthly" &&
     productId!=="saldo_cero_premium_monthly") {
    throw new Error("UNEXPECTED_PRODUCT_ID");
  }
}
