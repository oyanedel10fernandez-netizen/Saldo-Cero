import {FastifyInstance} from 'fastify';
import {decodePubSubV27} from './rtdn-pubsub-v27.js';
import {verifyGooglePubSubOidcV37} from './security/google-oidc-production-v37.js';
import {enqueueRtdnV37} from './billing/rtdn-queue-v37.js';
import {createHash} from 'node:crypto';

export async function registerRtdnV37(app:FastifyInstance){
  app.post('/v1/webhooks/google-play/rtdn',async(req,reply)=>{
    try{
      const aud=process.env.PUBSUB_OIDC_AUDIENCE, sa=process.env.PUBSUB_SERVICE_ACCOUNT;
      if(!aud||!sa) return reply.code(503).send({error:'pubsub_oidc_not_configured'});
      const auth=req.headers.authorization;
      if(!auth?.startsWith('Bearer ')) return reply.code(401).send({error:'missing_oidc'});
      await verifyGooglePubSubOidcV37(auth.slice(7),aud,sa);
      const x=decodePubSubV27(req.body);
      const expected=process.env.GOOGLE_PLAY_PACKAGE_NAME;
      if(expected && x.packageName!==expected) return reply.code(400).send({error:'package_mismatch'});
      const tokenHash=createHash('sha256').update(x.purchaseToken).digest('hex');
      await app.pg.query(`INSERT INTO billing_events(event_id,event_time_millis,notification_type,notification_name,package_name,purchase_token_hash,created_at) VALUES($1,$2,$3,$4,$5,$6,NOW()) ON CONFLICT(event_id) DO NOTHING`,[x.eventId,x.eventTimeMillis||null,x.notificationType,x.notificationName,x.packageName,tokenHash]);
      await enqueueRtdnV37(app.pg,{eventId:x.eventId,packageName:x.packageName,purchaseToken:x.purchaseToken,notificationType:x.notificationType});
      return reply.code(202).send({accepted:true,event_id:x.eventId});
    }catch(e:any){app.log.warn({err:e},'RTDN rejected'); return reply.code(401).send({error:'invalid_rtdn'});}
  });
}
