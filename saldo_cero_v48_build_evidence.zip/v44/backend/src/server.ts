import Fastify from "fastify";
import {registerRtdnV37} from './rtdn-endpoint-v37.js';
import cors from "@fastify/cors";
import jwt from "@fastify/jwt";
import postgres from "@fastify/postgres";
import { randomUUID, randomBytes, scryptSync, timingSafeEqual, createHash } from "node:crypto";
import {verifyGooglePurchaseV37} from "./google-play-verifier-v37.js";
import {applyVerifiedPurchaseV37} from "./billing-store-v37.js";
import {registerRequestGuardV37} from "./security/request-guard-v37.js";
import {createRedisRateLimitStore} from "./security/redis-rate-limit-adapter-v37.js";
import {enforceLimit} from "./security/shared-rate-limit-v35.js";
import {missingProductionEnv} from "./security/security-config-v37.js";

const app=Fastify({logger:true,bodyLimit:256000});
registerRequestGuardV37(app);
await app.register(cors,{origin:false});
const JWT_SECRET=process.env.JWT_SECRET; if(!JWT_SECRET) throw new Error("JWT_SECRET is required");
await app.register(jwt,{secret:JWT_SECRET});
const DATABASE_URL=process.env.DATABASE_URL;
if(!DATABASE_URL && process.env.NODE_ENV==="production") throw new Error("DATABASE_URL is required in production");
await app.register(postgres,{connectionString:DATABASE_URL||"postgres://saldo:saldo@localhost:5432/saldocero"});

let redis:any=null;
if(process.env.REDIS_URL){ try { redis=await createRedisRateLimitStore(process.env.REDIS_URL); } catch(e){ if(process.env.NODE_ENV==="production") throw e; app.log.warn({err:e},"Redis unavailable; rate limiting disabled for development"); } }
if(process.env.NODE_ENV==="production" && !redis) throw new Error("REDIS_URL is required in production");
if(redis){ app.addHook("onRequest",async(req,reply)=>{ const path=req.url.split("?")[0]; const sensitive=path.startsWith("/v1/auth/")||path.startsWith("/v1/webhooks/"); if(!sensitive)return; const key=`${path}:${req.ip}`; const d=await enforceLimit(redis.store,key, path.startsWith("/v1/webhooks/")?120:10,60); if(!d.allowed){reply.header("Retry-After",String(d.retryAfterSeconds)); return reply.code(429).send({error:"rate_limited",retry_after_seconds:d.retryAfterSeconds});}}); }

const hash=(p:string,salt:string)=>scryptSync(p,salt,32).toString("hex");
const verify=(p:string,h:string,salt:string)=>{const a=Buffer.from(hash(p,salt),"hex"),b=Buffer.from(h,"hex");return a.length===b.length&&timingSafeEqual(a,b)};
const sha256=(v:string)=>createHash("sha256").update(v).digest("hex");
const issueRefresh=async(userId:string)=>{const raw=randomBytes(48).toString("base64url");await app.pg.query("INSERT INTO refresh_tokens(id,user_id,token_hash,expires_at) VALUES($1,$2,$3,NOW()+INTERVAL '30 days')",[randomUUID(),userId,sha256(raw)]);return raw;};
async function auth(req:any,reply:any){try{await req.jwtVerify()}catch{return reply.code(401).send({error:"unauthorized"})}}

app.get("/health",async()=>({ok:true,version:"46.0.0"}));
app.get("/ready",async(_req,reply)=>{ const missing=process.env.NODE_ENV==="production"?missingProductionEnv(process.env):[]; if(missing.length)return reply.code(503).send({ok:false,missing}); try{await app.pg.query("SELECT 1");}catch{return reply.code(503).send({ok:false,db:false});} return {ok:true,db:true,redis:!!redis,google_play_configured:Boolean(process.env.GOOGLE_PLAY_PACKAGE_NAME&&process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON)}; });

app.post("/v1/auth/register",async(req,reply)=>{
 const b=req.body as any,e=b.email?.trim().toLowerCase();
 if(!e||typeof b.password!=="string"||b.password.length<8)return reply.code(400).send({error:"invalid_credentials"});
 try{
  const id=randomUUID();
  const salt=randomBytes(16).toString("hex");
  const r=await app.pg.query("INSERT INTO users(id,email,password_hash,password_salt) VALUES($1,$2,$3,$4) RETURNING id,email",[id,e,hash(b.password,salt),salt]);
  const u=r.rows[0];
  return {access_token:app.jwt.sign({sub:u.id,email:u.email},{expiresIn:"15m"}),refresh_token:await issueRefresh(u.id),user:u};
 }catch(err:any){if(err.code==="23505")return reply.code(409).send({error:"email_exists"});throw err}
});

app.post("/v1/auth/login",async(req,reply)=>{
 const b=req.body as any;
 const r=await app.pg.query("SELECT id,email,password_hash,password_salt FROM users WHERE email=$1",[b.email?.trim().toLowerCase()]);
 const u=r.rows[0];
 if(!u||!verify(b.password||"",u.password_hash,u.password_salt))return reply.code(401).send({error:"invalid_credentials"});
 return {access_token:app.jwt.sign({sub:u.id,email:u.email},{expiresIn:"15m"}),refresh_token:await issueRefresh(u.id),user:{id:u.id,email:u.email}};
});


app.post("/v1/auth/refresh",async(req,reply)=>{
 const b=req.body as any;if(typeof b.refresh_token!=="string")return reply.code(400).send({error:"refresh_token_required"});
 const r=await app.pg.query("SELECT id,user_id FROM refresh_tokens WHERE token_hash=$1 AND revoked_at IS NULL AND expires_at>NOW()",[sha256(b.refresh_token)]);
 const row=r.rows[0];if(!row)return reply.code(401).send({error:"invalid_refresh_token"});
 await app.pg.query("UPDATE refresh_tokens SET revoked_at=NOW() WHERE id=$1",[row.id]);
 const u=(await app.pg.query("SELECT id,email FROM users WHERE id=$1",[row.user_id])).rows[0];
 if(!u)return reply.code(401).send({error:"invalid_refresh_token"});
 return {access_token:app.jwt.sign({sub:u.id,email:u.email},{expiresIn:"15m"}),refresh_token:await issueRefresh(u.id)};
});
app.post("/v1/auth/forgot-password",async(req,reply)=>{
 const b=req.body as any;
 if(typeof b.email!=="string"||!b.email.trim())return reply.code(400).send({error:"email_required"});
 const email=b.email.trim().toLowerCase();
 const r=await app.pg.query("SELECT id FROM users WHERE email=$1",[email]);
 if(r.rows[0]){
   const raw=randomBytes(32).toString("base64url");
   await app.pg.query("INSERT INTO password_reset_tokens(id,user_id,token_hash,expires_at) VALUES($1,$2,$3,NOW()+INTERVAL '30 minutes')",[randomUUID(),r.rows[0].id,sha256(raw)]);
   const base=process.env.PASSWORD_RESET_URL_BASE;
   if(base && process.env.EMAIL_PROVIDER_URL && process.env.EMAIL_PROVIDER_API_KEY){
     await fetch(process.env.EMAIL_PROVIDER_URL,{method:"POST",headers:{"content-type":"application/json","authorization":`Bearer ${process.env.EMAIL_PROVIDER_API_KEY}`},body:JSON.stringify({to:email,template:"password_reset",reset_url:`${base.replace(/\/$/,"")}?token=${encodeURIComponent(raw)}`})});
   }
 }
 return {status:"accepted"};
});
app.post("/v1/auth/reset-password",async(req,reply)=>{
 const b=req.body as any;if(typeof b.token!=="string"||typeof b.new_password!=="string"||b.new_password.length<8)return reply.code(400).send({error:"invalid_reset"});
 const r=await app.pg.query("SELECT id,user_id FROM password_reset_tokens WHERE token_hash=$1 AND used_at IS NULL AND expires_at>NOW()",[sha256(b.token)]);
 const row=r.rows[0];if(!row)return reply.code(400).send({error:"invalid_or_expired_reset"});
 const salt=randomBytes(16).toString("hex");
 await app.pg.query("UPDATE users SET password_hash=$1,password_salt=$2 WHERE id=$3",[hash(b.new_password,salt),salt,row.user_id]);
 await app.pg.query("UPDATE password_reset_tokens SET used_at=NOW() WHERE id=$1",[row.id]);
 await app.pg.query("UPDATE refresh_tokens SET revoked_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL",[row.user_id]);
 return {status:"password_reset"};
});
app.get("/v1/profile",{preHandler:auth},async(req:any)=>{
 const r=await app.pg.query("SELECT id,email,display_name,currency FROM users WHERE id=$1",[req.user.sub]);
 if(!r.rows[0]) return {error:"not_found"};
 return r.rows[0];
});
app.patch("/v1/profile",{preHandler:auth},async(req:any,reply:any)=>{
 const b=req.body as any;
 if(b.display_name!=null && (typeof b.display_name!=="string" || b.display_name.trim().length>80))
   return reply.code(400).send({error:"invalid_display_name"});
 const r=await app.pg.query("UPDATE users SET display_name=$1 WHERE id=$2 RETURNING id,email,display_name,currency",
 [b.display_name?.trim()||null,req.user.sub]);
 return r.rows[0];
});

app.get("/v1/entitlement",{preHandler:auth},async(req:any)=>{
 const r=await app.pg.query(
   "SELECT plan,status,renews_at,product_id FROM subscriptions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1",
   [req.user.sub]
 );
 const x=r.rows[0];
 if(!x || x.status!=="ACTIVE") return {plan:"FREE",active:false,expires_at:null,product_id:null};
 return {plan:x.plan,active:true,expires_at:x.renews_at,product_id:x.product_id||null};
});

app.get("/v1/subscription",{preHandler:auth},async(req:any)=>{
 const r=await app.pg.query("SELECT plan,status,renews_at FROM subscriptions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 1",[req.user.sub]);
 return r.rows[0]||{plan:"FREE",status:"ACTIVE",renews_at:null};
});
app.post("/v1/subscription/verify",{preHandler:auth},async(req:any,reply:any)=>{
 const b=req.body as any;
 if(typeof b.product_id!=="string"||typeof b.purchase_token!=="string"||b.purchase_token.length>4096) return reply.code(400).send({error:"invalid_purchase"});
 if(!process.env.GOOGLE_PLAY_PACKAGE_NAME || !process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON)
   return reply.code(503).send({error:"google_play_not_configured"});
 try{
   const verification=await verifyGooglePurchaseV37({packageName:process.env.GOOGLE_PLAY_PACKAGE_NAME,productId:b.product_id,purchaseToken:b.purchase_token});
   const eventId=randomUUID();
   await applyVerifiedPurchaseV37((app.pg as any).pool,{eventId,userId:req.user.sub,productId:b.product_id,purchaseToken:b.purchase_token,state:verification.state,expiresAt:verification.expiresAt});
   return {status:"verified",plan:b.product_id==="saldo_cero_premium_monthly"?"PREMIUM":"PRO",expires_at:verification.expiresAt};
 }catch(e:any){
   app.log.error(e);
   return reply.code(502).send({error:"google_play_verification_failed"});
 }
});

app.get("/v1/me",{preHandler:auth},async(req:any)=>({user:{id:req.user.sub,email:req.user.email}}));

app.get("/v1/debts",{preHandler:auth},async(req:any)=>{
 const r=await app.pg.query("SELECT id,name,balance_cents,payment_cents,annual_rate_bps,due_day FROM debts WHERE user_id=$1 ORDER BY created_at",[req.user.sub]);
 return {debts:r.rows};
});

app.post("/v1/debts",{preHandler:auth},async(req:any,reply:any)=>{
 const b=req.body as any,id=randomUUID();
 if(!b.name||![b.balance_cents,b.payment_cents,b.annual_rate_bps].every(Number.isInteger))return reply.code(400).send({error:"invalid_debt"});
 const r=await app.pg.query("INSERT INTO debts(id,user_id,name,balance_cents,payment_cents,annual_rate_bps,due_day) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *",
 [id,req.user.sub,b.name,b.balance_cents,b.payment_cents,b.annual_rate_bps,b.due_day??null]);
 return reply.code(201).send({debt:r.rows[0]});
});

app.delete("/v1/debts/:id",{preHandler:auth},async(req:any,reply:any)=>{
 const r=await app.pg.query("DELETE FROM debts WHERE id=$1 AND user_id=$2",[(req.params as any).id,req.user.sub]);
 if(!r.rowCount)return reply.code(404).send({error:"not_found"}); return {ok:true};
});

app.post("/v1/plans/calculate",{preHandler:auth},async(req:any)=>{
 const b=req.body as any;
 const r=await app.pg.query("SELECT id,name,balance_cents,payment_cents,annual_rate_bps,due_day FROM debts WHERE user_id=$1",[req.user.sub]);
 const priority=[...r.rows];
 if(b.strategy==="SNOWBALL")priority.sort((a,z)=>Number(a.balance_cents)-Number(z.balance_cents));
 else priority.sort((a,z)=>Number(z.annual_rate_bps)-Number(a.annual_rate_bps));
 return {strategy:b.strategy||"AVALANCHE",extra_payment_cents:b.extra_payment_cents||0,priority};
});

app.post("/v1/assistant/message",{preHandler:auth},async(req:any,reply:any)=>{
 const b=req.body as any;if(typeof b.message!=="string"||!b.message.trim())return reply.code(400).send({error:"message_required"});
 const url=process.env.AI_PROVIDER_URL,key=process.env.AI_PROVIDER_API_KEY,model=process.env.AI_PROVIDER_MODEL||"default";
 if(!url||!key)return {mode:"unconfigured",message:"El asistente IA está preparado, pero falta configurar el proveedor en el servidor."};
 try{const r=await fetch(url,{method:"POST",headers:{"content-type":"application/json","authorization":`Bearer ${key}`},body:JSON.stringify({model,messages:[{role:"user",content:b.message.trim()}]})});
 if(!r.ok)return reply.code(502).send({error:"ai_provider_error"});const d=await r.json() as any;const answer=d?.choices?.[0]?.message?.content??d?.output_text??d?.message;
 if(typeof answer!=="string")return reply.code(502).send({error:"ai_invalid_response"});return {mode:"provider",message:answer};
 }catch(e){app.log.error(e);return reply.code(502).send({error:"ai_unavailable"});}
});
await registerRtdnV37(app);
await app.listen({host:"0.0.0.0",port:Number(process.env.PORT||8080)});
