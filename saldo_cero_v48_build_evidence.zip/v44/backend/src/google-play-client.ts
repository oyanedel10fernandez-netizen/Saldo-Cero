/**
 * Google Play Developer API V2 integration boundary.
 *
 * V18 keeps credentials/configuration outside source control. In deployment,
 * GOOGLE_PLAY_PACKAGE_NAME and service-account credentials must be supplied
 * through the secret manager. The actual Google API call remains isolated in
 * this module so it can be replaced/tested independently.
 */

export type GooglePlaySubscription = {
  productId: string;
  state: "ACTIVE"|"CANCELED"|"EXPIRED"|"ON_HOLD"|"GRACE_PERIOD"|"REVOKED";
  expiryTime?: string;
  autoRenewing?: boolean;
  linkedPurchaseToken?: string;
};

export function googlePlayConfigured(): boolean {
  return Boolean(process.env.GOOGLE_PLAY_PACKAGE_NAME &&
    (process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON ||
     process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_FILE));
}

export async function getSubscriptionV2(
  purchaseToken: string
): Promise<GooglePlaySubscription> {
  if (!googlePlayConfigured()) {
    throw new Error("GOOGLE_PLAY_DEVELOPER_API_NOT_CONFIGURED");
  }
  if (!purchaseToken) throw new Error("INVALID_PURCHASE_TOKEN");

  // Production implementation point:
  // authenticate with Google service account and call:
  // GET androidpublisher.googleapis.com/androidpublisher/v3/applications/
  // {packageName}/purchases/subscriptionsv2/tokens/{token}
  //
  // Never log the raw token or service-account JSON.
  throw new Error("GOOGLE_PLAY_API_CALL_NOT_ENABLED_IN_SOURCE_BUILD");
}
