import { verifyPurchaseV19, GooglePlayHttpClient } from "./google-play-verifier-v19.js";

export type ReconcileResult = {
  state:string;
  productId:string;
  expiryTime:string|null;
};

export async function reconcileVerifiedPurchaseV19(
  client:GooglePlayHttpClient,
  packageName:string,
  purchaseToken:string
):Promise<ReconcileResult> {
  const v=await verifyPurchaseV19(client,packageName,purchaseToken);
  // Integration point: execute one DB transaction:
  // 1) lock billing_purchases by purchase_token_hash
  // 2) upsert verified lifecycle state
  // 3) update subscriptions and expires_at
  // 4) recompute server-owned entitlement
  // 5) insert billing_events with a unique event key
  // 6) commit only after all writes succeed.
  return {state:v.state,productId:v.productId,expiryTime:v.expiryTime};
}
