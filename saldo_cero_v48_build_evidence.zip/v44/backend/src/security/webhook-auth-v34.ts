export interface VerifiedPushToken { issuer:string; audience:string; email?:string; }
export interface WebhookAuthVerifier { verify(token:string, expectedAudience:string):Promise<VerifiedPushToken>; }

export async function requirePubSubOidc(
 authorizationHeader:string|undefined,
 expectedAudience:string,
 verifier:WebhookAuthVerifier
){
 if(!authorizationHeader?.startsWith("Bearer ")) throw new Error("missing_webhook_auth");
 const token=authorizationHeader.slice("Bearer ".length);
 const claims=await verifier.verify(token,expectedAudience);
 if(claims.audience!==expectedAudience) throw new Error("invalid_webhook_audience");
 return claims;
}
