export const requestLimits={authBodyBytes:16384,jsonBodyBytes:256000,webhookBodyBytes:1048576,headerBytes:16384} as const;
