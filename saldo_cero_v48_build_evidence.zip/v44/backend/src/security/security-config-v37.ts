export const securityConfigV37={
  authRateLimit:{limit:10,windowSeconds:60},
  webhookRateLimit:{limit:120,windowSeconds:60},
  maxBodyBytes:256000,
  requiredProductionEnv:['JWT_SECRET','DATABASE_URL','GOOGLE_PLAY_PACKAGE_NAME','GOOGLE_PLAY_SERVICE_ACCOUNT_JSON','PUBSUB_OIDC_AUDIENCE','PUBSUB_SERVICE_ACCOUNT','REDIS_URL'] as const
};
export function missingProductionEnv(env:NodeJS.ProcessEnv){return securityConfigV37.requiredProductionEnv.filter(k=>!env[k]);}
