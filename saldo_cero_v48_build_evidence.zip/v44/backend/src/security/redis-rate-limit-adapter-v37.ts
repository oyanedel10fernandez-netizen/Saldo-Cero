import { createClient } from 'redis';
import type { RateLimitStore } from './shared-rate-limit-v35.js';

export class RedisRateLimitStore implements RateLimitStore {
  constructor(private readonly client: any) {}
  async increment(key:string, windowSeconds:number) {
    const bucket=Math.floor(Date.now()/1000/windowSeconds);
    const redisKey=`saldo-cero:rl:${key}:${bucket}`;
    const count=Number(await this.client.incr(redisKey));
    if(count===1) await this.client.expire(redisKey, windowSeconds+1);
    return {count, resetAt:(bucket+1)*windowSeconds*1000};
  }
}
export async function createRedisRateLimitStore(url:string){
  const client=createClient({url});
  client.on('error',()=>{});
  await client.connect();
  return {client, store:new RedisRateLimitStore(client)};
}
