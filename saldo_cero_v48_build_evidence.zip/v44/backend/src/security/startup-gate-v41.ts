export interface ProductionDependencies {
  databaseUrl?: string;
  redisUrl?: string;
  jwtSecret?: string;
  googlePlayPackageName?: string;
  googlePlayServiceAccountJson?: string;
  pubsubOidcAudience?: string;
}

export function assertProductionDependencies(env: NodeJS.ProcessEnv): void {
  if (env.NODE_ENV !== "production") return;
  const required = [
    "DATABASE_URL","REDIS_URL","JWT_SECRET",
    "GOOGLE_PLAY_PACKAGE_NAME","GOOGLE_PLAY_SERVICE_ACCOUNT_JSON",
    "PUBSUB_OIDC_AUDIENCE"
  ];
  const missing = required.filter(k => !env[k]);
  if (missing.length) throw new Error(`Missing production configuration: ${missing.join(",")}`);
}
