import {SecretManagerServiceClient} from '@google-cloud/secret-manager';
import type {SecretProvider} from './secret-manager-v35.js';

export class GoogleSecretManagerProvider implements SecretProvider {
  private client=new SecretManagerServiceClient();
  constructor(private readonly projectId:string){}
  async get(name:string){
    const [v]=await this.client.accessSecretVersion({name:name.includes('/versions/')?name:`projects/${this.projectId}/secrets/${name}/versions/latest`});
    const value=v.payload?.data?.toString();
    if(!value) throw new Error(`empty_secret:${name}`);
    return value;
  }
}
