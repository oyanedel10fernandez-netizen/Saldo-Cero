export interface OidcClaims {iss:string;aud:string;email?:string;sub?:string;exp:number;}
export interface OidcVerifier {verify(token:string):Promise<OidcClaims>;}
export async function verifyPubSubPush(authorization:string|undefined,expectedAudience:string,expectedServiceAccount:string,verifier:OidcVerifier):Promise<OidcClaims>{
 if(!authorization?.startsWith("Bearer ")) throw new Error("missing_oidc_token");
 const c=await verifier.verify(authorization.slice(7));
 if(!["https://accounts.google.com","accounts.google.com"].includes(c.iss)) throw new Error("invalid_oidc_issuer");
 if(c.aud!==expectedAudience) throw new Error("invalid_oidc_audience");
 if(c.email!==expectedServiceAccount) throw new Error("invalid_oidc_service_account");
 if(c.exp*1000<=Date.now()) throw new Error("expired_oidc_token");
 return c;
}
