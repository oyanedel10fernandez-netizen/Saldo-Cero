import {OAuth2Client} from 'google-auth-library';
import type {OidcClaims} from './pubsub-oidc-v35.js';

const client=new OAuth2Client();
export async function verifyGooglePubSubOidcV37(token:string,audience:string,expectedServiceAccount:string):Promise<OidcClaims>{
  const ticket=await client.verifyIdToken({idToken:token,audience});
  const p=ticket.getPayload();
  if(!p) throw new Error('invalid_oidc_payload');
  if(!['https://accounts.google.com','accounts.google.com'].includes(p.iss||'')) throw new Error('invalid_oidc_issuer');
  if(p.aud!==audience) throw new Error('invalid_oidc_audience');
  if(p.email!==expectedServiceAccount) throw new Error('invalid_oidc_service_account');
  if(!p.exp || p.exp*1000<=Date.now()) throw new Error('expired_oidc_token');
  return {iss:p.iss!,aud:p.aud!,email:p.email,sub:p.sub,exp:p.exp};
}
