import type {FastifyInstance} from 'fastify';
import {requestLimits} from './request-limits-v35.js';
export function registerRequestGuardV37(app:FastifyInstance){
  app.addHook('onRequest',async(req,reply)=>{
    const len=Number(req.headers['content-length']||0);
    if(len>requestLimits.jsonBodyBytes) return reply.code(413).send({error:'request_too_large'});
    const path=req.url.split('?')[0];
    if(path.startsWith('/v1/webhooks/google-play/') && len>requestLimits.webhookBodyBytes) return reply.code(413).send({error:'webhook_too_large'});
  });
  app.addHook('onSend',async(_req,reply,payload)=>{for(const [k,v] of Object.entries({
    'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Permissions-Policy':'camera=(), microphone=(), geolocation=()'
  })) reply.header(k,v); return payload;});
}
