export interface RateLimitDecision { allowed:boolean; remaining:number; retryAfterSeconds:number; }
export function decideRateLimit(count:number, limit:number, windowSeconds:number):RateLimitDecision {
 const allowed=count<limit;
 return {allowed,remaining:Math.max(0,limit-count-(allowed?1:0)),retryAfterSeconds:allowed?0:windowSeconds};
}
// Production adapter should use a shared store (e.g. Redis/Memorystore) rather than process memory.
