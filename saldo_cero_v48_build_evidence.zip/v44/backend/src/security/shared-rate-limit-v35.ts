export interface RateLimitStore { increment(key:string,windowSeconds:number):Promise<{count:number;resetAt:number}>; }
export interface RateLimitDecision {allowed:boolean;remaining:number;retryAfterSeconds:number;}
export async function enforceLimit(store:RateLimitStore,key:string,limit:number,windowSeconds:number):Promise<RateLimitDecision>{
 const r=await store.increment(key,windowSeconds), allowed=r.count<=limit;
 return {allowed,remaining:Math.max(0,limit-r.count),retryAfterSeconds:allowed?0:Math.max(1,Math.ceil((r.resetAt-Date.now())/1000))};
}
