import fs from "node:fs";
import path from "node:path";
const root = process.argv[2] || ".";
const patterns = [
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
  /AIza[0-9A-Za-z_-]{20,}/,
  /ghp_[0-9A-Za-z]{20,}/,
  /sk-[A-Za-z0-9]{20,}/
];
let found = [];
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    if (["node_modules",".git",".gradle","build"].includes(name)) continue;
    const p = path.join(dir,name), s = fs.statSync(p);
    if (s.isDirectory()) walk(p);
    else {
      let text;
      try { text = fs.readFileSync(p,"utf8"); } catch { return; }
      if (patterns.some(r => r.test(text))) found.push(p);
    }
  }
}
walk(root);
if (found.length) { console.error("Potential credentials:", found); process.exit(1); }
console.log("Secret scan: clean");
