export type AuditEvent={
 action:string; requestId?:string; userId?:string; outcome:"success"|"failure";
 metadata?:Record<string,unknown>; createdAt:string;
};
export function audit(action:string,outcome:AuditEvent["outcome"],metadata:Record<string,unknown>={}):AuditEvent{
 return {action,outcome,metadata,createdAt:new Date().toISOString()};
}
