export interface SecretProvider {get(name:string):Promise<string>;}
export function requireSecret(value:string|undefined,name:string):string{if(!value) throw new Error(`missing_secret:${name}`);return value;}
// Production adapter: Google Secret Manager. Never commit or bake real secrets into images.
