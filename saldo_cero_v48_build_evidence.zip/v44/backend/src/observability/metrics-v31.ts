export interface MetricSink { increment(name:string,value?:number,labels?:Record<string,string>):void; observe(name:string,value:number,labels?:Record<string,string>):void; }
export class NoopMetricSink implements MetricSink { increment(_n:string,_v=1,_l:Record<string,string>={}){} observe(_n:string,_v:number,_l:Record<string,string>={}){} }
export const METRICS = {
 httpRequests:"saldo_cero/http_requests_total", httpLatency:"saldo_cero/http_request_latency_ms",
 billingJobs:"saldo_cero/billing_jobs_total", billingFailures:"saldo_cero/billing_failures_total",
 billingRetries:"saldo_cero/billing_retries_total", rtdnEvents:"saldo_cero/rtdn_events_total",
 entitlementChanges:"saldo_cero/entitlement_changes_total"
} as const;
