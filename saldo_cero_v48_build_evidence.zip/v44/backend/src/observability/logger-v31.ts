export type LogLevel = "INFO" | "WARN" | "ERROR";
export interface LogContext { requestId?: string; userId?: string; route?: string; event?: string; productId?: string; statusCode?: number; durationMs?: number; [key:string]: unknown; }
export function log(level: LogLevel, message: string, context: LogContext = {}) {
  // Never log tokens, passwords, private keys or raw purchase tokens.
  process.stdout.write(JSON.stringify({timestamp:new Date().toISOString(), severity:level, message, ...context})+"\n");
}
