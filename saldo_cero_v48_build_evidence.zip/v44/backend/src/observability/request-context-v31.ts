import { randomUUID } from "node:crypto";
export function requestIdFrom(headers: Record<string, unknown>): string {
  const v=headers["x-request-id"];
  return typeof v==="string" && /^[A-Za-z0-9._:-]{8,128}$/.test(v) ? v : randomUUID();
}
