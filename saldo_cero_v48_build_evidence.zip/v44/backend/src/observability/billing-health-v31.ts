export interface BillingHealth { status:"ok"|"degraded"; queueDepth:number; processingJobs:number; failedJobs:number; oldestPendingAgeSeconds:number|null; checkedAt:string; }
export function evaluateBillingHealth(i:Omit<BillingHealth,"status"|"checkedAt">):BillingHealth {
 const degraded=i.failedJobs>0 || i.queueDepth>100 || (i.oldestPendingAgeSeconds!==null && i.oldestPendingAgeSeconds>900);
 return {...i,status:degraded?"degraded":"ok",checkedAt:new Date().toISOString()};
}
