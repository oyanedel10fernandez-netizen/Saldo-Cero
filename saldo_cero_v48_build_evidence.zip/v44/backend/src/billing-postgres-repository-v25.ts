/**
 * SALDO CERO V25 — PostgreSQL billing repository.
 *
 * This is the concrete SQL boundary. Inject a pg Pool/Client from the
 * application so credentials and connection lifecycle remain outside the
 * billing domain.
 */
export type SqlClient = {
  query<T=unknown>(text:string, values?:unknown[]):Promise<{rows:T[]}>;
};

export class BillingPostgresRepositoryV25 {
  constructor(private readonly db:SqlClient) {}

  async claimJobs(limit:number) {
    const n=Math.max(1,Math.min(limit,100));
    const r=await this.db.query(`
      UPDATE billing_jobs
      SET status='PROCESSING', locked_at=NOW(), updated_at=NOW()
      WHERE id IN (
        SELECT id FROM billing_jobs
        WHERE status IN ('PENDING','RETRY')
          AND (next_attempt_at IS NULL OR next_attempt_at<=NOW())
        ORDER BY created_at
        FOR UPDATE SKIP LOCKED
        LIMIT $1
      )
      RETURNING id,event_id,user_id,product_id,purchase_token_encrypted,attempts
    `,[n]);
    return r.rows;
  }

  async markDone(id:string) {
    await this.db.query(`
      UPDATE billing_jobs
      SET status='DONE', locked_at=NULL, updated_at=NOW()
      WHERE id=$1
    `,[id]);
  }

  async markRetry(id:string,error:string,nextAttemptAt:Date) {
    await this.db.query(`
      UPDATE billing_jobs
      SET status='RETRY', attempts=attempts+1, last_error=$2,
          next_attempt_at=$3, locked_at=NULL, updated_at=NOW()
      WHERE id=$1
    `,[id,error.slice(0,1000),nextAttemptAt]);
  }

  async markDead(id:string,error:string) {
    await this.db.query(`
      UPDATE billing_jobs
      SET status='DEAD', attempts=attempts+1, last_error=$2,
          locked_at=NULL, updated_at=NOW()
      WHERE id=$1
    `,[id,error.slice(0,1000)]);
  }

  async queueStats() {
    const r=await this.db.query(`
      SELECT status, COUNT(*)::int AS count
      FROM billing_jobs GROUP BY status
    `);
    return r.rows;
  }
}
