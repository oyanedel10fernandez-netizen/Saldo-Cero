import { getSubscriptionV2, GooglePlaySubscription } from "./google-play-client.js";

export function normalizeBillingState(s: GooglePlaySubscription["state"]) {
  return s;
}

/**
 * Reconciliation worker contract:
 * - find PENDING_VERIFICATION / ACTIVE paid purchases
 * - verify against Google Play Subscriptions V2
 * - update billing_purchases + subscriptions atomically
 * - downgrade on expiry/revocation/hold according to policy
 *
 * Call from a protected worker/cron, never from the Android client.
 */
export async function reconcilePurchase(purchaseToken:string) {
  const verified = await getSubscriptionV2(purchaseToken);
  return {
    state: normalizeBillingState(verified.state),
    productId: verified.productId,
    expiryTime: verified.expiryTime ?? null
  };
}
