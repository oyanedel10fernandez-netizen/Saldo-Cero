import {createHash} from 'node:crypto';
export async function applyVerifiedPurchaseV37(db:any,args:{eventId:string;userId:string;productId:string;purchaseToken:string;state:string;expiresAt:string|null}){
  const hash=createHash('sha256').update(args.purchaseToken).digest('hex');
  const active=args.state==='SUBSCRIPTION_STATE_ACTIVE' && !!args.expiresAt && new Date(args.expiresAt).getTime()>Date.now();
  const plan=args.productId==='saldo_cero_premium_monthly'?'PREMIUM':'PRO';
  const client=db.query && db.connect ? await db.connect() : db;
  await client.query('BEGIN');
  try{
    await client.query(`INSERT INTO billing_purchases(id,user_id,product_id,purchase_token_hash,purchase_state,verified_at,expires_at,created_at) VALUES(gen_random_uuid(),$1,$2,$3,$4,NOW(),$5,NOW()) ON CONFLICT(purchase_token_hash) DO UPDATE SET purchase_state=EXCLUDED.purchase_state,verified_at=NOW(),expires_at=EXCLUDED.expires_at`,[args.userId,args.productId,hash,args.state,args.expiresAt]);
    await client.query(`INSERT INTO subscriptions(id,user_id,provider,external_id,status,renews_at,product_id) VALUES(gen_random_uuid(),$1,'google_play',$2,$3,$4,$5) ON CONFLICT (user_id,provider,external_id) DO UPDATE SET status=EXCLUDED.status,renews_at=EXCLUDED.renews_at,product_id=EXCLUDED.product_id`,[args.userId,hash,active?'ACTIVE':'EXPIRED',args.expiresAt,args.productId]);
    await client.query(`INSERT INTO billing_events(event_id,purchase_token_hash,event_type,processed_at,created_at) VALUES($1,$2,'PURCHASE_VERIFIED',NOW(),NOW()) ON CONFLICT(event_id) DO NOTHING`,[args.eventId,hash]);
    await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK');throw e}
  finally{if(client!==db && client.release)client.release()}
  return {active,plan,expiresAt:args.expiresAt};
}
