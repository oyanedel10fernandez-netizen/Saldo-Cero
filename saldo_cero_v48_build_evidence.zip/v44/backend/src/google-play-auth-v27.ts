import {JWT} from 'google-auth-library';

export function googlePlayAuthV27(){
  const packageName=process.env.GOOGLE_PLAY_PACKAGE_NAME;
  const raw=process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON;
  if(!packageName || !raw) throw new Error('GOOGLE_PLAY_CONFIG_MISSING');
  let c:any; try{c=JSON.parse(raw)}catch{throw new Error('GOOGLE_PLAY_SERVICE_ACCOUNT_JSON_INVALID')}
  if(!c.client_email || !c.private_key) throw new Error('GOOGLE_PLAY_SERVICE_ACCOUNT_FIELDS_MISSING');
  return new JWT({email:c.client_email,key:c.private_key,scopes:['https://www.googleapis.com/auth/androidpublisher']});
}
export async function googlePlayAccessTokenV27(){
  const client=googlePlayAuthV27();
  const r=await client.authorize();
  if(!r.access_token) throw new Error('GOOGLE_PLAY_ACCESS_TOKEN_MISSING');
  return r.access_token;
}
