import {FastifyInstance} from 'fastify';
import {decodePubSubV27} from './rtdn-pubsub-v27.js';

export async function registerRtdnV27(app:FastifyInstance){
  app.post('/v1/webhooks/google-play/rtdn',async(req,reply)=>{
    try{
      const x=decodePubSubV27(req.body);
      if(process.env.GOOGLE_PLAY_PACKAGE_NAME && x.packageName!==process.env.GOOGLE_PLAY_PACKAGE_NAME) return reply.code(400).send({error:'package_mismatch'});
      const tokenHash=(await import('node:crypto')).createHash('sha256').update(x.purchaseToken).digest('hex');
      const eventTime=x.eventTimeMillis?new Date(Number(x.eventTimeMillis)):null;
      await app.pg.query(`INSERT INTO billing_events(event_id,event_time_millis,notification_type,notification_name,package_name,purchase_token_hash,created_at) VALUES($1,$2,$3,$4,$5,$6,NOW()) ON CONFLICT(event_id) DO NOTHING`,[x.eventId,x.eventTimeMillis||null,x.notificationType,x.notificationName,x.packageName,tokenHash]);
      return reply.code(202).send({accepted:true,event_id:x.eventId});
    } catch(e:any){app.log.warn(e); return reply.code(400).send({error:'invalid_rtdn'});}
  });
}
