import { assertProductionConfiguration } from "../security/production-bootstrap-v38.js";

export type BillingRuntime = {
  enabled: boolean;
  intervalMs: number;
  projectId: string;
  region: string;
};

export function createBillingRuntime(): BillingRuntime {
  const cfg = assertProductionConfiguration();
  return {
    enabled: cfg.BILLING_WORKER_ENABLED,
    intervalMs: cfg.BILLING_WORKER_INTERVAL_MS,
    projectId: cfg.GOOGLE_CLOUD_PROJECT_ID,
    region: cfg.GCP_REGION,
  };
}
