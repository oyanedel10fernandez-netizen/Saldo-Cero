import postgres from '@fastify/postgres';
import Fastify from 'fastify';
import {processOneBillingJobV37} from './worker-v37.js';
const app=Fastify();
const url=process.env.DATABASE_URL; if(!url) throw new Error('DATABASE_URL_REQUIRED');
await app.register(postgres,{connectionString:url});
let stopping=false; process.on('SIGTERM',()=>{stopping=true}); process.on('SIGINT',()=>{stopping=true});
while(!stopping){ const did=await processOneBillingJobV37((app.pg as any).pool); if(!did) await new Promise(r=>setTimeout(r,1000)); }
await app.close();
