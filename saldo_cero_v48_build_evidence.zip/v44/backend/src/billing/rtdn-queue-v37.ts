import {randomUUID} from 'node:crypto';
export type RtdnQueueJob={id:string;eventId:string;packageName:string;purchaseToken:string;notificationType:number;createdAt:string};
export async function enqueueRtdnV37(db:any,job:Omit<RtdnQueueJob,'id'|'createdAt'>){
  const id=randomUUID();
  await db.query(`INSERT INTO billing_jobs(id,event_id,user_id,product_id,purchase_token,status,next_attempt_at,attempts,created_at,updated_at) VALUES($1,$2,NULL,NULL,$3,'PENDING',NOW(),0,NOW(),NOW()) ON CONFLICT(event_id) DO NOTHING`,[id,job.eventId,job.purchaseToken]);
  return id;
}
