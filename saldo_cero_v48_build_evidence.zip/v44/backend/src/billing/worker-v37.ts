import {fetchGoogleSubscriptionV27} from '../google-play-client-v27.js';
import {applyVerifiedPurchaseV37} from '../billing-store-v37.js';
import {randomUUID} from 'node:crypto';

export async function processOneBillingJobV37(db:any){
  const q=await db.query(`WITH c AS (SELECT id FROM billing_jobs WHERE status='PENDING' AND next_attempt_at<=NOW() ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1) UPDATE billing_jobs j SET status='PROCESSING',locked_at=NOW(),lease_expires_at=NOW()+INTERVAL '2 minutes',attempts=COALESCE(j.attempts,0)+1,updated_at=NOW() FROM c WHERE j.id=c.id RETURNING j.*`);
  const job=q.rows[0]; if(!job)return false;
  try{
    const packageName=process.env.GOOGLE_PLAY_PACKAGE_NAME; if(!packageName)throw new Error('GOOGLE_PLAY_CONFIG_MISSING');
    const raw:any=await fetchGoogleSubscriptionV27(packageName,job.purchase_token);
    const line=(raw.lineItems||[])[0]; if(!line?.productId)throw new Error('GOOGLE_PLAY_PRODUCT_MISSING');
    await applyVerifiedPurchaseV37(db,{eventId:job.event_id||randomUUID(),userId:job.user_id,productId:line.productId,purchaseToken:job.purchase_token,state:String(raw.subscriptionState||''),expiresAt:line.expiryTime||null});
    await db.query(`UPDATE billing_jobs SET status='DONE',lease_expires_at=NULL,updated_at=NOW() WHERE id=$1`,[job.id]);
  }catch(e){
    await db.query(`UPDATE billing_jobs SET status=CASE WHEN attempts>=8 THEN 'DEAD' ELSE 'RETRY' END,lease_expires_at=NULL,next_attempt_at=NOW()+LEAST((2^LEAST(attempts,6))*INTERVAL '10 seconds',INTERVAL '30 minutes'),last_error=$2,updated_at=NOW() WHERE id=$1`,[job.id,String((e as Error)?.message||e)]);
  }
  return true;
}
