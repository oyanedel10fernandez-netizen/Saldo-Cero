import crypto from "node:crypto";

export interface BillingLookup {
  findByPurchaseTokenHash(hash: string): Promise<{ userId: string; productId: string } | null>;
}

export function purchaseTokenHash(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function resolveRtdnJob(
  purchaseToken: string,
  lookup: BillingLookup
): Promise<{ userId: string; productId: string } | null> {
  return lookup.findByPurchaseTokenHash(purchaseTokenHash(purchaseToken));
}
