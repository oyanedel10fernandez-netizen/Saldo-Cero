/**
 * SALDO CERO v19 — Google Play Subscriptions V2 verifier.
 *
 * This module is deliberately credential-agnostic: deployment supplies the
 * Google service-account credentials. The business layer never receives or
 * stores the service-account private key in source control.
 *
 * The HTTP request implementation is isolated behind GooglePlayHttpClient so
 * it can be replaced by the runtime's preferred authenticated Google client.
 */

export type GooglePlayV19State =
  | "ACTIVE"|"CANCELED"|"EXPIRED"|"ON_HOLD"|"GRACE_PERIOD"|"REVOKED";

export type VerifiedPurchaseV19 = {
  productId: string;
  state: GooglePlayV19State;
  expiryTime: string | null;
  autoRenewing: boolean | null;
};

export interface GooglePlayHttpClient {
  getSubscriptionV2(packageName:string, purchaseToken:string):
    Promise<{
      productId?:string;
      subscriptionState?:string;
      lineItems?:Array<{productId?:string; expiryTime?:string; autoRenewingPlan?:unknown}>;
    }>;
}

export function mapGoogleState(state:string|undefined):GooglePlayV19State {
  switch(state) {
    case "SUBSCRIPTION_STATE_ACTIVE": return "ACTIVE";
    case "SUBSCRIPTION_STATE_CANCELED": return "CANCELED";
    case "SUBSCRIPTION_STATE_EXPIRED": return "EXPIRED";
    case "SUBSCRIPTION_STATE_ON_HOLD": return "ON_HOLD";
    case "SUBSCRIPTION_STATE_IN_GRACE_PERIOD": return "GRACE_PERIOD";
    case "SUBSCRIPTION_STATE_REVOKED": return "REVOKED";
    default: throw new Error("UNKNOWN_GOOGLE_SUBSCRIPTION_STATE");
  }
}

export async function verifyPurchaseV19(
  client:GooglePlayHttpClient,
  packageName:string,
  purchaseToken:string
):Promise<VerifiedPurchaseV19> {
  if(!packageName || !purchaseToken) throw new Error("INVALID_GOOGLE_PLAY_INPUT");
  const data=await client.getSubscriptionV2(packageName,purchaseToken);
  const line=data.lineItems?.[0];
  const productId=line?.productId ?? data.productId;
  if(productId!=="saldo_cero_pro_monthly" &&
     productId!=="saldo_cero_premium_monthly") {
    throw new Error("UNEXPECTED_PRODUCT_ID");
  }
  return {
    productId,
    state:mapGoogleState(data.subscriptionState),
    expiryTime:line?.expiryTime ?? null,
    autoRenewing:line?.autoRenewingPlan != null ? true : null
  };
}
