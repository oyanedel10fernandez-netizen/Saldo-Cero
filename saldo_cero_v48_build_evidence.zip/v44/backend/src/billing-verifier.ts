/**
 * V16 Google Play verifier contract.
 *
 * Production implementation:
 * 1. Load GOOGLE_APPLICATION_CREDENTIALS / service-account credentials from a secret manager.
 * 2. Call Google Play Developer API subscriptionsv2.get with packageName + purchaseToken.
 * 3. Validate productId, acknowledgement state and expiry.
 * 4. Map the verified product to PRO/PREMIUM.
 * 5. Upsert subscriptions and entitlement.
 * 6. Revoke/downgrade when Google reports expiry/revocation.
 *
 * Never trust the Android client as the source of entitlement truth.
 */
export async function verifyGooglePlayPurchase(_packageName:string,_productId:string,_purchaseToken:string){
  throw new Error("GOOGLE_PLAY_VERIFIER_NOT_CONFIGURED");
}
