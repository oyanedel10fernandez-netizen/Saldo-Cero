import crypto from "node:crypto";

export type RtdnEnvelopeV21 = {
  message?: {messageId?:string; data?:string};
  subscription?:string;
};

export function decodeRtdnV21(body:RtdnEnvelopeV21) {
  if(!body.message?.data) throw new Error("INVALID_PUBSUB_MESSAGE");
  const raw=Buffer.from(body.message.data,"base64").toString("utf8");
  const payload=JSON.parse(raw);
  const n=payload.subscriptionNotification;
  if(!payload.packageName || !n?.purchaseToken)
    throw new Error("INVALID_RTDN_PAYLOAD");

  return {
    eventId:body.message.messageId ?? crypto.randomUUID(),
    packageName:String(payload.packageName),
    purchaseToken:String(n.purchaseToken),
    notificationType:Number(n.notificationType ?? 0)
  };
}

/**
 * Before accepting a push as processed, production must validate the
 * Pub/Sub push authentication/JWT and confirm the expected topic/subscription.
 */
export function assertExpectedPackage(packageName:string, expected:string) {
  if(packageName!==expected) throw new Error("UNEXPECTED_PACKAGE");
}
