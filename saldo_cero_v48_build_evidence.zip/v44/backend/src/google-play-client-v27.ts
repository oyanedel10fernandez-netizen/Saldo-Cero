import {googlePlayAccessTokenV27} from './google-play-auth-v27.js';

export async function fetchGoogleSubscriptionV27(packageName:string, purchaseToken:string){
  const token=await googlePlayAccessTokenV27();
  const url=`https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(packageName)}/purchases/subscriptionsv2/tokens/${encodeURIComponent(purchaseToken)}`;
  const r=await fetch(url,{headers:{Authorization:`Bearer ${token}`}});
  const text=await r.text();
  if(!r.ok) throw new Error(`GOOGLE_PLAY_HTTP_${r.status}:${text.slice(0,500)}`);
  return JSON.parse(text);
}
