export type AdminPrincipal = {
  userId:string;
  roles:string[];
};

export function requireBillingAdmin(p:AdminPrincipal) {
  if(!p.roles.includes("billing_admin")) {
    throw new Error("FORBIDDEN");
  }
  return true;
}

export function replayAllowed(p:AdminPrincipal,jobId:string) {
  requireBillingAdmin(p);
  if(!jobId) throw new Error("JOB_ID_REQUIRED");
  return {jobId};
}
