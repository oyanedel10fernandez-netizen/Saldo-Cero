export type RtdnV27={eventId:string;packageName:string;purchaseToken:string;notificationType:number;notificationName:string;eventTimeMillis?:string};
const names:Record<number,string>={1:'SUBSCRIPTION_RECOVERED',2:'SUBSCRIPTION_RENEWED',3:'SUBSCRIPTION_CANCELED',4:'SUBSCRIPTION_PURCHASED',5:'SUBSCRIPTION_ON_HOLD',6:'SUBSCRIPTION_IN_GRACE_PERIOD',7:'SUBSCRIPTION_RESTARTED',12:'SUBSCRIPTION_REVOKED',13:'SUBSCRIPTION_EXPIRED',19:'SUBSCRIPTION_PRICE_CHANGE_UPDATED',20:'SUBSCRIPTION_DEFERRED'};
export function decodePubSubV27(body:any):RtdnV27{
  const m=body?.message; if(!m?.data) throw new Error('INVALID_PUBSUB_MESSAGE');
  const data=JSON.parse(Buffer.from(m.data,'base64').toString('utf8'));
  const n=data?.subscriptionNotification; if(!n?.purchaseToken) throw new Error('INVALID_RTDN_NOTIFICATION');
  const eventId=String(m.messageId||m.message_id||`${Date.now()}-${n.purchaseToken.slice(0,12)}`);
  const packageName=String(data.packageName||'');
  const notificationType=Number(n.notificationType);
  return {eventId,packageName,purchaseToken:String(n.purchaseToken),notificationType,notificationName:names[notificationType]||`UNKNOWN_${notificationType}`,eventTimeMillis:data.eventTimeMillis?String(data.eventTimeMillis):undefined};
}
