/** V35 contract for authenticated Pub/Sub push.
 * The production deployment should verify Google's OIDC JWT using a maintained
 * Google-auth library before accepting the decoded Pub/Sub envelope.
 */
export function requirePubSubAudienceV35(expected:string|undefined, actual:string|undefined){
  if(!expected || !actual || expected!==actual) throw new Error('PUBSUB_AUDIENCE_MISMATCH');
}
