/**
 * SALDO CERO V24 — production worker orchestration.
 *
 * This module intentionally depends on interfaces so the deployment can use
 * the existing PostgreSQL pool and Google Play V2 transport without coupling
 * the domain logic to a particular queue provider.
 */
export type ClaimedJob = {
  id:string; eventId:string; userId:string; purchaseToken:string;
  productId:string; attempts:number;
};

export interface QueueV24 {
  claim(limit:number):Promise<ClaimedJob[]>;
  complete(id:string):Promise<void>;
  retry(id:string,error:string,nextAttemptAt:Date):Promise<void>;
  dead(id:string,error:string):Promise<void>;
}

export interface PlayVerifierV24 {
  verify(input:{packageName:string,productId:string,purchaseToken:string}):
    Promise<{state:string;expiresAt:string|null;acknowledged:boolean}>;
}

export interface BillingStoreV24 {
  applyVerifiedPurchase(input:{
    eventId:string; userId:string; productId:string;
    purchaseToken:string; lifecycleState:string; expiresAt:string|null;
  }):Promise<void>;
}

export async function processJob(
  job:ClaimedJob,
  deps:{queue:QueueV24; verifier:PlayVerifierV24; store:BillingStoreV24},
  packageName:string
) {
  try {
    const v=await deps.verifier.verify({
      packageName, productId:job.productId, purchaseToken:job.purchaseToken
    });
    await deps.store.applyVerifiedPurchase({
      eventId:job.eventId,userId:job.userId,productId:job.productId,
      purchaseToken:job.purchaseToken,lifecycleState:v.state,expiresAt:v.expiresAt
    });
    await deps.queue.complete(job.id);
  } catch (e) {
    const message=e instanceof Error?e.message:"billing_worker_error";
    if(job.attempts>=8) await deps.queue.dead(job.id,message);
    else {
      const seconds=Math.min(3600,15*2**Math.max(0,job.attempts-1));
      await deps.queue.retry(job.id,message,new Date(Date.now()+seconds*1000));
    }
  }
}
