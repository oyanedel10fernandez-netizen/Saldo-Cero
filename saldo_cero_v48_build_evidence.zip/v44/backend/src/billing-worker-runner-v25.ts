/**
 * V25 worker runner.
 * The actual dependency implementations are injected by the server entrypoint.
 */
export async function runBillingWorkerV25(
  deps:{
    claim(limit:number):Promise<any[]>;
    process(job:any):Promise<void>;
  },
  opts:{batchSize?:number; idleMs?:number; signal?:AbortSignal}={}
) {
  const batchSize=opts.batchSize ?? 10;
  const idleMs=opts.idleMs ?? 1000;

  while(!opts.signal?.aborted) {
    const jobs=await deps.claim(batchSize);
    if(!jobs.length) {
      await new Promise(r=>setTimeout(r,idleMs));
      continue;
    }
    for(const job of jobs) {
      if(opts.signal?.aborted) break;
      await deps.process(job);
    }
  }
}
