/**
 * SALDO CERO V42 — Resilient Production HUB
 * Orchestrates readiness stages without aborting the entire process after one failure.
 */
export type HubStageStatus = "PASS" | "WARN" | "FAIL" | "SKIP";

export interface HubStageResult {
  id: string;
  status: HubStageStatus;
  startedAt: string;
  finishedAt: string;
  durationMs: number;
  summary: string;
  details?: unknown;
}

export interface HubRunResult {
  runId: string;
  version: string;
  status: "READY" | "BLOCKED" | "PARTIAL";
  startedAt: string;
  finishedAt: string;
  stages: HubStageResult[];
  blockers: string[];
  warnings: string[];
}

export interface HubStage {
  id: string;
  run(ctx: Record<string, unknown>): Promise<Omit<HubStageResult, "id" | "startedAt" | "finishedAt" | "durationMs">>;
}

export class ProductionHubV42 {
  constructor(private readonly stages: HubStage[]) {}

  async run(ctx: Record<string, unknown> = {}): Promise<HubRunResult> {
    const runId = `hub-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const startedAt = new Date().toISOString();
    const results: HubStageResult[] = [];

    for (const stage of this.stages) {
      const t0 = Date.now();
      const stageStart = new Date(t0).toISOString();
      try {
        const r = await stage.run(ctx);
        results.push({
          id: stage.id, ...r,
          startedAt: stageStart,
          finishedAt: new Date().toISOString(),
          durationMs: Date.now() - t0,
        });
      } catch (error) {
        // Critical resilience rule: record the failure and continue to the next independent stage.
        results.push({
          id: stage.id,
          status: "FAIL",
          summary: "Stage failed; subsequent independent stages were still evaluated.",
          details: { error: error instanceof Error ? error.message : String(error) },
          startedAt: stageStart,
          finishedAt: new Date().toISOString(),
          durationMs: Date.now() - t0,
        });
      }
    }

    const blockers = results.filter(x => x.status === "FAIL").map(x => `${x.id}: ${x.summary}`);
    const warnings = results.filter(x => x.status === "WARN").map(x => `${x.id}: ${x.summary}`);
    const status = blockers.length ? "BLOCKED" : warnings.length ? "PARTIAL" : "READY";

    return {
      runId, version: "42.0.0", status,
      startedAt, finishedAt: new Date().toISOString(),
      stages: results, blockers, warnings
    };
  }
}
