export type RtdnV19 = {
  packageName:string;
  purchaseToken:string;
  notificationType:
    | "SUBSCRIPTION_RECOVERED"
    | "SUBSCRIPTION_RENEWED"
    | "SUBSCRIPTION_CANCELED"
    | "SUBSCRIPTION_PURCHASED"
    | "SUBSCRIPTION_ON_HOLD"
    | "SUBSCRIPTION_IN_GRACE_PERIOD"
    | "SUBSCRIPTION_EXPIRED"
    | "SUBSCRIPTION_REVOKED";
};

export function shouldReconcile(event:RtdnV19):boolean {
  return Boolean(event.packageName && event.purchaseToken);
}
