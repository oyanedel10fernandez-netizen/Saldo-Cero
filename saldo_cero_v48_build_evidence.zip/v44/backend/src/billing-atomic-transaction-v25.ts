/**
 * V25 atomicity contract.
 *
 * The supplied transaction client must represent one PostgreSQL transaction.
 * Replace the SQL placeholders with the project's exact schema names if they
 * differ. No entitlement should be granted outside this transaction.
 */
export async function applyVerifiedPurchaseV25(
  tx:{query(text:string,values?:unknown[]):Promise<{rows:unknown[]}>},
  input:{
    eventId:string; userId:string; productId:string;
    purchaseTokenHash:string; lifecycleState:string;
    expiresAt:string|null;
  }
) {
  await tx.query("BEGIN");
  try {
    await tx.query(`
      INSERT INTO billing_purchases
        (user_id,product_id,purchase_token_hash,purchase_state,expires_at,verified_at)
      VALUES ($1,$2,$3,$4,$5,NOW())
      ON CONFLICT (purchase_token_hash)
      DO UPDATE SET purchase_state=EXCLUDED.purchase_state,
                    expires_at=EXCLUDED.expires_at,
                    verified_at=NOW()
    `,[
      input.userId,input.productId,input.purchaseTokenHash,
      input.lifecycleState,input.expiresAt
    ]);

    const paid =
      input.lifecycleState==="ACTIVE" ||
      input.lifecycleState==="GRACE_PERIOD";
    const plan =
      !paid ? "FREE" :
      input.productId==="saldo_cero_premium_monthly" ? "PREMIUM" : "PRO";

    await tx.query(`
      INSERT INTO subscriptions
        (user_id,plan,status,product_id,expires_at,updated_at)
      VALUES ($1,$2,$3,$4,$5,NOW())
      ON CONFLICT (user_id)
      DO UPDATE SET plan=EXCLUDED.plan,status=EXCLUDED.status,
                    product_id=EXCLUDED.product_id,
                    expires_at=EXCLUDED.expires_at,updated_at=NOW()
    `,[
      input.userId,plan,paid ? "ACTIVE" : "EXPIRED",
      paid ? input.productId : null,input.expiresAt
    ]);

    await tx.query(`
      INSERT INTO billing_events(event_id,event_type,purchase_token_hash,created_at)
      VALUES ($1,'VERIFIED',$2,NOW())
      ON CONFLICT (event_id) DO NOTHING
    `,[input.eventId,input.purchaseTokenHash]);

    await tx.query("COMMIT");
  } catch(e) {
    await tx.query("ROLLBACK");
    throw e;
  }
}
