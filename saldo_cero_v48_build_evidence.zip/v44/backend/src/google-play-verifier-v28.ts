import {fetchGoogleSubscriptionV27} from './google-play-client-v27.js';

export type VerifiedSubscriptionV35 = {
  productId:string; state:string; expiresAt:string|null; acknowledged:boolean;
};

const ALLOWED = new Set(['saldo_cero_pro_monthly','saldo_cero_premium_monthly']);

export async function verifyGooglePurchaseV35(input:{packageName:string; productId:string; purchaseToken:string}):Promise<VerifiedSubscriptionV35>{
  if(!ALLOWED.has(input.productId)) throw new Error('GOOGLE_PLAY_UNKNOWN_PRODUCT');
  const raw:any = await fetchGoogleSubscriptionV27(input.packageName,input.purchaseToken);
  const line = Array.isArray(raw.lineItems) ? raw.lineItems.find((x:any)=>x.productId===input.productId) : null;
  if(!line) throw new Error('GOOGLE_PLAY_PRODUCT_MISMATCH');
  const expiry = line.expiryTime || null;
  const state = String(raw.subscriptionState || 'SUBSCRIPTION_STATE_UNSPECIFIED');
  const acknowledged = Boolean(raw.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED');
  return {productId:input.productId,state,expiresAt:expiry,acknowledged};
}
