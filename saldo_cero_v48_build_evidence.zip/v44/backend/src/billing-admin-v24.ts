/**
 * Authorized operational actions for billing incidents.
 * Wire these handlers to authenticated admin routes only.
 */
export type BillingAdminRepositoryV24 = {
  getQueueStats():Promise<Record<string,number>>;
  replayDeadJob(id:string):Promise<boolean>;
};

export async function billingHealth(repo:BillingAdminRepositoryV24) {
  return {ok:true,queue:await repo.getQueueStats()};
}

export async function replayBillingJob(
  repo:BillingAdminRepositoryV24,id:string
) {
  if(!id) throw new Error("JOB_ID_REQUIRED");
  return {replayed:await repo.replayDeadJob(id)};
}
