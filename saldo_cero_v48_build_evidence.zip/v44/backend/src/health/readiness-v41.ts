export interface ReadinessDependency {
  name: string;
  check(): Promise<void>;
}

export async function readinessChecks(deps: ReadinessDependency[]) {
  const results = await Promise.all(deps.map(async d => {
    const started = Date.now();
    try {
      await d.check();
      return { name: d.name, ok: true, latency_ms: Date.now() - started };
    } catch {
      return { name: d.name, ok: false, latency_ms: Date.now() - started };
    }
  }));
  return { ok: results.every(x => x.ok), dependencies: results };
}
