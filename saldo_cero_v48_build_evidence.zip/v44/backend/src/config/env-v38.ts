import { z } from "zod";

const productionSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "staging", "production"]).default("production"),
  PORT: z.coerce.number().int().positive().default(8080),
  GOOGLE_PLAY_PACKAGE_NAME: z.string().min(1),
  GOOGLE_PLAY_SERVICE_ACCOUNT_JSON: z.string().min(1),
  DATABASE_URL: z.string().url(),
  REDIS_URL: z.string().min(1),
  JWT_SECRET: z.string().min(32),
  PUBSUB_AUDIENCE: z.string().url(),
  PUBSUB_SERVICE_ACCOUNT: z.string().email(),
  GOOGLE_CLOUD_PROJECT_ID: z.string().min(1),
  GCP_REGION: z.string().min(1),
  BILLING_WORKER_ENABLED: z.coerce.boolean().default(true),
  BILLING_WORKER_INTERVAL_MS: z.coerce.number().int().min(1000).default(5000),
});

export type V38Config = z.infer<typeof productionSchema>;

export function loadV38Config(env: NodeJS.ProcessEnv = process.env): V38Config {
  const parsed = productionSchema.safeParse(env);
  if (!parsed.success) {
    const issues = parsed.error.issues.map(i => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new Error(`V38 production configuration invalid: ${issues}`);
  }
  return parsed.data;
}
