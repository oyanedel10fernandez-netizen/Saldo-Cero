import {fetchGoogleSubscriptionV27} from './google-play-client-v27.js';
export type VerifiedPlayV37={state:string;expiresAt:string|null;acknowledgementState:string;autoRenewing:boolean;productId:string};
const allowed=new Set(['saldo_cero_pro_monthly','saldo_cero_premium_monthly']);
export async function verifyGooglePurchaseV37(args:{packageName:string;productId:string;purchaseToken:string}):Promise<VerifiedPlayV37>{
  if(!allowed.has(args.productId)) throw new Error('unsupported_product');
  const raw:any=await fetchGoogleSubscriptionV27(args.packageName,args.purchaseToken);
  const line=(raw.lineItems||[]).find((x:any)=>x.productId===args.productId);
  if(!line) throw new Error('product_not_in_purchase');
  return {state:String(raw.subscriptionState||''),expiresAt:line.expiryTime||null,acknowledgementState:String(raw.acknowledgementState||''),autoRenewing:Boolean(line.autoRenewingPlan?.autoRenewEnabled),productId:line.productId};
}
