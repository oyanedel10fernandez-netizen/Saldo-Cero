/**
 * Google Cloud Pub/Sub / Real-time Developer Notifications contract.
 *
 * V18 defines the boundary. Production deployment should:
 * 1) create a Pub/Sub topic/subscription in Google Cloud;
 * 2) configure Google Play RTDN for the app;
 * 3) validate the Pub/Sub push/JWT;
 * 4) decode the notification and reconcile by purchase token;
 * 5) acknowledge the message only after durable processing.
 */

export type RtdnEventType =
  | "SUBSCRIPTION_RECOVERED"
  | "SUBSCRIPTION_RENEWED"
  | "SUBSCRIPTION_CANCELED"
  | "SUBSCRIPTION_PURCHASED"
  | "SUBSCRIPTION_ON_HOLD"
  | "SUBSCRIPTION_IN_GRACE_PERIOD"
  | "SUBSCRIPTION_EXPIRED"
  | "SUBSCRIPTION_REVOKED";

export type RtdnEvent = {
  packageName: string;
  purchaseToken: string;
  eventType: RtdnEventType;
};
