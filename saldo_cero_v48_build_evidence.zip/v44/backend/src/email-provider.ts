export type EmailProvider = { sendReset(to:string, resetUrl:string): Promise<void> };
export function createEmailProviderFromEnv(): EmailProvider | null {
  const url=process.env.EMAIL_PROVIDER_URL, key=process.env.EMAIL_PROVIDER_API_KEY;
  if(!url||!key) return null;
  return {async sendReset(to,resetUrl){
    const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${key}`},body:JSON.stringify({to,template:'password_reset',reset_url:resetUrl})});
    if(!r.ok) throw new Error(`email_provider_http_${r.status}`);
  }};
}
