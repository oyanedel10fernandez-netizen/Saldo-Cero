import {Pool, PoolClient} from 'pg';

export async function applyVerifiedPurchaseV35(pool:Pool,input:{eventId:string;userId:string;productId:string;purchaseToken:string;state:string;expiresAt:string|null}){
  const client:PoolClient=await pool.connect();
  const tokenHash=(await import('node:crypto')).createHash('sha256').update(input.purchaseToken).digest('hex');
  const plan=input.productId==='saldo_cero_premium_monthly'?'PREMIUM':'PRO';
  const active=input.state==='SUBSCRIPTION_STATE_ACTIVE' && !!input.expiresAt && new Date(input.expiresAt).getTime()>Date.now();
  try{
    await client.query('BEGIN');
    await client.query(`INSERT INTO billing_purchases(id,user_id,product_id,purchase_token_hash,purchase_state,verified_at,expires_at)
      VALUES(gen_random_uuid(),$1,$2,$3,$4,NOW(),$5)
      ON CONFLICT(purchase_token_hash) DO UPDATE SET purchase_state=EXCLUDED.purchase_state,verified_at=NOW(),expires_at=EXCLUDED.expires_at`,
      [input.userId,input.productId,tokenHash,input.state,input.expiresAt]);
    await client.query(`INSERT INTO subscriptions(id,user_id,provider,external_id,status,renews_at,plan,product_id)
      VALUES(gen_random_uuid(),$1,'GOOGLE_PLAY',$2,$3,$4,$5,$6)
      ON CONFLICT(user_id,provider,external_id) DO UPDATE SET status=EXCLUDED.status,renews_at=EXCLUDED.renews_at,plan=EXCLUDED.plan,product_id=EXCLUDED.product_id`,
      [input.userId,tokenHash,active?'ACTIVE':'INACTIVE',input.expiresAt,plan,input.productId]);
    await client.query(`INSERT INTO billing_events(event_id,event_time_millis,notification_type,notification_name,package_name,purchase_token_hash,processed_at,created_at)
      VALUES($1,$2,$3,$4,$5,$6,NOW(),NOW()) ON CONFLICT(event_id) DO UPDATE SET processed_at=NOW()`,
      [input.eventId,Date.now(),'VERIFIED','VERIFIED_PURCHASE',process.env.GOOGLE_PLAY_PACKAGE_NAME||'',tokenHash]);
    await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK');throw e}finally{client.release()}
}
