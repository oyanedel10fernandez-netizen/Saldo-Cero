import {missingProductionEnv} from '../security/security-config-v37.js';
const required=['JWT_SECRET','DATABASE_URL','REDIS_URL','GOOGLE_PLAY_PACKAGE_NAME','GOOGLE_PLAY_SERVICE_ACCOUNT_JSON','PUBSUB_OIDC_AUDIENCE','PUBSUB_SERVICE_ACCOUNT','GCP_PROJECT_ID'];
const missing=missingProductionEnv({});
if(JSON.stringify(missing)!==JSON.stringify(required)) throw new Error('production config gate mismatch');
console.log('V37 config smoke: PASS');
