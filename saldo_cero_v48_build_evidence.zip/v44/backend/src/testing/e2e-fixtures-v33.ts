export const e2e = {
  user: {email:"e2e@example.invalid", password:"TEST_ONLY_NOT_PRODUCTION"},
  debt: {name:"Tarjeta E2E", balance:100000, installment:10000, interestRate:2.5},
  products: ["saldo_cero_pro_monthly","saldo_cero_premium_monthly"]
} as const;
