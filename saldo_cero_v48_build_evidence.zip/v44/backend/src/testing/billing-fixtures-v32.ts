export const billingFixtures = {
  activePro: { productId:"saldo_cero_pro_monthly", state:"SUBSCRIPTION_STATE_ACTIVE", acknowledged:true, expiryFuture:true },
  activePremium: { productId:"saldo_cero_premium_monthly", state:"SUBSCRIPTION_STATE_ACTIVE", acknowledged:true, expiryFuture:true },
  expired: { productId:"saldo_cero_pro_monthly", state:"SUBSCRIPTION_STATE_EXPIRED", acknowledged:true, expiryFuture:false },
  revoked: { productId:"saldo_cero_pro_monthly", state:"SUBSCRIPTION_STATE_CANCELED", acknowledged:true, expiryFuture:false },
  pending: { productId:"saldo_cero_pro_monthly", state:"SUBSCRIPTION_STATE_PENDING", acknowledged:false, expiryFuture:true }
} as const;
