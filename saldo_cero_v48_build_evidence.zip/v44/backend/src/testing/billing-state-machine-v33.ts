export type BillingState = "PENDING"|"ACTIVE"|"EXPIRED"|"REVOKED"|"FAILED";

export function expectedEntitlement(state:BillingState, expiryMs:number|null, nowMs=Date.now()) {
  const active = state==="ACTIVE" && expiryMs!==null && expiryMs>nowMs;
  return {active, plan:active ? "PAID" : "FREE"};
}
