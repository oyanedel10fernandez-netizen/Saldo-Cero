export interface StagingCheck {
  name: string;
  required: boolean;
  run: () => Promise<void>;
}

export async function runStagingChecks(checks: StagingCheck[]) {
  const results: Array<{name:string; ok:boolean; error?:string}> = [];
  for (const c of checks) {
    try { await c.run(); results.push({name:c.name, ok:true}); }
    catch (e) { results.push({name:c.name, ok:false, error:String(e)}); if (c.required) break; }
  }
  return { ok: results.every(r => r.ok), results };
}
