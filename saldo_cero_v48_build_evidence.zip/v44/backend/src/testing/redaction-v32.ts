const SECRET_KEYS = /token|password|secret|private.?key|authorization|cookie/i;

export function redactSecrets(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(redactSecrets);
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k,v] of Object.entries(value)) out[k] = SECRET_KEYS.test(k) ? "[REDACTED]" : redactSecrets(v);
    return out;
  }
  return value;
}
