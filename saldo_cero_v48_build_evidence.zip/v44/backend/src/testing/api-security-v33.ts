export function assertNoSensitiveKeys(value:unknown, path="root"):string[] {
  const bad:string[]=[];
  const rx=/(password|token|secret|private.?key|authorization|cookie)/i;
  if (value && typeof value==="object") {
    for (const [k,v] of Object.entries(value as Record<string,unknown>)) {
      if (rx.test(k)) bad.push(path+"."+k);
      else bad.push(...assertNoSensitiveKeys(v,path+"."+k));
    }
  }
  return bad;
}
