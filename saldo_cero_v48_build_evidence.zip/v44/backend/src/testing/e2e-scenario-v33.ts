export type E2EStep = { name:string; run:()=>Promise<void> };

export async function runScenario(steps:E2EStep[]) {
  const results:{name:string;ok:boolean;error?:string}[]=[];
  for (const step of steps) {
    try { await step.run(); results.push({name:step.name,ok:true}); }
    catch (e) { results.push({name:step.name,ok:false,error:String(e)}); break; }
  }
  return {ok:results.every(x=>x.ok),results};
}

export const criticalFlows = [
  "register -> login -> create debt -> calculate plan -> entitlement",
  "purchase token -> server verification -> persisted entitlement",
  "RTDN -> durable event -> billing worker -> entitlement update",
  "duplicate purchase/event -> idempotent result",
  "expired/revoked subscription -> paid access removed"
] as const;
