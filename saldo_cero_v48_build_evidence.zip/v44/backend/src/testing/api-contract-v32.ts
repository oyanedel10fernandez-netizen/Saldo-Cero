export const criticalApiPaths = [
  "/health", "/ready", "/v1/auth/register", "/v1/auth/login",
  "/v1/debts", "/v1/plan", "/v1/entitlement",
  "/v1/subscription/verify", "/v1/webhooks/google-play/rtdn"
] as const;

export const expectedSecurityHeaders = ["content-type"];
