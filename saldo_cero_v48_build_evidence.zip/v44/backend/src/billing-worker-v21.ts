/**
 * V21 worker orchestration.
 *
 * Each job must be idempotent. A failed DB transaction must leave the event
 * eligible for retry. A successful transaction must make the event durable
 * before the Pub/Sub message is acknowledged.
 */
export type BillingJobV21 = {
  eventId:string;
  purchaseToken:string;
  reason:"RTDN"|"VERIFY"|"RECONCILIATION";
};

export async function processBillingJobV21(job:BillingJobV21) {
  if(!job.eventId || !job.purchaseToken) throw new Error("INVALID_BILLING_JOB");
  return {
    accepted:true,
    retryableOnFailure:true,
    acknowledgeOnlyAfterCommit:true
  };
}
