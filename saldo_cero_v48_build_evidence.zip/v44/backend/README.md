# SALDO CERO v7 API

Runnable Fastify/TypeScript backend foundation.

## Local
npm install
npm run dev

Health:
GET http://localhost:8080/health

## Important
The sample uses an in-memory user/debt store so the project can be inspected without provisioning cloud services. PostgreSQL is included in docker-compose and the schema should be migrated before production.

Replace DEV JWT secret and configure a real secret manager before deployment.
AI/payment credentials must remain server-side.
