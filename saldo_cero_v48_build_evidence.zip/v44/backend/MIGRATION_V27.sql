CREATE TABLE IF NOT EXISTS billing_events (
 event_id TEXT PRIMARY KEY,
 event_time_millis BIGINT,
 notification_type INTEGER,
 notification_name TEXT,
 package_name TEXT,
 purchase_token_hash TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS billing_events_created_idx ON billing_events(created_at);
CREATE INDEX IF NOT EXISTS billing_events_token_idx ON billing_events(purchase_token_hash);
CREATE TABLE IF NOT EXISTS billing_jobs (
 id UUID PRIMARY KEY,
 event_id TEXT NOT NULL,
 user_id UUID,
 product_id TEXT,
 purchase_token_encrypted TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'PENDING',
 attempts INTEGER NOT NULL DEFAULT 0,
 next_attempt_at TIMESTAMPTZ,
 locked_at TIMESTAMPTZ,
 last_error TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS billing_jobs_event_idx ON billing_jobs(event_id);
CREATE INDEX IF NOT EXISTS billing_jobs_claim_idx ON billing_jobs(status,next_attempt_at,created_at);
