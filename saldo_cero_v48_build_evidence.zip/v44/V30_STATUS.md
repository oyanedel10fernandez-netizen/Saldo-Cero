# SALDO CERO V35

## Goal
Automate reproducible production deployment while keeping credentials outside the repository.

## Added
- GitHub Actions CI/CD workflow
- Google Cloud OIDC / Workload Identity Federation integration
- Docker -> Artifact Registry -> Cloud Run deployment path
- automated health smoke test
- production migration policy
- release checklist
- explicit separation between deployment credentials and Google Play runtime credentials

## Not connected
There is still no live Google Cloud project, Cloud SQL instance, Pub/Sub subscription, domain, or Google Play credential embedded in this package. These require the owner's accounts and configuration.
