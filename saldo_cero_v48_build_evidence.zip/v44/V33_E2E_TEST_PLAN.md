# SALDO CERO V35 — E2E

## Flujo 1: Usuario
Registro -> login -> sesión segura -> crear deuda -> consultar deudas -> calcular plan -> consultar entitlement.

## Flujo 2: Compra
Android Billing -> purchase token -> POST verify -> Google Play V2 server verification -> transacción DB -> entitlement.

## Flujo 3: Ciclo de vida
RTDN -> webhook autenticado -> billing event idempotente -> cola -> worker -> Google Play reconsulta -> entitlement actualizado.

## Casos obligatorios
- PRO activo
- PREMIUM activo
- compra duplicada
- RTDN duplicado
- expiración
- cancelación/revocación
- Google Play timeout/5xx
- DB transaction rollback
- reintento y dead job
- usuario sin entitlement

## Criterio de salida
Todos los flujos críticos pasan en staging y no existe secreto real en fixtures/logs.
