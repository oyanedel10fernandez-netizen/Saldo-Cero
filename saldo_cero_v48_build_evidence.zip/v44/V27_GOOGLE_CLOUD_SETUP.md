# V27 — checklist de conexión real

## Google Cloud
- Crear proyecto dedicado a SALDO CERO.
- Habilitar Google Play Android Developer API y Cloud Pub/Sub API.
- Crear service account exclusiva del backend.
- En Play Console, conceder a esa cuenta solo los permisos necesarios para administrar/consultar suscripciones.

## Pub/Sub / RTDN
- Configurar Real-time developer notifications en Play Console hacia un tópico Pub/Sub del proyecto.
- Crear push subscription HTTPS apuntando a `https://api.saldocero.cl/v1/webhooks/google-play/rtdn`.
- Exigir autenticación OIDC y validar `aud` contra `PUBSUB_AUDIENCE` en producción.
- Mantener deduplicación por `messageId`.

## PostgreSQL / Cloud SQL
- Crear instancia PostgreSQL de producción.
- Activar TLS y usar `sslmode=require`.
- Aplicar `schema.sql` y luego `MIGRATION_V27.sql`.
- Usar usuario de aplicación con privilegios mínimos.
- Backups automáticos + PITR + alertas.

## Secretos
Nunca subir JSON de service account, passwords, JWT secret o DATABASE_URL al Git. Usar Secret Manager/variables protegidas del proveedor de despliegue.
