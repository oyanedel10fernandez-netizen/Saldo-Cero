# SALDO CERO V35 — Security Integration
- Rate limiting compartido para Cloud Run; no depender de memoria local.
- OIDC Pub/Sub: validar firma/issuer, audience exacta, service account esperada y expiración antes de persistir RTDN.
- Secretos en Secret Manager.
- Límites de tamaño de requests.
- Auditoría de eventos críticos.
