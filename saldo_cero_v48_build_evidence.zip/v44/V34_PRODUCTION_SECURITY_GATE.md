# V35 Production Security Gate

No production billing traffic until:
1. Pub/Sub OIDC validation is live and tested.
2. Cloud Run invoker permission is least-privilege.
3. Rate limiting uses shared infrastructure.
4. Secrets are in Secret Manager.
5. Security headers and request-size limits are active.
6. Auth and webhook abuse tests pass.
7. Audit logs are retained and protected.
8. E2E V33 passes after hardening.
