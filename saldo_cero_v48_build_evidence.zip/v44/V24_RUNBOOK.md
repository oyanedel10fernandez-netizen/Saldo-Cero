# V24 deployment runbook

1. Provision PostgreSQL and run schema migrations.
2. Store Google Play service-account credentials in a secret manager.
3. Configure package name and approved subscription product IDs.
4. Deploy RTDN Pub/Sub endpoint.
5. Start billing worker with least-privilege DB credentials.
6. Verify: purchase -> RTDN -> job -> Google verification -> entitlement.
7. Force a transient failure and confirm RETRY/backoff.
8. Force repeated failure and confirm DEAD + admin replay.
9. Confirm duplicate RTDN/purchase event is idempotent.
10. Confirm expired/revoked subscription downgrades to FREE.
11. Review logs to ensure no tokens or credentials are emitted.
12. Only then enable production Play subscription rollout.
