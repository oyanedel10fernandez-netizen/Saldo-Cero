# SALDO CERO V35

## Hecho
- Verificación server-side de Google Play Subscriptions V2 integrada en el endpoint de compra.
- OAuth2 con `google-auth-library` usando Service Account.
- Aplicación transaccional de compra verificada a PostgreSQL.
- Idempotencia por token y por evento.
- Endpoint `/ready` para DB/configuración.
- Dockerfile multi-stage para Cloud Run.
- Manifiesto Cloud Run con Secret Manager.
- Migración PostgreSQL V35.
- Guía de Cloud Run, Cloud SQL, Pub/Sub y secretos.

## Aún NO conectado
- No existe un proyecto Google Cloud real conectado desde este entorno.
- No hay credenciales reales almacenadas.
- No hay Cloud SQL de producción.
- No hay tópico/suscripción Pub/Sub reales.
- No se ha desplegado `api.saldocero.cl`.
- No se ha ejecutado una compra real/sandbox contra Google Play desde este entorno.

## Criterio de producción
La app solo debe mostrar Pro/Premium cuando el backend haya verificado la compra contra Google Play y persistido el entitlement. Nunca confiar en el estado enviado por Android.
