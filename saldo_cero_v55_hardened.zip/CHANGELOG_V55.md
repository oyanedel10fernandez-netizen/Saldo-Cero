# CHANGELOG V55

- Base directa V54.
- Hardened Android compilation.
- Hardened Billing 7.1.1 integration.
- Hardened GitHub Actions artifact generation.
- Version 55.0.0.
