# SALDO CERO V55 — BASE V54 + HARDENED BUILD

V55 se basa directamente en V54.

## Objetivo
Eliminar los problemas de compilación Android detectados durante V50–V53 y producir APK Debug + AAB Release como artifacts de GitHub Actions.

## Correcciones
- Billing Library 7.1.1: `queryProductDetailsAsync` consume la lista directamente con `firstOrNull()`.
- Eliminado `QueryProductDetailsResult`.
- Eliminado acceso `detailsResult.productDetailsList` incompatible con Billing 7.1.1.
- `Modifier.width` usa `androidx.compose.foundation.layout.width` mediante import explícito.
- Coroutines Android 1.9.0 declaradas.
- Kotlin 1.9.25 + Compose compiler 1.5.15 alineados.
- Java 21 y Gradle 8.9.
- MainActivity reescrita con sintaxis Kotlin válida y llamadas Compose explícitas.
- Billing lifecycle corregido para conectar/restaurar sobre la instancia creada.
- Workflow separado Backend/Android.
- APK y AAB se copian y publican como artifact.
- Verificación estática V55 incluida.

## No afirmado
No se afirma que V55 haya pasado GitHub Actions hasta ejecutar el workflow real.
