# SALDO CERO V54 — BASE ESTABLE

V54 parte directamente de V48, la base que obtuvo build verde en GitHub Actions.

## Correcciones de V53 incorporadas

- Billing Library 7.1.1: `queryProductDetailsAsync` usa directamente `detailsResult.firstOrNull()`.
- No se usa `androidx.compose.ui.unit.width`; `Modifier.width` proviene de `androidx.compose.foundation.layout` (V48 ya usa el wildcard correcto).
- `kotlinx-coroutines-android:1.9.0` queda declarada explícitamente.
- Android versionCode/versionName: 54.0.0.
- Se conserva Gradle 8.9, Java 21 y Kotlin 1.9.25.
- Workflow independiente para Backend y Android, con APK Debug + AAB Release como artifacts.

No contiene credenciales ni conexiones reales de producción.
