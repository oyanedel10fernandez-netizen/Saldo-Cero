# Changelog V54
- Base directa: V48.
- Fix Billing Library 7.1.1.
- Fix `Modifier.width`.
- Coroutines Android explícitas.
- Android 54.0.0.
- Workflow limpio Backend + APK + AAB.
