# V54 FIXES

Base directa: V48.

1. Corregido callback de Billing Library 7.1.1: `detailsResult.firstOrNull()`.
2. Eliminado cualquier import incorrecto de `androidx.compose.ui.unit.width`.
3. Coroutines Android declaradas explícitamente.
4. Workflow V54 publica APK y AAB.
