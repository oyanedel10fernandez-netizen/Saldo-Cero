package cl.saldocero.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

fun money(cents: Long): String =
    "$" + String.format(Locale.US, "%,d", cents / 100L).replace(',', '.')

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val appRoutes = listOf(
    "Inicio" to "home",
    "Deudas" to "debts",
    "Plan" to "plan",
    "IA" to "ai",
    "Perfil" to "profile"
)

@Composable
fun App() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    var access by remember { mutableStateOf(SecureSession.access(context)) }
    var error by remember { mutableStateOf("") }

    if (access == null) {
        AuthScreen(
            login = { email, password ->
                scope.launch {
                    runCatching {
                        withContext(Dispatchers.IO) { ApiClient.login(email, password) }
                    }.onSuccess {
                        SecureSession.save(context, it.access, it.refresh)
                        access = it.access
                        error = ""
                    }.onFailure {
                        error = it.message ?: "Error de conexión"
                    }
                }
            },
            register = { email, password ->
                scope.launch {
                    runCatching {
                        withContext(Dispatchers.IO) { ApiClient.register(email, password) }
                    }.onSuccess {
                        SecureSession.save(context, it.access, it.refresh)
                        access = it.access
                        error = ""
                    }.onFailure {
                        error = it.message ?: "No se pudo crear la cuenta"
                    }
                }
            },
            error = error
        )
        return
    }

    val token = access ?: return

    Scaffold(
        bottomBar = {
            NavigationBar {
                appRoutes.forEach { (label, route) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = {
                            if (currentRoute != route) {
                                navController.navigate(route) {
                                    launchSingleTop = true
                                }
                            }
                        },
                        icon = { Text(label.take(1)) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("home") { Home(token) }
            composable("debts") { Debts(token) }
            composable("plan") { Plan(token) }
            composable("ai") { AI(token) }
            composable("profile") {
                Profile {
                    SecureSession.clear(context)
                    access = null
                }
            }
        }
    }
}

@Composable
fun AuthScreen(
    login: (String, String) -> Unit,
    register: (String, String) -> Unit,
    error: String
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var createAccount by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("SALDO CERO", style = MaterialTheme.typography.headlineLarge)
        Text(if (createAccount) "Crear cuenta" else "Iniciar sesión")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Correo") },
            singleLine = true
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Contraseña") },
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (createAccount) register(email.trim(), password) else login(email.trim(), password)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (createAccount) "Crear cuenta" else "Entrar")
        }
        TextButton(onClick = { createAccount = !createAccount }) {
            Text(if (createAccount) "Ya tengo cuenta" else "Crear cuenta")
        }
        if (error.isNotBlank()) {
            Text(error, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
fun Home(token: String) {
    var debts by remember { mutableStateOf<List<DebtDto>>(emptyList()) }
    var message by remember { mutableStateOf("Cargando…") }

    LaunchedEffect(token) {
        runCatching {
            withContext(Dispatchers.IO) { ApiClient.debts(token) }
        }.onSuccess {
            debts = it
            message = ""
        }.onFailure {
            message = "No se pudieron cargar tus datos: ${it.message ?: "error"}"
        }
    }

    Column(Modifier.padding(20.dp)) {
        Text("SALDO CERO", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))
        Card {
            Column(Modifier.padding(20.dp)) {
                Text("Deuda total")
                Text(
                    money(debts.sumOf { it.balanceCents }),
                    style = MaterialTheme.typography.headlineMedium
                )
                Text("${debts.size} deudas")
            }
        }
        if (message.isNotBlank()) Text(message)
    }
}

@Composable
fun Debts(token: String) {
    val scope = rememberCoroutineScope()
    var debts by remember { mutableStateOf<List<DebtDto>>(emptyList()) }
    var name by remember { mutableStateOf("") }
    var balance by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    fun reload() {
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { ApiClient.debts(token) } }
                .onSuccess { debts = it }
                .onFailure { message = it.message ?: "No se pudieron cargar las deudas" }
        }
    }

    LaunchedEffect(token) { reload() }

    Column(Modifier.padding(16.dp)) {
        Text("Mis deudas", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(balance, { balance = it }, label = { Text("Saldo $") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(payment, { payment = it }, label = { Text("Cuota $") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(rate, { rate = it }, label = { Text("Tasa anual %") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            val balanceCents = ((balance.toDoubleOrNull() ?: 0.0) * 100.0).toLong()
            val paymentCents = ((payment.toDoubleOrNull() ?: 0.0) * 100.0).toLong()
            val annualRateBps = ((rate.toDoubleOrNull() ?: 0.0) * 100.0).toInt()
            if (name.isBlank() || balanceCents <= 0L) {
                message = "Ingresa nombre y saldo válido."
                return@Button
            }
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        ApiClient.addDebt(token, name.trim(), balanceCents, paymentCents, annualRateBps)
                        ApiClient.debts(token)
                    }
                }.onSuccess {
                    debts = it
                    name = ""
                    balance = ""
                    payment = ""
                    rate = ""
                    message = "Deuda agregada."
                }.onFailure {
                    message = it.message ?: "No se pudo agregar la deuda"
                }
            }
        }) {
            Text("Agregar deuda")
        }
        if (message.isNotBlank()) Text(message)
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(debts, key = { it.id }) { debt ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(debt.name, style = MaterialTheme.typography.titleLarge)
                        Text("Saldo ${money(debt.balanceCents)}")
                        Text("Cuota ${money(debt.paymentCents)}")
                        Text("Tasa ${debt.annualRateBps / 100.0}%")
                    }
                }
            }
        }
    }
}

@Composable
fun Plan(token: String) {
    var avalanche by remember { mutableStateOf(true) }
    var result by remember { mutableStateOf("Selecciona una estrategia") }
    val scope = rememberCoroutineScope()

    Column(Modifier.padding(16.dp)) {
        Text("Plan de pago", style = MaterialTheme.typography.headlineMedium)
        Row {
            FilterChip(
                selected = avalanche,
                onClick = { avalanche = true },
                label = { Text("Avalancha") }
            )
            Spacer(Modifier.width(8.dp))
            FilterChip(
                selected = !avalanche,
                onClick = { avalanche = false },
                label = { Text("Bola de nieve") }
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        ApiClient.plan(token, if (avalanche) "AVALANCHE" else "SNOWBALL", 0L)
                    }
                }.onSuccess { result = it.toString() }
                    .onFailure { result = "Error: ${it.message ?: "no se pudo calcular"}" }
            }
        }) {
            Text("Calcular plan")
        }
        Text(result)
    }
}

@Composable
fun AI(token: String) {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(Modifier.padding(16.dp)) {
        Text("Asistente IA", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(
            value = question,
            onValueChange = { question = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Pregunta") }
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (question.isBlank()) {
                answer = "Escribe una pregunta."
                return@Button
            }
            scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) { ApiClient.assistant(token, question.trim()) }
                }.onSuccess { answer = it.optString("message") }
                    .onFailure { answer = "Error: ${it.message ?: "no se pudo enviar"}" }
            }
        }) {
            Text("Enviar")
        }
        Spacer(Modifier.height(12.dp))
        Text(answer)
    }
}

@Composable
fun Profile(logout: () -> Unit) {
    val activity = LocalContext.current as? Activity
    var billing by remember { mutableStateOf<BillingManager?>(null) }
    var status by remember { mutableStateOf("Conectando con Google Play…") }

    LaunchedEffect(activity) {
        activity ?: return@LaunchedEffect
        val manager = BillingManager(activity) { product, _ ->
            status = "Compra recibida: $product. Verificación en servidor pendiente."
        }
        billing = manager
        manager.connect { status = "Google Play disponible" }
        manager.restore()
    }

    Column(Modifier.padding(16.dp)) {
        Text("Cuenta", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text("SALDO CERO PRO / PREMIUM")
        Text(status)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { billing?.buy("saldo_cero_pro_monthly") }) {
            Text("Pro $9.990/mes")
        }
        Button(onClick = { billing?.buy("saldo_cero_premium_monthly") }) {
            Text("Premium $14.990/mes")
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = logout) { Text("Cerrar sesión") }
        Text("El servidor valida las compras con Google Play antes de conceder acceso pagado.")
    }
}
