#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const required = [
 'android/app/build.gradle.kts',
 'android/app/src/main/java/cl/saldocero/app/BillingManager.kt',
 'android/app/src/main/java/cl/saldocero/app/MainActivity.kt',
 '.github/workflows/verify-build-v55.yml'
];
for (const f of required) if (!fs.existsSync(path.join(root,f))) throw new Error(`FAIL: missing ${f}`);
const gradle=read('android/app/build.gradle.kts');
const billing=read('android/app/src/main/java/cl/saldocero/app/BillingManager.kt');
const main=read('android/app/src/main/java/cl/saldocero/app/MainActivity.kt');
const workflow=read('.github/workflows/verify-build-v55.yml');
const checks=[
 ['Java 21',/sourceCompatibility\s*=\s*JavaVersion\.VERSION_21/,gradle],
 ['Kotlin JVM 21',/jvmTarget\s*=\s*"21"/,gradle],
 ['versionCode 55',/versionCode\s*=\s*55/,gradle],
 ['versionName 55',/versionName\s*=\s*"55\.0\.0"/,gradle],
 ['Billing 7.1.1',/billing-ktx:7\.1\.1/,gradle],
 ['Billing callback list',/detailsResult\.firstOrNull\(\)/,billing],
 ['No QueryProductDetailsResult',/QueryProductDetailsResult/,billing, true],
 ['No productDetailsList property',/detailsResult\.productDetailsList/,billing, true],
 ['Correct width import',/androidx\.compose\.foundation\.layout\.width/,main],
 ['No invalid nullable ternary',/it\.message\?"/,main, true],
 ['Coroutines Android',/kotlinx-coroutines-android:1\.9\.0/,gradle],
 ['APK build',/assembleDebug/,workflow],
 ['AAB build',/bundleRelease/,workflow],
 ['Android artifact',/saldo-cero-v55-android/,workflow],
];
for (const [name,re,text,negative=false] of checks) { const matched=re.test(text); if ((negative && matched) || (!negative && !matched)) throw new Error(`FAIL: ${name}`); }
console.log('V55 static verification: PASS');
