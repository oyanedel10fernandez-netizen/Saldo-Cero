#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const exists = p => fs.existsSync(path.join(root, p));

const required = [
  'android/app/build.gradle.kts',
  'android/app/src/main/AndroidManifest.xml',
  'android/app/src/main/java/cl/saldocero/app/ApiClient.kt',
  'android/app/src/main/java/cl/saldocero/app/BillingManager.kt',
  'android/app/src/main/java/cl/saldocero/app/MainActivity.kt',
  'backend/package.json'
];
for (const f of required) if (!exists(f)) throw new Error(`FAIL: missing ${f}`);

const gradle = read('android/app/build.gradle.kts');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const api = read('android/app/src/main/java/cl/saldocero/app/ApiClient.kt');
const billing = read('android/app/src/main/java/cl/saldocero/app/BillingManager.kt');
const main = read('android/app/src/main/java/cl/saldocero/app/MainActivity.kt');
const pkg = JSON.parse(read('backend/package.json'));

const checks = [
  ['versionCode 56', /versionCode\s*=\s*56/, gradle],
  ['versionName 56', /versionName\s*=\s*"56\.0\.0"/, gradle],
  ['Java 21', /sourceCompatibility\s*=\s*JavaVersion\.VERSION_21/, gradle],
  ['Kotlin JVM 21', /jvmTarget\s*=\s*"21"/, gradle],
  ['Kotlin 1.9.25', /id\("org\.jetbrains\.kotlin\.android"\) version "1\.9\.25"/, read('android/build.gradle.kts')],
  ['Gradle-compatible Compose compiler', /kotlinCompilerExtensionVersion\s*=\s*"1\.5\.15"/, gradle],
  ['Billing 7.1.1', /billing-ktx:7\.1\.1/, gradle],
  ['Billing callback list', /detailsResult\.firstOrNull\(\)/, billing],
  ['No old Billing result type', /QueryProductDetailsResult/, billing, true],
  ['No old productDetailsList access', /detailsResult\.productDetailsList/, billing, true],
  ['Correct width import', /androidx\.compose\.foundation\.layout\.width/, main],
  ['Coroutines Android', /kotlinx-coroutines-android:1\.9\.0/, gradle],
  ['HTTPS debug API', /debug\s*\{[^}]*https:\/\/api\.saldocero\.cl\//s, gradle],
  ['HTTPS release API', /release\s*\{[^}]*https:\/\/api\.saldocero\.cl\//s, gradle],
  ['No emulator cleartext URL', /10\.0\.2\.2|http:\/\//, gradle, true],
  ['Manifest cleartext disabled', /android:usesCleartextTraffic="false"/, manifest],
  ['API enforces HTTPS', /base\.startsWith\("https:\/\/"\)/, api],
  ['Friendly unknown-host handling', /No se pudo encontrar el servidor/, api],
  ['APK workflow command', /assembleDebug/, read('.github/workflows/verify-build-v56.yml')],
  ['AAB workflow command', /bundleRelease/, read('.github/workflows/verify-build-v56.yml')],
  ['Android artifact', /saldo-cero-v56-android/, read('.github/workflows/verify-build-v56.yml')],
  ['V56 verifier script', pkg.scripts?.['verify:v56'] === 'node scripts/verify-v56.mjs', JSON.stringify(pkg.scripts)]
];

for (const [name, re, text, negative=false] of checks) {
  const matched = typeof re === 'boolean' ? re : re.test(String(text));
  if ((negative && matched) || (!negative && !matched)) throw new Error(`FAIL: ${name}`);
}
console.log('V56 static verification: PASS');
