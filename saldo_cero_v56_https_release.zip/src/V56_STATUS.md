# SALDO CERO V56 — STATUS

V56 parte directamente de V55 y corrige la causa de la pantalla `Cleartext HTTP traffic to 10.0.2.2 not permitted`.

## Build gate
- Backend: build + verify:v56
- Android: assembleDebug + bundleRelease
- Artifact: saldo-cero-v56-android

## Runtime gate
- API Base URL: HTTPS únicamente
- Debug: https://api.saldocero.cl/
- Release: https://api.saldocero.cl/
- Cleartext HTTP: deshabilitado

## No se afirma
No se afirma que la API de producción esté desplegada o accesible hasta comprobarlo desde un entorno real.
