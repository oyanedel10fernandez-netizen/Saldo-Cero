# CHANGELOG V56

- Base: V55
- Eliminada dependencia de `10.0.2.2` para el APK instalado en teléfono.
- HTTPS obligatorio para ApiClient.
- Manifest mantiene cleartext deshabilitado.
- Mejor manejo de UnknownHostException y SocketTimeoutException.
- Verificación estática V56.
- Workflow V56 para backend + APK + AAB.
