# SALDO CERO V56 — CONEXIÓN HTTPS Y BUILD ROBUSTO

V56 se basa directamente en V55.

## Correcciones principales
- La app ya no usa `http://10.0.2.2:8080` en debug.
- Debug y release apuntan a `https://api.saldocero.cl/`.
- Se mantiene `usesCleartextTraffic=false`.
- ApiClient rechaza cualquier base URL que no sea HTTPS.
- Se agregan mensajes de error de red más claros.
- Se mantienen las correcciones Billing 7.1.1 de V55.
- Se mantiene Java 21, Kotlin 1.9.25, Compose compiler 1.5.15 y Gradle 8.9.
- Se genera APK Debug y AAB Release y ambos se publican como artifact.

## Nota
El dominio `api.saldocero.cl` debe estar realmente desplegado y responder por HTTPS para que el registro/login funcionen en un teléfono. Esta versión no inventa ni embebe credenciales de producción.
