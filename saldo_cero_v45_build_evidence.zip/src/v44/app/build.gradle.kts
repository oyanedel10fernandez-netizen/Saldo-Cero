plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="cl.saldocero.app"
    compileSdk=35
    defaultConfig {
        applicationId="cl.saldocero.app"
        minSdk=26
        targetSdk=35
        versionCode=16
        versionName="16.0.0"
    }
    buildFeatures { compose=true; buildConfig=true }
    buildTypes {
        getByName("debug") { buildConfigField("String","API_BASE_URL","\"http://10.0.2.2:8080/\"") }
        getByName("release") { buildConfigField("String","API_BASE_URL","\"https://api.saldocero.cl/\"") }
    }
    composeOptions { kotlinCompilerExtensionVersion="1.5.15" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.compose.ui:ui:1.7.8")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.8")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("com.android.billingclient:billing-ktx:7.1.1")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-kotlinx-serialization:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    debugImplementation("androidx.compose.ui:ui-tooling:1.7.8")
}
