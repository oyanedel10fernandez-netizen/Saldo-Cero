import { loadV38Config } from "../config/env-v38";

export function assertProductionConfiguration(): ReturnType<typeof loadV38Config> {
  const cfg = loadV38Config();
  if (cfg.NODE_ENV === "production") {
    // Guardrail: production must never rely on localhost/demo endpoints.
    if (cfg.DATABASE_URL.includes("localhost") || cfg.REDIS_URL.includes("localhost")) {
      throw new Error("Production configuration cannot use localhost database/redis endpoints");
    }
  }
  return cfg;
}
