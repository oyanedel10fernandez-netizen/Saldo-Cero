# SALDO CERO V50

V50 corrige el problema de V49 donde la verificación exigía que el workflow de GitHub Actions estuviera dentro del ZIP.

## Cambios principales
- Verificación estática V50 independiente del workflow externo.
- Workflow V50 separado para GitHub Actions.
- Backend y Android continúan como jobs independientes.
- Node.js 22 para CI.
- Gradle 8.9 para Android.
- Android genera APK debug y AAB release.
- Se copian APK/AAB a `android/artifacts/` y se generan SHA-256.
- Los artefactos usan `if-no-files-found: error`.
- La evidencia de backend exige `dist/server.js`.
- No contiene credenciales ni conexiones reales de producción.

Estado: preparado para ejecutar en GitHub Actions.
