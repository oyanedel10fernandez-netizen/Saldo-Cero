# Changelog V51

- Fixed Android Kotlin compilation errors from V50.
- Hardened Billing Library callback handling.
- Added V51 verification workflow.
