# V50 FIXES

1. `verify-v50.mjs` ya no exige `.github/workflows/verify-build-v50.yml` dentro del ZIP.
2. El workflow localiza el proyecto después de extraer el ZIP usando `V50_STATUS.md`.
3. Android usa Gradle 8.9 para evitar el error de compatibilidad visto con Gradle 8.7.
4. Backend y Android son jobs independientes para que un fallo no oculte el resultado del otro.
5. La evidencia Android falla explícitamente si no aparece un APK o AAB.
