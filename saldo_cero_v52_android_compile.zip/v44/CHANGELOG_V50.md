# Changelog V50

- Version Android: 50.0.0
- Nuevo verificador `verify:v50`.
- Corregida dependencia incorrecta del workflow dentro del archivo ZIP.
- Pipeline de GitHub Actions V50 con Gradle 8.9 y Node 22.
- Evidencia de APK/AAB y hashes SHA-256.
