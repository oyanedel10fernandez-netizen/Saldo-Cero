# SALDO CERO V52

V52 addresses the remaining Android compile blockers exposed by the V51 build.

## Changes
- Explicitly imports `androidx.compose.ui.unit.width` because `Spacer(Modifier.width(...))` is used.
- Explicitly adds `kotlinx-coroutines-android:1.9.0` for `Dispatchers`, `launch`, and `withContext`.
- Keeps V51 fixes for Kotlin null handling and Billing Library 7.1.1 callbacks.
- Android version 52.0.0.
- Separate backend and Android GitHub Actions jobs.
- Gradle 8.9.

## Success criterion
The V52 GitHub Actions Android job must complete both `assembleDebug` and `bundleRelease` and produce an APK plus AAB.
