# Changelog V52

- Added missing Compose width import.
- Added explicit Android coroutines dependency.
- Added V52 CI build workflow.
