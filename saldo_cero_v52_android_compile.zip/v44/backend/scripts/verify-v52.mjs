import fs from "node:fs";

const root = process.cwd();
const main = fs.readFileSync("../android/app/src/main/java/cl/saldocero/app/MainActivity.kt", "utf8");
const gradle = fs.readFileSync("../android/app/build.gradle.kts", "utf8");

const checks = [
  ["Compose width import", main.includes("import androidx.compose.ui.unit.width")],
  ["Coroutines imports", main.includes("kotlinx.coroutines.Dispatchers") && main.includes("kotlinx.coroutines.withContext")],
  ["Coroutines dependency", gradle.includes("kotlinx-coroutines-android:1.9.0")],
  ["No invalid Kotlin ternary", !main.includes("it.message?\"")],
  ["No obsolete Billing result type", !fs.readFileSync("../android/app/src/main/java/cl/saldocero/app/BillingManager.kt", "utf8").includes("QueryProductDetailsResult")],
  ["No nullable acknowledge listener", !fs.readFileSync("../android/app/src/main/java/cl/saldocero/app/BillingManager.kt", "utf8").includes("acknowledgePurchase(params, null)")]
];

for (const [name, ok] of checks) {
  if (!ok) throw new Error(`FAIL: ${name}`);
}
console.log("V52 static verification: PASS");
