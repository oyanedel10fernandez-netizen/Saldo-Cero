import fs from "node:fs";
import path from "node:path";

const root = path.resolve(new URL("../..", import.meta.url).pathname);
const required = [
  "backend/package.json",
  "backend/src/server.ts",
  "android/app/build.gradle.kts",
  "V50_STATUS.md",
];

for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) throw new Error(`Missing ${rel}`);
}

const pkg = JSON.parse(fs.readFileSync(path.join(root, "backend/package.json"), "utf8"));
if (!pkg.scripts?.build || !pkg.scripts?.["verify:v50"]) {
  throw new Error("Backend scripts missing");
}

const gradle = fs.readFileSync(path.join(root, "android/app/build.gradle.kts"), "utf8");
if (!gradle.includes("versionCode = 50") || !gradle.includes('versionName = "50.0.0"')) {
  throw new Error("Android version is not V50");
}

console.log("V50 static verification: PASS");
