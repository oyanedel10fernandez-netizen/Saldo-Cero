import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const required = [
  "android/app/src/main/java/cl/saldocero/app/MainActivity.kt",
  "android/app/src/main/java/cl/saldocero/app/BillingManager.kt",
  "android/app/build.gradle.kts",
  ".github/workflows/verify-build-v51.yml"
];

for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) {
    throw new Error(`Missing ${rel}`);
  }
}

const main = fs.readFileSync(
  path.join(root, "android/app/src/main/java/cl/saldocero/app/MainActivity.kt"),
  "utf8"
);
const billing = fs.readFileSync(
  path.join(root, "android/app/src/main/java/cl/saldocero/app/BillingManager.kt"),
  "utf8"
);

if (main.includes('it.message?"')) throw new Error("Invalid Kotlin ternary syntax remains");
if (!main.includes('it.message ?: "Error de conexión"')) throw new Error("Login error fallback missing");
if (!main.includes('it.message ?: "No se pudo crear la cuenta"')) throw new Error("Register error fallback missing");
if (billing.includes("QueryProductDetailsResult")) throw new Error("Explicit QueryProductDetailsResult type should not be required");
if (billing.includes("acknowledgePurchase(params, null)")) throw new Error("Nullable acknowledge listener remains");
if (!billing.includes("client.acknowledgePurchase(params)")) throw new Error("Acknowledge call missing");
if (!billing.includes("queryProductDetailsAsync(params) { result, detailsResult ->")) throw new Error("Billing product query not using inferred callback");
if (!billing.includes("queryPurchasesAsync(params) { result, purchases ->")) throw new Error("Billing restore query not using inferred callback");

console.log("V51 static verification: PASS");
