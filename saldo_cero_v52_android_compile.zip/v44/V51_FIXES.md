# SALDO CERO V51 — Android compile fix

V51 addresses the concrete V50 Android compile failures observed in GitHub Actions.

## Fixed
- Removed invalid Kotlin `condition ? a : b` syntax from `MainActivity.kt`.
- Rewrote affected authentication/error handling with Kotlin `?:`.
- Reworked `BillingManager.kt` to use inferred Billing Library callback result types.
- Removed the nullable `null` acknowledgement listener call.
- Kept Google Play purchase acknowledgement and restore behavior.
- Bumped Android version to 51.0.0.
- Added a dedicated V51 GitHub Actions workflow with separate backend and Android jobs.
- Android workflow uses Gradle 8.9.

## V50 errors directly addressed
- `Unresolved reference: QueryProductDetailsResult`
- `Null can not be a value of a non-null type AcknowledgePurchaseResponseListener`
- `Unexpected tokens` in `MainActivity.kt`
- `Type mismatch: inferred type is String? but String was expected`
- `Unsupported [literal prefixes and suffixes]`

## Important
The V51 package is prepared for GitHub Actions. A real APK/AAB build is only considered successful after the V51 workflow turns green.
